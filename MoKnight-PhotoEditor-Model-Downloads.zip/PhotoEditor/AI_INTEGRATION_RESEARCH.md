# MoKnight Photo Editor — AI and open-source integration research

This note records candidate projects and the integration decision. It does not claim that their code or models are already bundled into this app.

## Hair segmentation

- Google MediaPipe Image Segmenter documents models for person/background, hair-only, and person parts (hair, face, skin, clothing, accessories).
- This is the strongest candidate for hair refinement because it can run on-device. Google's HairSegmenter model card lists Apache 2.0 licensing. The documented model is intended for a single smartphone selfie subject; distant subjects, multiple people, thin braids and headwear can reduce accuracy.
- The Kotlin integration now loads `hair_segmenter.tflite` through MediaPipe Tasks Vision. The Gradle `preBuild` task downloads the official model into the Android assets folder if it is missing. The binary could not be downloaded in this working environment, so it is not physically present in this ZIP; the first Android build must have internet access. The installed app can then run the hair model offline.
- Official guide: https://developers.google.com/edge/mediapipe/solutions/vision/image_segmenter

## Small object repair

- `EmreO33/unmark` is an Android/Kotlin offline example using a manual mask and nearest-fill/smoothing inpainting. It explicitly is not generative AI. MoKnight now has mask-based nearest-pixel fill as a similar classical fallback.
- MoKnight now has a lightweight local circular repair primitive based on nearest-pixel propagation for small marks. This is an algorithmic repair aid, not a replacement for LaMa/ diffusion inpainting.
- Repository: https://github.com/EmreO33/unmark

## Generative fill / AI object removal

- `Sanster/IOPaint` and `beckettharriman/openfill` are desktop/local-GPU projects and are not drop-in Android libraries.
- The selected Android integration is LaMa ONNX through ONNX Runtime Android. LaMa is an image-inpainting model that reconstructs a selected mask from surrounding visual context.
- The model is downloaded only after the user presses Generative Fill, checked against a pinned SHA-256, and kept in app-private storage. Once downloaded, inference is local.
- The fixed 512×512 model is not text-prompt guided and may lose detail on large images. Android runtime support, speed and memory use still require a real build and device test.
- References: https://github.com/Sanster/IOPaint, https://github.com/beckettharriman/openfill, https://huggingface.co/sapienkit/LaMa-ONNX

## General object selection

- Person segmentation remains available through ML Kit Selfie Segmentation.
- A point-based MagicTouch interactive segmenter is now integrated. The user taps an object in the photo; the model returns a mask. The Gradle `preBuild` task fetches the official model asset. This is point-guided segmentation, not text-prompt selection of every possible object.

## Licensing and reuse policy

Before copying any third-party source or bundling weights, verify the exact repository licence, model licence, attribution requirements, notices, and commercial-use restrictions. Prefer integrating a library/API over copying an entire application. Do not bundle model weights whose terms are unclear.

## Newly integrated MediaPipe tasks

- `MediaPipeOfflineModels.kt` contains point-guided object selection via `InteractiveSegmenter` and hair-only segmentation via `ImageSegmenter`.
- `app/build.gradle.kts` downloads `magic_touch.tflite` and `hair_segmenter.tflite` during the first `preBuild` when missing. This is a build-time download only; the model files are packaged in the resulting app for offline inference.
- MagicTouch is based on the official MediaPipe interactive segmentation model. Its model card describes a roughly 6 MB point-guided object mask model and Apache 2.0 licensing.
- HairSegmenter is designed for a close, single-person selfie and can struggle with thin braids/strands, headwear, multiple subjects or distant people.
- Official Android API guides: https://developers.google.com/edge/mediapipe/solutions/vision/interactive_segmenter/android and https://developers.google.com/edge/mediapipe/solutions/vision/image_segmenter/android


## Integrated LaMa ONNX Generative Fill

- Integrated `sapienkit/LaMa-ONNX` `lama_fp32.onnx` with ONNX Runtime Android.
- Model card documents fixed 512×512 RGB image and erase-mask inputs and a 512×512 RGB output.
- Apache-2.0 model card; original LaMa and ONNX export are Apache-2.0; Places2 attribution is CC-BY 4.0.
- First use downloads the model after a user tap, verifies the pinned SHA-256, and stores it in app-private storage. Inference after download is local.
- The model is context-based inpainting, not prompt-guided image generation. 512×512 fixed input may reduce detail on large photos.
- Runtime compatibility, output quality, latency and memory use remain unverified until an Android build and device test are run.

## Cinematic grading and creative-effects research (2026-11-02)

The cinematic panel is being designed as manual image development, not as a row of named one-click looks. The reference workflow is based on Adobe Camera Raw's documented separation of exposure/contrast/highlights/shadows/whites/blacks, white balance, vibrance/saturation, color mixer, RGB curves, and three-range color grading wheels. The implementation in this project uses its own Kotlin pixel operations; it does not copy Adobe code or assets.

Research references from separate open-source projects:
- CalibRaw (Duecki1/CalibRaw): reference for a non-destructive photo workflow, color mixer, point color, curves, grading wheels, local masks, sharpening and noise reduction. Its project is GPL-3.0-or-later; no source code was copied into this project.
- PixelPerfect-PhotoEditor (ProHussain): reference for an Android editor's HSL, GPU filter pipeline, crop and basic adjustments. The repository describes itself as MIT-licensed; no source code was copied into this project.
- Android-GPUImage-Plus (iigacon/gpuimage): reference for the breadth of GPU image effects and shader-based filter architecture. No source code was copied into this project.

Network access from the build workspace was unavailable, so repository archives could not be cloned/downloaded locally. The research was based on repository search metadata and project descriptions. No third-party repository code or binaries are bundled.

Current manual controls added in this revision:
- Exposure, contrast, highlights, shadows, whites, blacks.
- Temperature, tint, vibrance, saturation.
- Independent shadow, midtone and highlight hue/strength controls, plus tonal balance.
- Eight creative operations: matte fade, posterize, solarize, duotone, highlight lift, edge burn, emboss and threshold.
- Existing effects remain separately available in the Effects panel: vignette, grain, blur, sharpening, clarity and texture.

Limitations: the three color wheels are currently represented by hue and strength sliders, not a draggable circular wheel widget. These are bitmap CPU operations and may take time on large images; GPU shader acceleration and a true non-destructive adjustment stack remain future work. The legacy named-look transform remains in source for compatibility but is no longer presented in the Cinematic panel.
