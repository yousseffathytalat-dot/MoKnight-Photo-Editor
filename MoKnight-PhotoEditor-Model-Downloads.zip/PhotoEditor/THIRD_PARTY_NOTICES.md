# Third-party notices

## Google ML Kit Selfie Segmentation

Dependency: `com.google.mlkit:segmentation-selfie:16.0.0-beta6`.
See the official ML Kit documentation and applicable Google terms.

## MediaPipe Tasks Vision

Dependency: `com.google.mediapipe:tasks-vision:1.1.1`.
HairSegmenter and MagicTouch model assets are downloaded during the Gradle preBuild task. See the MediaPipe model documentation and licenses.

## ONNX Runtime Android

Dependency: `com.microsoft.onnxruntime:onnxruntime-android:1.20.0`.
ONNX Runtime is distributed under the MIT License.

## LaMa ONNX inpainting model

Model: `sapienkit/LaMa-ONNX`, file `lama_fp32.onnx`.
Model card license: Apache License 2.0. Original LaMa model: `advimman/lama`, Apache-2.0. ONNX export based on `Carve/LaMa-ONNX`, Apache-2.0. Training dataset attribution: Places2, CC-BY 4.0. Model SHA-256 is pinned in `GenerativeFillEngine.kt`.

Paper: Suvorov et al., “Resolution-robust Large Mask Inpainting with Fourier Convolutions,” WACV 2022.

The ONNX model weights are downloaded by the app on first user-initiated Generative Fill use and are not redistributed inside this source ZIP.

## Real-ESRGAN x4plus (AI Upscale)

Model file: `real_esrgan_x4.onnx` from `SceneWorks/real-esrgan-onnx` on Hugging Face (1:1 ONNX export of the original `RealESRGAN_x4plus.pth` weights from xinntao/Real-ESRGAN). The model card lists the BSD-3-Clause license, and publishes the SHA-256 `5c586662929cbc686c1a5c38d9c060dbdb4ea5863a1f7672b8c0761e6b89c033`, which the app checks after download. The weights are downloaded on first explicit use and are not bundled in this repository. See https://github.com/xinntao/Real-ESRGAN and https://huggingface.co/SceneWorks/real-esrgan-onnx.

## Android-GPUImage-Plus

`org.wysaid:gpuimage-plus:3.2.0-min` — MIT. Upstream: https://github.com/wysaid/android-gpuimage-plus. The image-only artifact avoids bundling its FFmpeg/video feature set.

## OpenCV Android

`org.opencv:opencv:4.14.0` — Apache-2.0 / BSD-3-Clause family (Maven Central listing: Apache 2.0). Upstream: https://github.com/opencv/opencv.

## Jetpack Compose UI motion

The AI Studio visual treatment uses the existing AndroidX Jetpack Compose animation and drawing APIs (including `rememberInfiniteTransition`, `animateContentSize`, gradients and draw modifiers). No additional third-party animation runtime or remotely sourced UI assets are bundled. Refer to the Android Developers Compose animation documentation: https://developer.android.com/develop/ui/compose/animation/introduction.
