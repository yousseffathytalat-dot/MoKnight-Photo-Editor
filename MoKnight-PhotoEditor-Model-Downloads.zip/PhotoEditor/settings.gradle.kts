pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement {
    repositories {
        google()
        mavenCentral()
        // Android-GPUImage-Plus artifacts are published by the upstream project.
        maven(url = "https://maven.wysaid.org/")
    }
}
rootProject.name = "PhotoEditor"
include(":app")
