# MoKnight Photo Editor — Feature Status

This is the consolidated Android source project. The source has not been built or device-tested in this delivery; status below distinguishes implemented code from verified runtime behavior.

## The 14 core features

| # | Feature | Current status |
|---|---|---|
| 1 | Crop & Straighten | **Implemented in source** — aspect-ratio crop, rotate/flip, -45° to +45° straighten, four independently draggable perspective corners, live 3×3 alignment grid, and four-point projective warp. Not yet build/device-tested. |
| 2 | Advanced Adjustments | **Implemented in source** — brightness, contrast, saturation, exposure, highlights, shadows, temperature and tint. |
| 3 | HSL | **Implemented in source** — hue, saturation and lightness controls for selected color ranges. |
| 4 | Curves | **Implemented in source** — master RGB and independent red/green/blue curves; each channel accepts multiple editable input/output control points before applying. |
| 5 | Healing & Object Removal | **Implemented in source** — drag-based Clone Stamp and local repair brush for small defects, plus selected-mask LaMa inpainting for larger unwanted objects. LaMa model download/inference and visual quality still require device verification. |
| 6 | Sharpen, Clarity & Texture | **Implemented in source** — separate sharpening, local-contrast Clarity, and fine-detail Texture controls with adjustable strength. |
| 7 | Background Blur | **Implemented in source** — person mask and selective background blur. |
| 8 | Layers | **Expanded in source; runtime unverified** — non-destructive adjustment layers; bitmap, text and vector layers have direct on-canvas move/scale/rotate handles; independent masks are supported for bitmap, adjustment, text, vector and drawing overlays; layer lock, rename, visibility, order and opacity controls. Text/vector transform bounds are approximate and need touch-device validation. |
| 9 | AI Background Removal | **Implemented in source** — person segmentation, transparent cutout, solid/image background replacement, plus a foreground-person layer over the original image. Model execution still needs device testing. |
| 10 | Advanced Text Editor | **Implemented in source** — text editing, fill/outline/shadow, size, bold/italic, built-in/custom TTF/OTF fonts, letter/line spacing, rotation, alignment, opacity and rounded background. New text can be inserted below the isolated-person layer. |
| 11 | Shapes | **Expanded in source; runtime unverified** — tap-to-place Pen Tool nodes, editable cubic Bézier handles, smooth/corner nodes, direct vector transform handles, and vector path Union/Subtract/Intersect operations. Boolean-result paths are stored as Android vector paths; their post-boolean node editing and SVG export remain limited. |
| 12 | Gradients | **Implemented in source** — start/end colors, alpha/opacity and angle controls. |
| 13 | Masks & Selections | **Expanded in source; runtime unverified** — manual add/erase with hardness, named save/load, invert, feather, expand/shrink, person/hair segmentation, point-based MagicTouch selection, and independent editable masks for bitmap, adjustment, text, vector and drawing overlays. Hair-edge controls improve matte contrast/feather only; they do not recover individual strands or perform AI color decontamination. |
| 14 | Double Exposure | **Expanded in source; runtime unverified** — ten blend modes, opacity, scale, rotation, X/Y offset, RGB channel selection, optional subject-mask compositing, Blend-If-style shadow/highlight luminance ranges with softness, and live canvas preview while controls change. The flattened apply action uses the same mask/range/channel settings. |

## Generative AI and background workflow

### LaMa Generative Fill / AI object removal

- Integrated `GenerativeFillEngine.kt` using ONNX Runtime Android and a LaMa 512×512 ONNX model.
- Inputs: current image and a selection mask; white/opaque mask areas are reconstructed from surrounding context.
- First use downloads the model from Hugging Face after the user taps **Generative Fill**. The file is SHA-256 checked before it is stored in app-private storage.
- After successful download, inference is local and can run offline. Photos and masks are not uploaded.
- This LaMa implementation is context-based inpainting. It does **not** accept a text prompt such as “replace this with a red car”.
- The model uses a fixed 512×512 input, so output detail can be lower than the original for large images. Quality, speed, memory use and ONNX operator compatibility still need testing on target phones.

### Separate a person and put text behind them

1. Select the person using person segmentation.
2. Tap **فصل الشخص كطبقة أمامية**. The original photo remains as the background and a transparent cutout of the person is added as an independent top layer.
3. Add text and enable **ضع النص خلف الشخص المعزول**. The new text is inserted below the isolated-person layer, so it appears over the original background but behind the person.
4. Use layer ordering and undo as needed.

The original image is retained as the background; the subject cutout is a separate transparent overlay. This is the intended compositing workflow rather than permanently erasing the background from the original image.

### Other AI models

- ML Kit Selfie Segmentation: person mask.
- MediaPipe HairSegmenter: hair mask.
- MediaPipe MagicTouch: tap-based object selection.
- LaMa ONNX: context-based generative inpainting / object removal.

These are different tasks and do not all share the same accuracy or hardware requirements.

## Model download, privacy and licensing

- LaMa model: `sapienkit/LaMa-ONNX`, `lama_fp32.onnx`, Apache-2.0 model card.
- SHA-256 pinned in code: `1faef5301d78db7dda502fe59966957ec4b79dd64e16f03ed96913c7a4eb68d6`.
- Model URL: `https://huggingface.co/sapienkit/LaMa-ONNX/resolve/main/lama_fp32.onnx`.
- The ONNX file is **not** embedded in this source ZIP. The app downloads it once on first Generative Fill use; an internet connection is needed for that initial download. The verified file is kept in app-private storage for later offline use.
- The HairSegmenter and MagicTouch model assets are fetched by the Gradle preBuild task; first build requires internet. Once packaged, their inference is local.

## Build and test status

- No APK was built, as requested.
- No Gradle build or on-device test was run in this environment. “Implemented in source” means the corresponding editing controls and processing paths are present; it is not a claim of successful device verification.
- The original project has no Gradle wrapper scripts/JAR. Open the project in Android Studio with JDK 17 and let Gradle resolve dependencies.
- Do not treat source integration as verified runtime success until it builds and the models are exercised on the target device.

## Latest source additions (2026-11-02)

- Layers: added direct on-canvas move/scale/rotate handles for text and vector overlays as well as bitmap layers. Masks can be painted and attached independently to bitmap, adjustment, text, vector and drawing layers. Layer locking applies to transform and mask editing.
- Masks: generalized independent masks to bitmap, adjustment, text, vector and drawing layers. The Masks tool can switch between the global selection and the selected layer mask. Manual hair-edge matte refinement controls remain contrast/feather adjustments, not strand reconstruction or color decontamination.
- Double exposure: added live canvas preview while opacity, transform, blend mode and channel controls change; optional selection-mask preview; and Blend-If-style luminance range controls for shadows/highlights with softness. Ten blend modes and RGB source-channel toggles remain available.
- Vector/SVG: PathLayer now stores cubic Bézier incoming/outgoing handles. Selected nodes can be switched between smooth and sharp, and handles are drawn and draggable directly on the canvas. SVG export remains hybrid: the photo background and non-vector layers are embedded as PNG while editable paths are exported as vector paths.
- App icon artwork: added an "أيقونة 1024" export action that places the current composite image on a centered 1024×1024 black square PNG in Pictures/MoKnightIcons. This creates icon artwork; it does not automatically replace Android launcher icon resources or provide a complete logo-design editor.
- Effects: added a cinematic teal-shadow / warm-highlight lighting grade with contrast, vignette and bloom controls.
- Build status remains unchanged: no APK or Gradle build/device test has been run.


## متابعة المرحلة الاحترافية – 2026-11-02

- أضيف خيار Boolean XOR (الاستبعاد المتبادل) إلى محرر المسارات، بجانب الاتحاد والطرح والتقاطع.
- تحويل النصوص والأشكال عبر الإطار المباشر موجود في واجهة MOVE؛ طبقات الصور لها تحويل مستقل.
- أقنعة مستقلة مدعومة لطبقات الصور والتعديلات والنصوص والأشكال والرسم.
- Adjustment Layers غير مدمرة وتُطبّق على الطبقات الواقعة أسفلها، مع قناع وشفافية.
- تحرير Bézier بالنقاط ومقابض الدخول والخروج، مع نقاط حادة/ناعمة.
- تحسين حواف الشعر الحالي يعتمد على تحسين انتقالات القناع يدويًا، وليس نموذجًا متخصصًا لاستعادة خصل الشعر.
- Blend If حسب إضاءة الصورة الأساسية موجود ضمن أداة التعريض المزدوج، مع عتبات الظلال والإضاءات ونعومة الانتقال، إضافة إلى قنوات RGB وأنماط الدمج.
- الإضاءة السينمائية متاحة كأداة منفصلة تتضمن الدفء/التيل والتباين والتظليل والتوهج.

لم يتم تنفيذ Build أو اختبار على جهاز فعلي؛ وجود التنفيذ في المصدر لا يثبت خلوه من أخطاء التشغيل.


## Three additional AI features (15–17)

| # | Feature | Source status |
|---|---|---|
| 15 | AI Object Removal | **Integrated in source** — selected-mask LaMa inpainting is exposed in the AI panel. It reconstructs from surrounding image context; it is not prompt-based generative replacement. Runtime quality/performance remain unverified. |
| 16 | AI Image Upscale | **Integrated in source; runtime unverified** — Real-ESRGAN x4plus ONNX inference, first-use model download, local tiled inference, and a 4096-pixel maximum long edge. It can enhance apparent detail but cannot guarantee recovery of true details absent from the source. The model file is not included in the ZIP. |
| 17 | Smart Selection | **Integrated in source** — MediaPipe MagicTouch tap-to-select, plus person and hair segmentation. MagicTouch is point-guided selection, not a text-prompt/open-vocabulary selector; manual mask refinement remains available. |

### AI Upscale model notes

- Model: `SceneWorks/real-esrgan-onnx` `real_esrgan_x4.onnx` (BSD-3-Clause export of the original Real-ESRGAN x4plus weights), verified after download with the publisher-listed SHA-256.
- The ONNX file is downloaded only after the user explicitly starts AI Upscale. It is stored in app-private storage; subsequent inference is on-device.
- The model is not bundled in the source ZIP. First use requires internet and roughly 60–70 MB of model download, plus temporary memory for inference.
- The source validates a minimum model size and rejects obvious HTML responses. The SHA-256 is pinned in `AiUpscaleEngine.kt`; the download URL was not fetched in the environment where this was edited, so the first real download should be tested.
- Inference uses 256×256 tiles and x4 output. Input is reduced when necessary so the longest output edge does not exceed 4096 pixels. This is a resource limit, not a guarantee of 4K detail quality.
- No APK, Gradle build, model download, inference, or device test was performed in this delivery.

### AI feature distinction

- **AI Object Removal (15):** LaMa fills a user-selected region using surrounding context.
- **AI Upscale (16):** Real-ESRGAN x4plus increases image resolution and attempts detail restoration.
- **Smart Selection (17):** MagicTouch selects an object from a tap point; person/hair models provide additional segmentation choices.

These models perform different tasks. All first-time model downloads require internet; inference is intended to run locally after installation.

## تحديث واجهة وأدوات 2026-11-02 (مرحلة التلوين السينمائي)
- فصل التلوين السينمائي في أداة مستقلة بدل خلطه مع الحدة والتأثيرات.
- إضافة ستة Looks سينمائية مدمجة بأسلوب LUT (Teal & Orange, Hollywood, Moody Blue, Warm Film, Bleach Bypass, Vintage Film).
- إضافة لوحة Color Grading مستقلة لضبط دفء الإضاءات، Teal الظلال، التباين، Vignette وBloom.
- تسمية أداة القص لتوضح أن تصحيح المنظور موجود داخلها؛ تحريك أركان الصورة الأربعة والشبكة والتصحيح الرباعي موجودة بالفعل.
- لم تتم إضافة HSL أو التحديد الذكي أو إزالة الخلفية أو LaMa/Generative Fill مرة ثانية؛ الأدوات السابقة موجودة في المصدر وتم الإبقاء عليها.
- هذه المرحلة تغيّر تنظيم أدوات التلوين وتضيف Looks برمجية داخلية؛ لا تدّعي دعم استيراد ملفات LUT بصيغة .cube أو واجهة Photoshop مكتملة بعد.
- تنظيم شريط الأدوات إلى أربع مجموعات قابلة للتبديل: أساسي، الألوان، AI والتحديد، التصميم والطبقات؛ وتظهر أدوات المجموعة المختارة فقط لتقليل الزحمة على شاشة الهاتف.

## Vector icon system (2026-11-02)

- Added `MoIcons.kt`: original lightweight vector icon renderer using Jetpack Compose Canvas and a 24×24 coordinate grid.
- Replaced Unicode placeholder glyphs in the top action buttons, tool strip, layer rows, and bottom navigation with semantic vector icons.
- No raster icon assets or extra icon dependency were added. This is an in-project vector set, not the complete Lucide package.
- Build and visual verification remain outstanding.

## Smart Filters (Phase 2)

- Non-destructive, per-layer filter stacks on Bitmap Layers and Adjustment Layers.
- Blur, approximate Gaussian Blur, Sharpen, Noise, Grayscale, Brightness, Contrast, and Color Adjustments.
- Per-filter intensity, enable/disable, reorder, individual removal, and clear-stack controls.
- Source bitmap remains unchanged; changes participate in the editor's existing Undo/Redo history.
