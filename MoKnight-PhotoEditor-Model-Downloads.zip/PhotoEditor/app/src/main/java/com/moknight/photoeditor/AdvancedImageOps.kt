package com.moknight.photoeditor

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/** Offline pixel operations used by the editor. All functions work locally on the device. */
object AdvancedImageOps {
    data class HslRange(val hue: Float = 0f, val saturation: Float = 0f, val lightness: Float = 0f)

    data class CinematicGrade(
        val exposure: Float = 0f, val contrast: Float = 0f,
        val highlights: Float = 0f, val shadows: Float = 0f,
        val whites: Float = 0f, val blacks: Float = 0f,
        val temperature: Float = 0f, val tint: Float = 0f,
        val vibrance: Float = 0f, val saturation: Float = 0f,
        val shadowHue: Float = 210f, val shadowAmount: Float = 0f,
        val midHue: Float = 35f, val midAmount: Float = 0f,
        val highlightHue: Float = 42f, val highlightAmount: Float = 0f,
        val balance: Float = 0f
    )

    /** Manual, non-preset grading inspired by a photographic raw workflow. */
    fun applyCinematicGrade(source: Bitmap, g: CinematicGrade): Bitmap {
        val w=source.width; val h=source.height
        val input=IntArray(w*h); source.getPixels(input,0,w,0,0,w,h)
        val output=IntArray(input.size)
        val gain=2.0.pow(g.exposure.coerceIn(-4f,4f).toDouble()).toFloat()
        fun wheel(rgb: FloatArray, hue: Float, amount: Float) {
            if (amount==0f) return
            val hsv=FloatArray(3); Color.RGBToHSV((rgb[0]*255).toInt().coerceIn(0,255),(rgb[1]*255).toInt().coerceIn(0,255),(rgb[2]*255).toInt().coerceIn(0,255),hsv)
            val target=Color.HSVToColor(floatArrayOf(hue.coerceIn(0f,360f),1f,1f))
            val tr=Color.red(target)/255f; val tg=Color.green(target)/255f; val tb=Color.blue(target)/255f
            val a=amount.coerceIn(-1f,1f)*.18f
            rgb[0]=(rgb[0]+(tr-.5f)*a).coerceIn(0f,1f); rgb[1]=(rgb[1]+(tg-.5f)*a).coerceIn(0f,1f); rgb[2]=(rgb[2]+(tb-.5f)*a).coerceIn(0f,1f)
        }
        for(i in input.indices){
            val c=input[i]; val a=c ushr 24
            val origR=((c shr 16)and 255)/255f; val origG=((c shr 8)and 255)/255f; val origB=(c and 255)/255f
            val lum=.2126f*origR+.7152f*origG+.0722f*origB
            val sh=(1f-lum).coerceIn(0f,1f).pow(2); val hi=lum.coerceIn(0f,1f).pow(2)
            var r=origR*gain + g.shadows.coerceIn(-1f,1f)*sh*.35f + g.highlights.coerceIn(-1f,1f)*hi*.35f + g.whites.coerceIn(-1f,1f)*lum.pow(4)*.25f + g.blacks.coerceIn(-1f,1f)*(1f-lum).pow(4)*.25f
            var gg=origG*gain + g.shadows.coerceIn(-1f,1f)*sh*.35f + g.highlights.coerceIn(-1f,1f)*hi*.35f + g.whites.coerceIn(-1f,1f)*lum.pow(4)*.25f + g.blacks.coerceIn(-1f,1f)*(1f-lum).pow(4)*.25f
            var b=origB*gain + g.shadows.coerceIn(-1f,1f)*sh*.35f + g.highlights.coerceIn(-1f,1f)*hi*.35f + g.whites.coerceIn(-1f,1f)*lum.pow(4)*.25f + g.blacks.coerceIn(-1f,1f)*(1f-lum).pow(4)*.25f
            r+=g.temperature.coerceIn(-1f,1f)*.12f + g.tint.coerceIn(-1f,1f)*.035f
            gg-=g.tint.coerceIn(-1f,1f)*.045f
            b-=g.temperature.coerceIn(-1f,1f)*.12f + g.tint.coerceIn(-1f,1f)*.035f
            val contrast=1f+g.contrast.coerceIn(-1f,1f)*.8f
            r=((r-.5f)*contrast+.5f).coerceIn(0f,1f); gg=((gg-.5f)*contrast+.5f).coerceIn(0f,1f); b=((b-.5f)*contrast+.5f).coerceIn(0f,1f)
            val l=.2126f*r+.7152f*gg+.0722f*b
            val hsv=FloatArray(3); Color.RGBToHSV((r*255).toInt(),(gg*255).toInt(),(b*255).toInt(),hsv)
            val satMul=(1f+g.saturation.coerceIn(-1f,1f))
            val vibrance=1f+g.vibrance.coerceIn(-1f,1f)*(1f-hsv[1])
            hsv[1]=(hsv[1]*satMul*vibrance).coerceIn(0f,1f)
            val rgb=FloatArray(3); val hsvColor=Color.HSVToColor(hsv)
            rgb[0]=Color.red(hsvColor)/255f; rgb[1]=Color.green(hsvColor)/255f; rgb[2]=Color.blue(hsvColor)/255f
            val balance=(g.balance.coerceIn(-1f,1f))
            val shadowW=((.68f-l+balance*.25f)/.68f).coerceIn(0f,1f)
            val highW=((l-.32f-balance*.25f)/.68f).coerceIn(0f,1f)
            val midW=(1f-shadowW*.65f-highW*.65f).coerceIn(0f,1f)
            wheel(rgb,g.shadowHue,g.shadowAmount*shadowW); wheel(rgb,g.midHue,g.midAmount*midW); wheel(rgb,g.highlightHue,g.highlightAmount*highW)
            output[i]=Color.argb(a,(rgb[0]*255).toInt(),(rgb[1]*255).toInt(),(rgb[2]*255).toInt())
        }
        return Bitmap.createBitmap(output,w,h,Bitmap.Config.ARGB_8888)
    }

    /** Small creative effects that can be stacked manually; no baked-in named looks. */
    fun creativeEffect(source: Bitmap, effect: Int, amount: Float): Bitmap {
        val w=source.width; val h=source.height; val src=IntArray(w*h); source.getPixels(src,0,w,0,0,w,h); val out=IntArray(src.size); val a=amount.coerceIn(0f,1f)
        for(y in 0 until h) for(x in 0 until w){
            val i=y*w+x; val c=src[i]; var r=(c shr 16)and 255; var g=(c shr 8)and 255; var b=c and 255
            when(effect){
                0->{ val lift=(a*22).toInt(); r=(r+lift).coerceAtMost(255);g=(g+lift).coerceAtMost(255);b=(b+lift).coerceAtMost(255) } // matte fade
                1->{ val q=(2f+30f*(1f-a)).coerceAtLeast(2f); r=(r/q).toInt()*(q.toInt());g=(g/q).toInt()*(q.toInt());b=(b/q).toInt()*(q.toInt()) } // posterize
                2->{ val l=(.2126f*r+.7152f*g+.0722f*b); if(l>255f*(1f-a*.65f)){r=(255-r*a).toInt().coerceIn(0,255);g=(255-g*a).toInt().coerceIn(0,255);b=(255-b*a).toInt().coerceIn(0,255)} } // solarize
                3->{ val l=(.2126f*r+.7152f*g+.0722f*b)/255f; val mix=a*.7f; r=(r*(1-mix)+(35+180*l)*mix).toInt();g=(g*(1-mix)+(20+95*l)*mix).toInt();b=(b*(1-mix)+(95+150*l)*mix).toInt() } // duotone blue amber
                4->{ val l=(.2126f*r+.7152f*g+.0722f*b)/255f; val edge=(kotlin.math.abs(l-.5f)*a*70).toInt();r=(r+edge).coerceIn(0,255);g=(g+edge).coerceIn(0,255);b=(b+edge).coerceIn(0,255) } // high-key glow lift
                5->{ val d=(kotlin.math.abs(x-w/2f)+kotlin.math.abs(y-h/2f))/(w+h).toFloat(); val k=(1f-a*d*1.5f).coerceIn(.25f,1f);r=(r*k).toInt();g=(g*k).toInt();b=(b*k).toInt() } // edge burn
                6->{ val gray=(.2126f*r+.7152f*g+.0722f*b).toInt(); val emboss=(if(x>0&&y>0){ val p=src[(y-1)*w+x-1]; ((p shr 16 and 255)+(p shr 8 and 255)+(p and 255))/3-gray }else 0);r=(gray+128+emboss*a*2).toInt().coerceIn(0,255);g=r;b=r } // emboss
                7->{ val gray=(.2126f*r+.7152f*g+.0722f*b).toInt(); val v=(gray*(1-a)+if(gray>128)255*a else 0f).toInt().coerceIn(0,255);r=v;g=v;b=v } // threshold
            }
            out[i]=(c and -0x1000000) or (r.coerceIn(0,255) shl 16) or (g.coerceIn(0,255) shl 8) or b.coerceIn(0,255)
        }
        return Bitmap.createBitmap(out,w,h,Bitmap.Config.ARGB_8888)
    }
    data class CurvePoint(val x: Float, val y: Float)
    enum class BlendMode { NORMAL, MULTIPLY, SCREEN, OVERLAY, LIGHTEN, DARKEN, ADD, DIFFERENCE, SRC_ATOP, XOR }

    fun adjustExposure(source: Bitmap, exposure: Float, highlights: Float = 0f, shadows: Float = 0f, temperature: Float = 0f, tint: Float = 0f): Bitmap {
        val w = source.width; val h = source.height
        val input = IntArray(w * h); source.getPixels(input, 0, w, 0, 0, w, h)
        val output = IntArray(input.size)
        val gain = 2.0.pow(exposure.toDouble()).toFloat()
        for (i in input.indices) {
            val c = input[i]; val a = c ushr 24
            var r = ((c shr 16) and 255) / 255f; var g = ((c shr 8) and 255) / 255f; var b = (c and 255) / 255f
            val lum = .2126f*r + .7152f*g + .0722f*b
            val sh = shadows * (1f-lum).pow(2)
            val hi = highlights * lum.pow(2)
            r = (r*gain + sh + hi + temperature*.12f + tint*.04f).coerceIn(0f,1f)
            g = (g*gain + sh + hi - tint*.035f).coerceIn(0f,1f)
            b = (b*gain + sh + hi - temperature*.12f + tint*.04f).coerceIn(0f,1f)
            output[i] = Color.argb(a, (r*255).toInt(), (g*255).toInt(), (b*255).toInt())
        }
        return Bitmap.createBitmap(output, w, h, Bitmap.Config.ARGB_8888)
    }

    /** HSL adjustments are weighted toward the selected hue so adjacent colors stay natural. */
    fun adjustHsl(source: Bitmap, targetHue: Float, hueShift: Float, saturation: Float, lightness: Float, range: Float = 32f): Bitmap {
        val w=source.width; val h=source.height; val px=IntArray(w*h); source.getPixels(px,0,w,0,0,w,h)
        for (i in px.indices) {
            val c=px[i]; val hsv=FloatArray(3); Color.colorToHSV(c,hsv)
            var d=kotlin.math.abs(hsv[0]-targetHue)%360f; if(d>180f)d=360f-d
            val weight=(1f-d/range.coerceAtLeast(1f)).coerceIn(0f,1f)
            if(weight>0f){ hsv[0]=(hsv[0]+hueShift*weight+360f)%360f; hsv[1]=(hsv[1]+saturation*weight).coerceIn(0f,1f); hsv[2]=(hsv[2]+lightness*weight).coerceIn(0f,1f); px[i]=(c and -0x1000000) or (Color.HSVToColor(hsv) and 0x00ffffff) }
        }
        return Bitmap.createBitmap(px,w,h,Bitmap.Config.ARGB_8888)
    }

    /** Builds a monotonic interpolated RGB tone curve from normalized control points. */
    fun applyCurve(source: Bitmap, points: List<CurvePoint>): Bitmap {
        val sorted=(listOf(CurvePoint(0f,0f))+points+CurvePoint(1f,1f)).sortedBy{it.x}
        val lut=IntArray(256)
        for(v in 0..255){ val x=v/255f; val idx=(0 until sorted.lastIndex).firstOrNull{x<=sorted[it+1].x} ?: sorted.lastIndex-1
            val p=sorted[idx]; val q=sorted[idx+1]; val t=((x-p.x)/(q.x-p.x).coerceAtLeast(.0001f)).coerceIn(0f,1f)
            lut[v]=(255f*(p.y+(q.y-p.y)*t).coerceIn(0f,1f)).toInt() }
        val w=source.width;val h=source.height;val px=IntArray(w*h);source.getPixels(px,0,w,0,0,w,h)
        for(i in px.indices){val c=px[i];px[i]=(c and -0x1000000) or (lut[(c shr 16) and 255] shl 16) or (lut[(c shr 8) and 255] shl 8) or lut[c and 255]}
        return Bitmap.createBitmap(px,w,h,Bitmap.Config.ARGB_8888)
    }

    fun gradientOverlay(source: Bitmap, startColor: Int, endColor: Int, angleDegrees: Float, opacity: Float): Bitmap {
        val out=source.copy(Bitmap.Config.ARGB_8888,true); val c=Canvas(out); val rad=Math.toRadians(angleDegrees.toDouble())
        val cx=out.width/2f;val cy=out.height/2f;val len=max(out.width,out.height).toFloat()/2f
        val dx=(kotlin.math.cos(rad)*len).toFloat();val dy=(kotlin.math.sin(rad)*len).toFloat()
        val p=Paint(Paint.ANTI_ALIAS_FLAG).apply{shader=LinearGradient(cx-dx,cy-dy,cx+dx,cy+dy,startColor,endColor,Shader.TileMode.CLAMP);alpha=(opacity.coerceIn(0f,1f)*255).toInt()}
        c.drawRect(0f,0f,out.width.toFloat(),out.height.toFloat(),p);return out
    }

    /** Keeps only the selected RGB source channels; alpha is preserved for masked compositing. */
    fun selectSourceChannels(source: Bitmap, channelMask: Int): Bitmap {
        if (channelMask and 7 == 7) return source.copy(Bitmap.Config.ARGB_8888, true)
        val w=source.width; val h=source.height; val px=IntArray(w*h); source.getPixels(px,0,w,0,0,w,h)
        for(i in px.indices){ val c=px[i]; val r=if(channelMask and 1 != 0) c and 0x00FF0000 else 0; val g=if(channelMask and 2 != 0) c and 0x0000FF00 else 0; val b=if(channelMask and 4 != 0) c and 0x000000FF else 0; px[i]=(c and -0x1000000) or r or g or b }
        return Bitmap.createBitmap(px,w,h,Bitmap.Config.ARGB_8888)
    }

    fun composite(base: Bitmap, overlay: Bitmap, opacity: Float, mode: BlendMode = BlendMode.NORMAL): Bitmap {
        val out=base.copy(Bitmap.Config.ARGB_8888,true);val c=Canvas(out)
        val p=Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply{alpha=(opacity.coerceIn(0f,1f)*255).toInt();xfermode=PorterDuffXfermode(when(mode){BlendMode.MULTIPLY->PorterDuff.Mode.MULTIPLY;BlendMode.SCREEN->PorterDuff.Mode.SCREEN;BlendMode.OVERLAY->PorterDuff.Mode.OVERLAY;BlendMode.LIGHTEN->PorterDuff.Mode.LIGHTEN;BlendMode.DARKEN->PorterDuff.Mode.DARKEN;BlendMode.ADD->PorterDuff.Mode.ADD;BlendMode.SRC_ATOP->PorterDuff.Mode.SRC_ATOP;BlendMode.XOR->PorterDuff.Mode.XOR;else->PorterDuff.Mode.SRC_OVER});if(mode==BlendMode.DIFFERENCE && android.os.Build.VERSION.SDK_INT>=29){xfermode=null;blendMode=android.graphics.BlendMode.DIFFERENCE}}
        c.drawBitmap(overlay,null,Rect(0,0,out.width,out.height),p);p.xfermode=null;return out
    }

    /** Unsharp-mask style sharpening with a separate strength control. */
    fun sharpen(source: Bitmap, amount: Float): Bitmap {
        val strength = amount.coerceIn(0f, 2f)
        if (strength <= 0.001f) return source.copy(Bitmap.Config.ARGB_8888, true)
        val w=source.width; val h=source.height; val src=IntArray(w*h); source.getPixels(src,0,w,0,0,w,h)
        val out=IntArray(src.size)
        for(y in 0 until h) for(x in 0 until w) {
            val i=y*w+x; val c=src[i]
            fun channel(shift:Int):Int {
                val center=(c shr shift) and 255
                val l=(src[y*w+maxOf(0,x-1)] shr shift) and 255
                val r=(src[y*w+minOf(w-1,x+1)] shr shift) and 255
                val u=(src[maxOf(0,y-1)*w+x] shr shift) and 255
                val d=(src[minOf(h-1,y+1)*w+x] shr shift) and 255
                val blur=(l+r+u+d)/4f
                return (center+(center-blur)*strength).toInt().coerceIn(0,255)
            }
            out[i]=(c and -0x1000000) or (channel(16) shl 16) or (channel(8) shl 8) or channel(0)
        }
        return Bitmap.createBitmap(out,w,h,Bitmap.Config.ARGB_8888)
    }

    /** A soft circular clone/healing stamp. Source and destination are pixel coordinates. */
    fun cloneStamp(source: Bitmap, fromX: Float, fromY: Float, toX: Float, toY: Float, radius: Float, strength: Float = 1f): Bitmap {
        val out=source.copy(Bitmap.Config.ARGB_8888,true);val c=Canvas(out);val r=radius.coerceAtLeast(1f)
        val src=RectF(fromX-r,fromY-r,fromX+r,fromY+r);val dst=RectF(toX-r,toY-r,toX+r,toY+r)
        val p=Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply{alpha=(strength.coerceIn(0f,1f)*255).toInt();shader=android.graphics.BitmapShader(source,Shader.TileMode.CLAMP,Shader.TileMode.CLAMP)}
        val m=android.graphics.Matrix().apply{setTranslate(toX-fromX,toY-fromY)};(p.shader as android.graphics.BitmapShader).setLocalMatrix(m)
        c.save();c.clipCircle(toX,toY,r);c.drawBitmap(source,src,dst,p);c.restore();return out
    }

    fun drawShape(source: Bitmap, kind: String, color: Int, strokeWidth: Float, left: Float, top: Float, right: Float, bottom: Float, filled: Boolean = false): Bitmap {
        val out=source.copy(Bitmap.Config.ARGB_8888,true); val c=Canvas(out)
        val p=Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color=color; style=if(filled) Paint.Style.FILL else Paint.Style.STROKE; this.strokeWidth=strokeWidth.coerceAtLeast(1f) }
        val rect=RectF(left,top,right,bottom)
        val cx=(left+right)/2f; val cy=(top+bottom)/2f
        val path=android.graphics.Path()
        fun polygon(sides:Int, rotation:Float=-Math.PI.toFloat()/2f) {
            for(i in 0 until sides) {
                val a=rotation + (2.0*Math.PI*i/sides).toFloat()
                val x=cx + kotlin.math.cos(a)*rect.width()/2f
                val y=cy + kotlin.math.sin(a)*rect.height()/2f
                if(i==0) path.moveTo(x,y) else path.lineTo(x,y)
            }
            path.close()
        }
        when(kind.lowercase()) {
            "circle", "ellipse" -> c.drawOval(rect,p)
            "line" -> c.drawLine(left,top,right,bottom,p)
            "arrow", "double_arrow" -> {
                c.drawLine(left,top,right,bottom,p)
                val a=kotlin.math.atan2((bottom-top).toDouble(),(right-left).toDouble()); val head=strokeWidth*4f
                fun headAt(x:Float,y:Float,angle:Double) { path.moveTo(x,y); path.lineTo((x-head*kotlin.math.cos(angle-.5)).toFloat(),(y-head*kotlin.math.sin(angle-.5)).toFloat()); path.moveTo(x,y); path.lineTo((x-head*kotlin.math.cos(angle+.5)).toFloat(),(y-head*kotlin.math.sin(angle+.5)).toFloat()) }
                headAt(right,bottom,a); if(kind=="double_arrow") headAt(left,top,a+Math.PI)
                c.drawPath(path,p)
            }
            "rounded_rectangle" -> c.drawRoundRect(rect, min(rect.width(),rect.height())*.16f, min(rect.width(),rect.height())*.16f,p)
            "triangle" -> { polygon(3); c.drawPath(path,p) }
            "diamond" -> { path.moveTo(cx,top); path.lineTo(right,cy); path.lineTo(cx,bottom); path.lineTo(left,cy); path.close(); c.drawPath(path,p) }
            "pentagon" -> { polygon(5); c.drawPath(path,p) }
            "hexagon" -> { polygon(6); c.drawPath(path,p) }
            "octagon" -> { polygon(8); c.drawPath(path,p) }
            "star" -> { for(i in 0 until 10) { val a=(-Math.PI/2 + Math.PI*i/5).toFloat(); val r=if(i%2==0) 1f else .42f; val x=cx+kotlin.math.cos(a)*rect.width()/2f*r; val y=cy+kotlin.math.sin(a)*rect.height()/2f*r; if(i==0) path.moveTo(x,y) else path.lineTo(x,y) }; path.close(); c.drawPath(path,p) }
            "cross" -> { c.drawRect(cx-strokeWidth,top,cx+strokeWidth,bottom,p); c.drawRect(left,cy-strokeWidth,right,cy+strokeWidth,p) }
            "plus" -> { c.drawLine(cx,top,cx,bottom,p); c.drawLine(left,cy,right,cy,p) }
            "heart" -> { path.moveTo(cx,bottom); path.cubicTo(left-strokeWidth,cy,left,top,cx,top+rect.height()*.28f); path.cubicTo(right,top,right+strokeWidth,cy,cx,bottom); c.drawPath(path,p) }
            "speech" -> { c.drawRoundRect(rect,rect.width()*.08f,rect.width()*.08f,p); val tail=android.graphics.Path().apply { moveTo(left+rect.width()*.2f,bottom); lineTo(left+rect.width()*.12f,bottom+rect.height()*.18f); lineTo(left+rect.width()*.38f,bottom) }; c.drawPath(tail,p) }
            else -> c.drawRect(rect,p)
        }
        return out
    }

    /** Draws a custom polygon/path from user supplied points; optional rounded joins use quadratic smoothing. */
    fun drawCustomPath(source: Bitmap, points: List<android.graphics.PointF>, color: Int, strokeWidth: Float, filled: Boolean = false, closed: Boolean = false, roundCorners: Boolean = true): Bitmap {
        if(points.size < 2) return source.copy(Bitmap.Config.ARGB_8888,true)
        val out=source.copy(Bitmap.Config.ARGB_8888,true); val canvas=Canvas(out)
        val path=android.graphics.Path(); path.moveTo(points.first().x,points.first().y)
        if(roundCorners && points.size>2) {
            for(i in 1 until points.size) { val prev=points[i-1]; val cur=points[i]; val mx=(prev.x+cur.x)/2f; val my=(prev.y+cur.y)/2f; path.quadTo(prev.x,prev.y,mx,my) }
            path.lineTo(points.last().x,points.last().y)
        } else points.drop(1).forEach { path.lineTo(it.x,it.y) }
        if(closed) path.close()
        val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color=color; style=if(filled) Paint.Style.FILL else Paint.Style.STROKE; this.strokeWidth=strokeWidth.coerceAtLeast(1f); strokeJoin=Paint.Join.ROUND; strokeCap=Paint.Cap.ROUND }
        canvas.drawPath(path,paint); return out
    }

    /**
     * Fills a user-selected object mask by propagating the nearest unmasked pixels inward.
     * This is an offline classical inpainting fallback, not a generative-AI model.
     */
    fun inpaintMask(source: Bitmap, selectionMask: Bitmap): Bitmap {
        val w=source.width; val h=source.height
        val mask=Bitmap.createScaledBitmap(selectionMask,w,h,true)
        val src=IntArray(w*h); val mp=IntArray(w*h)
        source.getPixels(src,0,w,0,0,w,h); mask.getPixels(mp,0,w,0,0,w,h)
        var minX=w; var minY=h; var maxX=-1; var maxY=-1
        for(y in 0 until h) for(x in 0 until w){if((mp[y*w+x] ushr 24)>24){minX=min(minX,x);minY=min(minY,y);maxX=max(maxX,x);maxY=max(maxY,y)}}
        if(maxX<minX || maxY<minY) return source.copy(Bitmap.Config.ARGB_8888,true)
        val pad=max(12,max(maxX-minX,maxY-minY)/8)
        val x0=max(0,minX-pad); val y0=max(0,minY-pad); val x1=min(w-1,maxX+pad); val y1=min(h-1,maxY+pad)
        val rw=x1-x0+1; val rh=y1-y0+1; val count=rw*rh
        val local=IntArray(count); val dist=IntArray(count){Int.MAX_VALUE}; val queue=IntArray(count)
        var head=0; var tail=0
        for(y in 0 until rh) for(x in 0 until rw){
            val global=(y0+y)*w+(x0+x); val i=y*rw+x; local[i]=src[global]
            if((mp[global] ushr 24)<96){dist[i]=0;queue[tail++]=i}
        }
        if(tail==0) return source.copy(Bitmap.Config.ARGB_8888,true)
        val dxs=intArrayOf(-1,1,0,0); val dys=intArrayOf(0,0,-1,1)
        while(head<tail){val i=queue[head++];val x=i%rw;val y=i/rw
            for(k in 0..3){val nx=x+dxs[k];val ny=y+dys[k];if(nx in 0 until rw && ny in 0 until rh){val ni=ny*rw+nx;if(dist[ni]==Int.MAX_VALUE){dist[ni]=dist[i]+1;local[ni]=local[i];queue[tail++]=ni}}}
        }
        val out=src.copyOf()
        for(y in 0 until rh) for(x in 0 until rw){
            val gi=(y0+y)*w+(x0+x); val a=(mp[gi] ushr 24)/255f
            if(a>0f){val fill=local[y*rw+x];val old=src[gi];val blend=a.coerceIn(0f,1f)
                out[gi]=Color.rgb((Color.red(old)*(1f-blend)+Color.red(fill)*blend).toInt(),(Color.green(old)*(1f-blend)+Color.green(fill)*blend).toInt(),(Color.blue(old)*(1f-blend)+Color.blue(fill)*blend).toInt())
            }
        }
        return Bitmap.createBitmap(out,w,h,Bitmap.Config.ARGB_8888)
    }

    /** Local mask inpainting for small marks. This is an algorithmic repair, not generative AI. */
    fun inpaintCircular(source: Bitmap, centerX: Float, centerY: Float, radius: Float, feather: Float = .18f): Bitmap {
        val w=source.width; val h=source.height
        val src=IntArray(w*h); source.getPixels(src,0,w,0,0,w,h)
        val out=src.copyOf()
        val cx=centerX.toInt().coerceIn(0,w-1); val cy=centerY.toInt().coerceIn(0,h-1)
        val r=radius.toInt().coerceIn(2,max(w,h))
        val x0=max(0,cx-r); val x1=min(w-1,cx+r); val y0=max(0,cy-r); val y1=min(h-1,cy+r)
        val rw=x1-x0+1; val rh=y1-y0+1; val count=rw*rh
        val local=IntArray(count); val distance=IntArray(count){Int.MAX_VALUE}; val queue=IntArray(count)
        var head=0; var tail=0
        for(y in 0 until rh) for(x in 0 until rw) {
            val gx=x0+x; val gy=y0+y; val li=y*rw+x; local[li]=src[gy*w+gx]
            val dx=gx-cx; val dy=gy-cy
            if(dx*dx+dy*dy>=r*r) { distance[li]=0; queue[tail++]=li }
        }
        // Multi-source nearest-pixel propagation, limited to the brush's local rectangle.
        val dxs=intArrayOf(-1,1,0,0); val dys=intArrayOf(0,0,-1,1)
        while(head<tail) {
            val i=queue[head++]; val x=i%rw; val y=i/rw
            for(k in 0..3) {
                val nx=x+dxs[k]; val ny=y+dys[k]
                if(nx in 0 until rw && ny in 0 until rh) {
                    val ni=ny*rw+nx
                    if(distance[ni]==Int.MAX_VALUE) { distance[ni]=distance[i]+1; local[ni]=local[i]; queue[tail++]=ni }
                }
            }
        }
        val band=(r*feather.coerceIn(0f,.5f)).toInt().coerceAtLeast(1)
        for(y in 0 until rh) for(x in 0 until rw) {
            val gx=x0+x; val gy=y0+y; val dx=gx-cx; val dy=gy-cy
            if(dx*dx+dy*dy<r*r) {
                val d=kotlin.math.sqrt((dx*dx+dy*dy).toFloat())
                val edge=((d-(r-band))/band).coerceIn(0f,1f)
                val t=edge*edge*(3f-2f*edge); val i=gy*w+gx; val a=src[i]; val b=local[y*rw+x]
                out[i]=Color.rgb((Color.red(a)*(1f-t)+Color.red(b)*t).toInt(),(Color.green(a)*(1f-t)+Color.green(b)*t).toInt(),(Color.blue(a)*(1f-t)+Color.blue(b)*t).toInt())
            }
        }
        return Bitmap.createBitmap(out,w,h,Bitmap.Config.ARGB_8888)
    }


    /** Perspective correction by mapping a user-adjustable trapezoid back to a rectangle. */
    fun correctPerspective(source: Bitmap, horizontal: Float, vertical: Float): Bitmap {
        val w=source.width.toFloat(); val h=source.height.toFloat()
        val hx=horizontal.coerceIn(-0.22f,0.22f)*w
        val vy=vertical.coerceIn(-0.22f,0.22f)*h
        val src=floatArrayOf(hx,vy, w-hx,0f, w, h-vy, 0f,h-vy)
        val dst=floatArrayOf(0f,0f,w,0f,w,h,0f,h)
        val matrix=android.graphics.Matrix()
        if(!matrix.setPolyToPoly(src,0,dst,0,4)) return source.copy(Bitmap.Config.ARGB_8888,true)
        return Bitmap.createBitmap(source,0,0,source.width,source.height,matrix,true)
    }

    /** Warp a user-defined four-corner quadrilateral into a rectangular, perspective-corrected image. */
    fun correctPerspectiveFourPoint(source: Bitmap, corners: List<androidx.compose.ui.geometry.Offset>): Bitmap {
        if (corners.size != 4) return source.copy(Bitmap.Config.ARGB_8888, true)
        val w = source.width.toFloat(); val h = source.height.toFloat()
        val points = corners.map { androidx.compose.ui.geometry.Offset(it.x.coerceIn(0f, w), it.y.coerceIn(0f, h)) }
        var twiceArea = 0f
        var turnSign = 0
        for (i in 0..3) {
            val a = points[i]; val b = points[(i + 1) % 4]; val c = points[(i + 2) % 4]
            twiceArea += a.x * b.y - b.x * a.y
            val cross = (b.x - a.x) * (c.y - b.y) - (b.y - a.y) * (c.x - b.x)
            if (kotlin.math.abs(cross) > 0.5f) {
                val sign = if (cross > 0f) 1 else -1
                if (turnSign != 0 && sign != turnSign) return source.copy(Bitmap.Config.ARGB_8888, true)
                turnSign = sign
            }
        }
        if (kotlin.math.abs(twiceArea) < w * h * 0.015f || turnSign == 0) return source.copy(Bitmap.Config.ARGB_8888, true)
        val src = FloatArray(8)
        points.forEachIndexed { i, p -> src[i * 2] = p.x; src[i * 2 + 1] = p.y }
        val dst = floatArrayOf(0f, 0f, w, 0f, w, h, 0f, h)
        val matrix = android.graphics.Matrix()
        if (!matrix.setPolyToPoly(src, 0, dst, 0, 4)) return source.copy(Bitmap.Config.ARGB_8888, true)
        return Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
    }

    /** Straighten with expanded rotation followed by a centered crop to the largest safe rectangle. */
    fun straighten(source: Bitmap, degrees: Float): Bitmap {
        if(kotlin.math.abs(degrees)<0.01f) return source.copy(Bitmap.Config.ARGB_8888,true)
        val w=source.width; val h=source.height
        val rotated=Bitmap.createBitmap(source,0,0,w,h,android.graphics.Matrix().apply{postRotate(degrees)},true)
        val a=kotlin.math.abs(Math.toRadians(degrees.toDouble()))
        val sin=kotlin.math.sin(a).toFloat(); val cos=kotlin.math.cos(a).toFloat()
        val cropW=(w*cos-h*sin).let{ if(it>0) it else w*cos }.coerceAtLeast(1f)
        val cropH=(h*cos-w*sin).let{ if(it>0) it else h*cos }.coerceAtLeast(1f)
        val cw=cropW.toInt().coerceIn(1,rotated.width); val ch=cropH.toInt().coerceIn(1,rotated.height)
        return Bitmap.createBitmap(rotated,(rotated.width-cw)/2,(rotated.height-ch)/2,cw,ch)
    }

    /** Texture enhances fine high-frequency detail while clarity targets broader local contrast. */
    fun texture(source: Bitmap, amount: Float): Bitmap {
        val strength=amount.coerceIn(-1f,1f)*0.85f
        if(kotlin.math.abs(strength)<0.001f) return source.copy(Bitmap.Config.ARGB_8888,true)
        val w=source.width; val h=source.height; val src=IntArray(w*h); source.getPixels(src,0,w,0,0,w,h); val out=IntArray(src.size)
        for(y in 0 until h) for(x in 0 until w){
            val i=y*w+x; val c=src[i]; val l=src[y*w+max(0,x-1)]; val r=src[y*w+min(w-1,x+1)]; val u=src[max(0,y-1)*w+x]; val d=src[min(h-1,y+1)*w+x]
            fun ch(shift:Int):Int { val v=(c shr shift) and 255; val avg=(((l shr shift)and 255)+((r shr shift)and 255)+((u shr shift)and 255)+((d shr shift)and 255))/4f; return (v+(v-avg)*strength).toInt().coerceIn(0,255) }
            out[i]=(c and -0x1000000) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
        }
        return Bitmap.createBitmap(out,w,h,Bitmap.Config.ARGB_8888)
    }

    /** Blurs only the white/opaque part of a supplied grayscale/alpha mask. */
    fun selectiveBlur(source: Bitmap, mask: Bitmap, radius: Int = 12): Bitmap {
        val w=source.width; val h=source.height; val small=Bitmap.createScaledBitmap(source,max(1,w/4),max(1,h/4),true)
        val blurred=Bitmap.createScaledBitmap(small,w,h,true); val original=IntArray(w*h); val blurPx=IntArray(w*h); val maskPx=IntArray(w*h)
        source.getPixels(original,0,w,0,0,w,h); blurred.getPixels(blurPx,0,w,0,0,w,h); Bitmap.createScaledBitmap(mask,w,h,true).getPixels(maskPx,0,w,0,0,w,h)
        for(i in original.indices){val a=(maskPx[i] ushr 24);val gray=(((maskPx[i] shr 16) and 255)+((maskPx[i] shr 8) and 255)+(maskPx[i] and 255))/3;val k=max(a,gray)/255f;val x=original[i];val y=blurPx[i];val inv=1f-k;original[i]=Color.argb(255,(((x shr 16 and 255)*inv+(y shr 16 and 255)*k).toInt()),(((x shr 8 and 255)*inv+(y shr 8 and 255)*k).toInt()),(((x and 255)*inv+(y and 255)*k).toInt()))}
        return Bitmap.createBitmap(original,w,h,Bitmap.Config.ARGB_8888)
    }

    /** Built-in cinematic color looks. These are pixel transforms (LUT-style), not imported .cube files. */
    fun cinematicLut(source: Bitmap, look: Int): Bitmap {
        val w=source.width; val h=source.height
        val src=IntArray(w*h); source.getPixels(src,0,w,0,0,w,h); val out=IntArray(src.size)
        val contrast=floatArrayOf(1.12f,1.16f,1.18f,1.08f,1.28f,1.04f)[look.coerceIn(0,5)]
        val sat=floatArrayOf(1.08f,1.12f,.88f,1.16f,.72f,.82f)[look.coerceIn(0,5)]
        for(i in src.indices){
            val c=src[i]; val a=c ushr 24
            var r=((c shr 16) and 255)/255f; var g=((c shr 8) and 255)/255f; var b=(c and 255)/255f
            val l=.2126f*r+.7152f*g+.0722f*b
            when(look.coerceIn(0,5)){
                0,1->{ val sh=(1f-l)*(1f-l); val hi=l*l; r+=.10f*hi-.035f*sh; g+=.025f*hi+.018f*sh; b-=.07f*hi-.10f*sh }
                2->{ val sh=(1f-l)*(1f-l); r-=.035f*sh; g+=.012f*sh; b+=.12f*sh }
                3->{ r+=.075f*l; g+=.025f*l; b-=.045f*l }
                4->{ r=(r-.5f)*1.28f+.5f; g=(g-.5f)*1.28f+.5f; b=(b-.5f)*1.28f+.5f; r=r*.92f+.04f; g=g*.92f+.04f; b=b*.92f+.04f }
                5->{ r=r*.94f+.035f; g=g*.96f+.025f; b=b*.90f+.045f }
            }
            val lum=.2126f*r+.7152f*g+.0722f*b
            r=((lum+(r-lum)*sat-.5f)*contrast+.5f).coerceIn(0f,1f)
            g=((lum+(g-lum)*sat-.5f)*contrast+.5f).coerceIn(0f,1f)
            b=((lum+(b-lum)*sat-.5f)*contrast+.5f).coerceIn(0f,1f)
            out[i]=Color.argb(a,(r*255).toInt(),(g*255).toInt(),(b*255).toInt())
        }
        return Bitmap.createBitmap(out,w,h,Bitmap.Config.ARGB_8888)
    }

    /** Cinematic teal-shadow / warm-highlight grade with contrast, edge falloff and soft highlight bloom. */
    fun cinematicLighting(source: Bitmap, warmth: Float, teal: Float, contrast: Float, vignette: Float, bloom: Float): Bitmap {
        val w=source.width; val h=source.height
        val input=IntArray(w*h); source.getPixels(input,0,w,0,0,w,h)
        val output=IntArray(input.size)
        val cx=w/2f; val cy=h/2f; val maxRadius=kotlin.math.hypot(cx.toDouble(),cy.toDouble()).toFloat().coerceAtLeast(1f)
        val warm=warmth.coerceIn(-1f,1f); val cool=teal.coerceIn(0f,1f); val con=contrast.coerceIn(.5f,2f)
        val edge=vignette.coerceIn(0f,1f); val glow=bloom.coerceIn(0f,1f)
        for(y in 0 until h) for(x in 0 until w){
            val i=y*w+x; val c=input[i]; val a=c ushr 24
            val r=((c shr 16) and 255)/255f; val g=((c shr 8) and 255)/255f; val b=(c and 255)/255f
            val lum=.2126f*r+.7152f*g+.0722f*b
            val shadow=(1f-lum)*(1f-lum)*cool
            val highlight=lum*lum
            var nr=r + warm*.16f*highlight - shadow*.055f
            var ng=g + warm*.045f*highlight + shadow*.035f
            var nb=b - warm*.10f*highlight + shadow*.13f
            nr=((nr-.5f)*con+.5f).coerceIn(0f,1f)
            ng=((ng-.5f)*con+.5f).coerceIn(0f,1f)
            nb=((nb-.5f)*con+.5f).coerceIn(0f,1f)
            val dist=kotlin.math.hypot((x-cx).toDouble(),(y-cy).toDouble()).toFloat()/maxRadius
            val falloff=(1f-edge*dist*dist*.72f).coerceIn(.15f,1f)
            val bloomLift=(highlight*highlight*glow*.22f).coerceIn(0f,.22f)
            nr=(nr*falloff+bloomLift).coerceIn(0f,1f); ng=(ng*falloff+bloomLift*.92f).coerceIn(0f,1f); nb=(nb*falloff+bloomLift*.78f).coerceIn(0f,1f)
            output[i]=Color.argb(a,(nr*255).toInt(),(ng*255).toInt(),(nb*255).toInt())
        }
        return Bitmap.createBitmap(output,w,h,Bitmap.Config.ARGB_8888)
    }

    /** Uses the underlying image luminance to fade the overlay through shadow/highlight ranges. */
    fun blendIfByLuminance(base: Bitmap, overlay: Bitmap, shadowCut: Float, highlightCut: Float, softness: Float): Bitmap {
        val w=overlay.width; val h=overlay.height
        val baseScaled=if(base.width==w && base.height==h) base else Bitmap.createScaledBitmap(base,w,h,true)
        val bp=IntArray(w*h); val op=IntArray(w*h); baseScaled.getPixels(bp,0,w,0,0,w,h); overlay.getPixels(op,0,w,0,0,w,h)
        val low=shadowCut.coerceIn(0f,1f); val high=highlightCut.coerceIn(0f,1f); val soft=softness.coerceIn(.001f,.5f)
        for(i in op.indices){
            val c=bp[i]; val lum=(.2126f*((c shr 16)and 255)+.7152f*((c shr 8)and 255)+.0722f*(c and 255))/255f
            val shadow=((lum-low)/soft).coerceIn(0f,1f); val highlight=((high-lum)/soft).coerceIn(0f,1f)
            val weight=min(shadow,highlight); val a=(op[i] ushr 24)*weight
            op[i]=(op[i] and 0x00FFFFFF) or (a.toInt().coerceIn(0,255) shl 24)
        }
        if(baseScaled!==base) baseScaled.recycle()
        return Bitmap.createBitmap(op,w,h,Bitmap.Config.ARGB_8888)
    }

    fun applyAlphaMask(source: Bitmap, mask: Bitmap): Bitmap {
        val out=source.copy(Bitmap.Config.ARGB_8888,true);val w=out.width;val h=out.height;val mp=Bitmap.createScaledBitmap(mask,w,h,true)
        val a=IntArray(w*h);val m=IntArray(w*h);out.getPixels(a,0,w,0,0,w,h);mp.getPixels(m,0,w,0,0,w,h)
        for(i in a.indices){val alpha=(a[i] ushr 24)*(m[i] ushr 24)/255;a[i]=(a[i] and 0x00ffffff) or (alpha shl 24)}
        out.setPixels(a,0,w,0,0,w,h);return out
    }

    private fun Canvas.clipCircle(x:Float,y:Float,r:Float){ val path=android.graphics.Path().apply { addCircle(x,y,r,android.graphics.Path.Direction.CW) }; clipPath(path) }
}
