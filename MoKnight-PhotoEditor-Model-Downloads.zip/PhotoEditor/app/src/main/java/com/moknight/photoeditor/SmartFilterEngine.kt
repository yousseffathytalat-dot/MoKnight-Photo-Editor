package com.moknight.photoeditor

import android.graphics.Bitmap
import kotlin.math.roundToInt

/** Immutable, editable filter descriptor stored on its owning layer. */
enum class SmartFilterType(val title: String) {
    GAUSSIAN_BLUR("Gaussian Blur"), BLUR("Blur"), SHARPEN("Sharpen"), NOISE("Noise"),
    GRAYSCALE("Grayscale"), BRIGHTNESS("Brightness"), CONTRAST("Contrast"), COLOR_ADJUST("Color Adjustments")
}

data class SmartFilter(
    val id: Long,
    val type: SmartFilterType,
    val amount: Float = 0.5f,
    val enabled: Boolean = true
)

/** CPU bitmap pipeline. The source bitmap is never modified; each enabled filter returns a new bitmap. */
object SmartFilterEngine {
    fun apply(source: Bitmap, filters: List<SmartFilter>): Bitmap {
        var current = source
        var ownsCurrent = false
        filters.filter { it.enabled }.forEach { filter ->
            val next = applyOne(current, filter)
            if (ownsCurrent && current !== next && !current.isRecycled) current.recycle()
            current = next
            ownsCurrent = current !== source
        }
        return current
    }

    private fun applyOne(src: Bitmap, filter: SmartFilter): Bitmap {
        val amount = filter.amount.coerceIn(0f, 1f)
        if (filter.type == SmartFilterType.BLUR || filter.type == SmartFilterType.GAUSSIAN_BLUR) {
            val radius = (1 + amount * if (filter.type == SmartFilterType.BLUR) 5f else 8f).roundToInt()
            if (filter.type == SmartFilterType.BLUR) return boxBlur(src, radius)
            // Three box passes approximate a Gaussian kernel while remaining linear-time.
            val first = boxBlur(src, radius)
            val second = boxBlur(first, radius)
            first.recycle()
            val third = boxBlur(second, radius)
            second.recycle()
            return third
        }
        val w = src.width; val h = src.height
        val input = IntArray(w * h)
        src.getPixels(input, 0, w, 0, 0, w, h)
        val output = input.copyOf()
        when (filter.type) {
            SmartFilterType.GRAYSCALE -> for (i in input.indices) {
                val c=input[i]; val y=(0.2126f*((c ushr 16) and 255)+0.7152f*((c ushr 8) and 255)+0.0722f*(c and 255)).roundToInt()
                fun mix(original: Int) = (original + (y - original) * amount).roundToInt().coerceIn(0,255)
                output[i]=(c and -0x1000000) or (mix((c ushr 16) and 255) shl 16) or
                    (mix((c ushr 8) and 255) shl 8) or mix(c and 255)
            }
            SmartFilterType.BRIGHTNESS, SmartFilterType.CONTRAST, SmartFilterType.COLOR_ADJUST -> {
                val brightness = if(filter.type==SmartFilterType.BRIGHTNESS) (amount-.5f)*180f else if(filter.type==SmartFilterType.COLOR_ADJUST) (amount-.5f)*70f else 0f
                val contrast = if(filter.type==SmartFilterType.CONTRAST) .25f+amount*1.5f else if(filter.type==SmartFilterType.COLOR_ADJUST) .75f+amount*.5f else 1f
                for (i in input.indices) {
                    val c = input[i]
                    fun channel(v: Int): Int = ((v - 127.5f) * contrast + 127.5f + brightness).roundToInt().coerceIn(0, 255)
                    output[i] = (c and -0x1000000) or (channel((c ushr 16) and 255) shl 16) or
                        (channel((c ushr 8) and 255) shl 8) or channel(c and 255)
                }
            }
            SmartFilterType.NOISE -> {
                val seed=filter.id xor 0x5DEECE66DL
                var state=seed
                for (i in input.indices) {
                    state = state * 25214903917L + 11L
                    val noise = ((((state ushr 16) and 255L).toInt() - 127) * amount * .32f).roundToInt()
                    val c = input[i]
                    fun channel(v: Int): Int = (v + noise).coerceIn(0, 255)
                    output[i] = (c and -0x1000000) or (channel((c ushr 16) and 255) shl 16) or
                        (channel((c ushr 8) and 255) shl 8) or channel(c and 255)
                }
            }
            SmartFilterType.SHARPEN -> {
                val strength=amount*1.8f
                for(y in 0 until h) for(x in 0 until w){val i=y*w+x; if(x==0||y==0||x==w-1||y==h-1) continue
                    val c=input[i]; for(shift in intArrayOf(16,8,0)){val center=(c ushr shift) and 255;val avg=(((input[i-1] ushr shift) and 255)+((input[i+1] ushr shift) and 255)+((input[i-w] ushr shift) and 255)+((input[i+w] ushr shift) and 255))/4f;val v=(center+(center-avg)*strength).roundToInt().coerceIn(0,255);output[i]=(output[i] and (255 shl (if(shift==16) 16 else if(shift==8) 8 else 0)).inv()) or (v shl shift)}
                }
            }
            else -> Unit
        }
        return Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888).also { it.setPixels(output,0,w,0,0,w,h) }
    }

    /** Separable sliding-window box blur with bounded radius and O(width*height) work. */
    private fun boxBlur(src: Bitmap, radius: Int): Bitmap {
        val w=src.width; val h=src.height; val input=IntArray(w*h); src.getPixels(input,0,w,0,0,w,h)
        val temp=IntArray(input.size); val out=IntArray(input.size); val r=radius.coerceIn(1,16)
        for(y in 0 until h){var a=0;var rr=0;var g=0;var b=0;var count=0
            for(x in -r until w+r){val add=x+r;if(add in 0 until w){val c=input[y*w+add];a+=c ushr 24;rr+=(c ushr 16) and 255;g+=(c ushr 8) and 255;b+=c and 255;count++};val rem=x-r-1;if(rem in 0 until w){val c=input[y*w+rem];a-=c ushr 24;rr-=(c ushr 16) and 255;g-=(c ushr 8) and 255;b-=c and 255;count--};if(x in 0 until w && count>0)temp[y*w+x]=((a/count) shl 24) or ((rr/count) shl 16) or ((g/count) shl 8) or (b/count)}
        }
        for(x in 0 until w){var a=0;var rr=0;var g=0;var b=0;var count=0
            for(y in -r until h+r){val add=y+r;if(add in 0 until h){val c=temp[add*w+x];a+=c ushr 24;rr+=(c ushr 16) and 255;g+=(c ushr 8) and 255;b+=c and 255;count++};val rem=y-r-1;if(rem in 0 until h){val c=temp[rem*w+x];a-=c ushr 24;rr-=(c ushr 16) and 255;g-=(c ushr 8) and 255;b-=c and 255;count--};if(y in 0 until h && count>0)out[y*w+x]=((a/count) shl 24) or ((rr/count) shl 16) or ((g/count) shl 8) or (b/count)}
        }
        return Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888).also{it.setPixels(out,0,w,0,0,w,h)}
    }
}
