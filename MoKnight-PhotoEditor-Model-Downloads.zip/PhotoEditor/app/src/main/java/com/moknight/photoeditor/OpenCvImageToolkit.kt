package com.moknight.photoeditor

import android.graphics.Bitmap
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Point
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import org.opencv.photo.Photo

/** OpenCV-backed operations. Call initialize() once before using these helpers. */
object OpenCvImageToolkit {
    @Volatile private var ready = false

    @Synchronized
    fun initialize(): Boolean {
        if (ready) return true
        ready = runCatching { OpenCVLoader.initLocal() }.getOrDefault(false)
        return ready
    }

    /** Perspective correction from four source corners to a rectangular output. */
    fun correctPerspective(
        source: Bitmap,
        topLeft: Point,
        topRight: Point,
        bottomRight: Point,
        bottomLeft: Point,
        outputWidth: Int = source.width,
        outputHeight: Int = source.height
    ): Bitmap {
        check(ready) { "OpenCV is not initialized. Call initialize() first." }
        require(outputWidth > 0 && outputHeight > 0)
        val input = Mat()
        val output = Mat()
        val sourcePoints = Mat(4, 1, CvType.CV_32FC2)
        val targetPoints = Mat(4, 1, CvType.CV_32FC2)
        try {
            Utils.bitmapToMat(source.copy(Bitmap.Config.ARGB_8888, false), input)
            sourcePoints.put(0, 0, floatArrayOf(
                topLeft.x.toFloat(), topLeft.y.toFloat(),
                topRight.x.toFloat(), topRight.y.toFloat(),
                bottomRight.x.toFloat(), bottomRight.y.toFloat(),
                bottomLeft.x.toFloat(), bottomLeft.y.toFloat()
            ))
            targetPoints.put(0, 0, floatArrayOf(
                0f, 0f, outputWidth.toFloat() - 1f, 0f,
                outputWidth.toFloat() - 1f, outputHeight.toFloat() - 1f,
                0f, outputHeight.toFloat() - 1f
            ))
            val transform = Imgproc.getPerspectiveTransform(sourcePoints, targetPoints)
            try {
                Imgproc.warpPerspective(input, output, transform, Size(outputWidth.toDouble(), outputHeight.toDouble()))
                val result = Bitmap.createBitmap(outputWidth, outputHeight, Bitmap.Config.ARGB_8888)
                Utils.matToBitmap(output, result)
                return result
            } finally { transform.release() }
        } finally {
            input.release(); output.release(); sourcePoints.release(); targetPoints.release()
        }
    }

    /** Mask-guided object cleanup. White mask pixels are inpainted; mask must match image size. */
    fun removeMarkedObject(source: Bitmap, mask: Bitmap, radius: Double = 3.0): Bitmap {
        check(ready) { "OpenCV is not initialized. Call initialize() first." }
        require(source.width == mask.width && source.height == mask.height) { "Mask size must match image size." }
        val input = Mat(); val maskMat = Mat(); val output = Mat()
        try {
            Utils.bitmapToMat(source.copy(Bitmap.Config.ARGB_8888, false), input)
            Utils.bitmapToMat(mask.copy(Bitmap.Config.ARGB_8888, false), maskMat)
            Imgproc.cvtColor(maskMat, maskMat, Imgproc.COLOR_RGBA2GRAY)
            Photo.inpaint(input, maskMat, output, radius.coerceIn(1.0, 15.0), Photo.INPAINT_TELEA)
            val result = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
            Utils.matToBitmap(output, result)
            return result
        } finally { input.release(); maskMat.release(); output.release() }
    }

    /** Compose-friendly wrapper. Returns null when OpenCV is unavailable or the quad is invalid, so callers can fall back. */
    fun correctPerspectiveOrNull(source: Bitmap, corners: List<androidx.compose.ui.geometry.Offset>): Bitmap? {
        if (corners.size != 4 || !initialize()) return null
        var sign = 0
        for (i in 0..3) {
            val a = corners[i]; val b = corners[(i + 1) % 4]; val c = corners[(i + 2) % 4]
            val cross = (b.x - a.x) * (c.y - b.y) - (b.y - a.y) * (c.x - b.x)
            if (kotlin.math.abs(cross) < 0.5f) return null
            val current = if (cross > 0f) 1 else -1
            if (sign == 0) sign = current else if (sign != current) return null
        }
        val w = source.width.toDouble(); val h = source.height.toDouble()
        fun pt(o: androidx.compose.ui.geometry.Offset) = Point(o.x.toDouble().coerceIn(0.0, w), o.y.toDouble().coerceIn(0.0, h))
        return runCatching { correctPerspective(source, pt(corners[0]), pt(corners[1]), pt(corners[2]), pt(corners[3])) }.getOrNull()
    }
}
