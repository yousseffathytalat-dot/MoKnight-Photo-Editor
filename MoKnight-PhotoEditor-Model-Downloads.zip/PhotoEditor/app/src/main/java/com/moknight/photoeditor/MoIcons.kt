package com.moknight.photoeditor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke as DrawStroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.unit.dp

/**
 * Lightweight, dependency-free vector icon set for MoKnight.
 * All icons use a 24x24 coordinate system, 1.8px rounded strokes.
 * Names are semantic (not glyph characters), so labels/accessibility stay independent.
 */
@Composable
fun MoIcon(name: String, modifier: Modifier = Modifier, tint: Color = MoKnightColors.OnDark) {
    Canvas(modifier.size(24.dp)) {
        val s = size.minDimension / 24f
        scale(s, s, pivot = Offset.Zero) {
            val st = DrawStroke(width = 1.8f, cap = StrokeCap.Round, join = StrokeJoin.Round)
            fun line(x1: Float, y1: Float, x2: Float, y2: Float) =
                drawLine(tint, Offset(x1,y1), Offset(x2,y2), 1.8f, cap = StrokeCap.Round)
            fun circle(x: Float, y: Float, r: Float, fill: Boolean = false) =
                drawCircle(tint, r, Offset(x,y), style = if (fill) androidx.compose.ui.graphics.drawscope.Fill else st)
            fun rect(l: Float,t: Float,r: Float,b: Float, radius: Float = 2f, fill: Boolean = false) =
                drawRoundRect(tint, Offset(l,t), Size(r-l,b-t), androidx.compose.ui.geometry.CornerRadius(radius),
                    style = if (fill) androidx.compose.ui.graphics.drawscope.Fill else st)
            fun path(vararg pts: Float) {
                val p = Path()
                if (pts.size >= 4) {
                    p.moveTo(pts[0], pts[1])
                    var i=2
                    while (i+1<pts.size) { p.lineTo(pts[i],pts[i+1]); i+=2 }
                    drawPath(p,tint,style=st)
                }
            }
            when (name) {
                "home" -> { path(3f,11f,12f,3f,21f,11f); path(5f,10f,5f,21f,19f,21f,19f,10f); rect(10f,14f,14f,21f,1f) }
                "plus" -> { line(12f,4f,12f,20f); line(4f,12f,20f,12f) }
                "info" -> { circle(12f,12f,9f); circle(12f,8f,1f,true); line(12f,11f,12f,17f) }
                "folder" -> { path(3f,7f,3f,19f,21f,19f,21f,7f,13f,7f,11f,5f,3f,5f,3f,7f) }
                "settings" -> { circle(12f,12f,3f); circle(12f,12f,8f); line(12f,2f,12f,4f); line(12f,20f,12f,22f); line(2f,12f,4f,12f); line(20f,12f,22f,12f); line(5f,5f,6.5f,6.5f); line(17.5f,17.5f,19f,19f); line(19f,5f,17.5f,6.5f); line(6.5f,17.5f,5f,19f) }
                "open" -> { rect(3f,5f,21f,20f); path(3f,5f,3f,3f,15f,3f,17f,5f); line(12f,14f,12f,7f); path(8f,11f,12f,7f,16f,11f) }
                "undo" -> { path(9f,7f,4f,12f,9f,17f); path(4f,12f,14f,12f,19f,17f,19f,20f) }
                "redo" -> { path(15f,7f,20f,12f,15f,17f); path(20f,12f,10f,12f,5f,17f,5f,20f) }
                "zoom-in" -> { circle(10.5f,10.5f,6.5f); line(15.5f,15.5f,21f,21f); line(10.5f,7f,10.5f,14f); line(7f,10.5f,14f,10.5f) }
                "zoom-out" -> { circle(10.5f,10.5f,6.5f); line(15.5f,15.5f,21f,21f); line(7f,10.5f,14f,10.5f) }
                "fit" -> { path(8f,3f,3f,3f,3f,8f); path(16f,3f,21f,3f,21f,8f); path(3f,16f,3f,21f,8f,21f); path(21f,16f,21f,21f,16f,21f) }
                "more" -> { circle(5f,12f,1.2f,true); circle(12f,12f,1.2f,true); circle(19f,12f,1.2f,true) }
                "sun" -> { circle(12f,12f,4f); line(12f,2f,12f,5f); line(12f,19f,12f,22f); line(2f,12f,5f,12f); line(19f,12f,22f,12f); line(5f,5f,7f,7f); line(17f,17f,19f,19f); line(19f,5f,17f,7f); line(7f,17f,5f,19f) }
                "crop" -> { path(8f,3f,8f,16f,21f,16f); path(3f,8f,16f,8f,16f,21f) }
                "adjust" -> { line(4f,6f,20f,6f); circle(9f,6f,2f,true); line(4f,12f,20f,12f); circle(15f,12f,2f,true); line(4f,18f,20f,18f); circle(11f,18f,2f,true) }
                "filter" -> { path(3f,4f,21f,4f,14f,12f,14f,20f,10f,22f,10f,12f,3f,4f) }
                "curves" -> { path(3f,19f,7f,15f,10f,16f,14f,8f,18f,9f,21f,4f); line(3f,3f,3f,21f); line(3f,21f,21f,21f) }
                "layers" -> { path(12f,3f,21f,8f,12f,13f,3f,8f,12f,3f); path(3f,12f,12f,17f,21f,12f); path(3f,16f,12f,21f,21f,16f) }
                "text" -> { line(4f,5f,20f,5f); line(12f,5f,12f,20f); line(8f,20f,16f,20f) }
                "draw" -> { path(4f,17f,3f,21f,7f,20f,19f,8f,16f,5f,4f,17f); line(14f,7f,17f,10f) }
                "shapes" -> { path(12f,3f,21f,20f,3f,20f,12f,3f); circle(12f,12f,2f) }
                "mask" -> { rect(3f,3f,21f,21f); path(12f,3f,12f,21f); path(12f,3f,18f,6f,21f,12f,18f,18f,12f,21f) }
                "ai" -> { circle(12f,12f,3f); path(12f,2f,12f,7f); path(12f,17f,12f,22f); path(2f,12f,7f,12f); path(17f,12f,22f,12f); path(5f,5f,8f,8f); path(16f,16f,19f,19f); path(19f,5f,16f,8f); path(8f,16f,5f,19f) }
                "heal" -> { line(12f,3f,12f,21f); line(3f,12f,21f,12f); line(5.5f,5.5f,18.5f,18.5f); line(18.5f,5.5f,5.5f,18.5f) }
                "rotate" -> { path(20f,10f,18f,5f,13f,3f,7f,4f,4f,9f,4f,14f,7f,18f,12f,20f,17f,18f); path(16f,4f,20f,4f,20f,8f) }
                "move" -> { path(12f,2f,9f,6f,15f,6f,12f,2f); path(12f,22f,9f,18f,15f,18f,12f,22f); path(2f,12f,6f,9f,6f,15f,2f,12f); path(22f,12f,18f,9f,18f,15f,22f,12f); line(12f,6f,12f,18f); line(6f,12f,18f,12f) }
                "gradient" -> { rect(3f,5f,21f,19f); line(4f,8f,20f,8f); line(4f,12f,20f,12f); line(4f,16f,20f,16f) }
                "effects" -> { path(12f,2f,14f,9f,21f,12f,14f,14f,12f,22f,10f,14f,3f,12f,10f,9f,12f,2f) }
                "flare" -> { circle(12f,12f,3f); path(12f,2f,12f,7f); path(12f,17f,12f,22f); path(2f,12f,7f,12f); path(17f,12f,22f,12f); line(5f,5f,7f,7f); line(17f,17f,19f,19f) }
                "background" -> { rect(3f,3f,21f,21f); circle(8f,8f,1.5f,true); path(4f,18f,9f,12f,13f,16f,16f,13f,20f,18f) }
                "selection" -> { path(4f,4f,8f,4f); path(12f,4f,16f,4f); path(20f,4f,20f,8f); path(20f,12f,20f,16f); path(20f,20f,16f,20f); path(12f,20f,8f,20f); path(4f,20f,4f,16f); path(4f,12f,4f,8f) }
                "save" -> { path(4f,3f,18f,3f,21f,6f,21f,21f,3f,21f,3f,3f,4f,3f); rect(7f,3f,17f,10f); rect(7f,14f,17f,21f) }
                "close" -> { line(5f,5f,19f,19f); line(19f,5f,5f,19f) }
                "eye" -> { path(2f,12f,5f,7f,9f,4f,12f,3f,15f,4f,19f,7f,22f,12f,19f,17f,15f,20f,12f,21f,9f,20f,5f,17f,2f,12f); circle(12f,12f,3f) }
                "eye-off" -> { path(3f,12f,6f,8f,10f,6f,13f,6f,18f,9f,21f,12f); line(4f,4f,20f,20f); path(3f,14f,7f,18f,12f,20f,17f,18f) }
                "lock" -> { rect(5f,10f,19f,21f); path(8f,10f,8f,7f,10f,4f,14f,4f,16f,7f,16f,10f); circle(12f,15f,1f,true) }
                "arrow-up" -> { path(4f,14f,12f,6f,20f,14f); line(12f,6f,12f,21f) }
                "arrow-down" -> { path(4f,10f,12f,18f,20f,10f); line(12f,3f,12f,18f) }
                "duplicate" -> { rect(7f,7f,20f,20f); path(4f,16f,3f,16f,3f,4f,16f,4f,16f,5f) }
                "compare" -> { line(12f,3f,12f,21f); path(9f,6f,5f,6f,5f,18f,9f,18f); path(15f,6f,19f,6f,19f,18f,15f,18f) }
                else -> { circle(12f,12f,8f); circle(12f,12f,1.5f,true) }
            }
        }
    }
}
