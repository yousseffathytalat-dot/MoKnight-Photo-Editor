package com.moknight.photoeditor

import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView

/** HTML/CSS text-layer preview. HTML is loaded locally; JavaScript stays disabled. */
@Composable
fun HtmlTextLayerPreview(
    html: String,
    modifier: Modifier = Modifier,
    backgroundColor: String = "#00000000"
) {
    AndroidView(
        modifier = modifier,
        factory = { context ->
            WebView(context).apply {
                settings.javaScriptEnabled = false
                settings.domStorageEnabled = false
                webViewClient = WebViewClient()
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            }
        },
        update = { webView ->
            val safeBackground = backgroundColor.filter { it.isLetterOrDigit() || it == '#' }
            val document = """
                <!doctype html><html><head><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
                <style>html,body{margin:0;padding:0;background:$safeBackground;color:white;overflow:hidden;}
                body{font-family:Arial,sans-serif;} img{max-width:100%;height:auto;}</style></head>
                <body>$html</body></html>
            """.trimIndent()
            webView.loadDataWithBaseURL("https://localhost/", document, "text/html", "UTF-8", null)
        }
    )
}
