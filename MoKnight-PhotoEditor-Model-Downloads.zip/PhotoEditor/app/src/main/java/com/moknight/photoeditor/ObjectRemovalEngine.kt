package com.moknight.photoeditor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import org.tensorflow.lite.DataType
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.Tensor
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executors

/**
 * Mobile-first LaMa-Dilated INT8 object removal.
 *
 * Model contract published by the model card:
 * image [1,512,512,3] uint8 RGB, mask [1,512,512,1] uint8, output [1,512,512,3] uint8.
 */
object ObjectRemovalEngine {
    private const val SIZE = 512
    private val worker = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    fun remove(
        context: Context,
        source: Bitmap,
        mask: Bitmap,
        onProgress: (String) -> Unit,
        onResult: (Result<Bitmap>) -> Unit
    ) {
        val app = context.applicationContext
        worker.execute {
            val result = runCatching {
                val model = AiModelManager.objectRemoval
                if (!AiModelManager.isInstalled(app, model)) {
                    main.post { onProgress("تنزيل LaMa-Dilated INT8 (حوالي 44 MB)…") }
                    AiModelManager.downloadBlocking(app, model) { p -> main.post { onProgress(p) } }
                }
                main.post { onProgress("النموذج جاهز. جاري إزالة العنصر محليًا…") }
                runInference(app, source, mask)
            }
            main.post { onResult(result) }
        }
    }

    private fun runInference(context: Context, source: Bitmap, selection: Bitmap): Bitmap {
        val modelFile = File(AiModelManager.directory(context, AiModelManager.objectRemoval), "lama_int8.tflite")
        require(modelFile.exists()) { "نموذج إزالة العناصر غير موجود" }
        val interpreter = Interpreter(modelFile, Interpreter.Options().apply { setNumThreads(4) })
        try {
            val image = Bitmap.createScaledBitmap(source, SIZE, SIZE, true)
            val mask = Bitmap.createScaledBitmap(selection, SIZE, SIZE, true)
            val inputImage = ByteBuffer.allocateDirect(SIZE * SIZE * 3).order(ByteOrder.nativeOrder())
            val inputMask = ByteBuffer.allocateDirect(SIZE * SIZE).order(ByteOrder.nativeOrder())
            val imagePixels = IntArray(SIZE * SIZE)
            val maskPixels = IntArray(SIZE * SIZE)
            image.getPixels(imagePixels, 0, SIZE, 0, 0, SIZE, SIZE)
            mask.getPixels(maskPixels, 0, SIZE, 0, 0, SIZE, SIZE)
            imagePixels.forEach { p -> inputImage.put(Color.red(p).toByte()); inputImage.put(Color.green(p).toByte()); inputImage.put(Color.blue(p).toByte()) }
            maskPixels.forEach { p -> inputMask.put(if ((p ushr 24) > 20 || Color.red(p) > 20) 255.toByte() else 0.toByte()) }
            inputImage.rewind(); inputMask.rewind()
            val out = Array(1) { Array(SIZE) { Array(SIZE) { ByteArray(3) } } }
            val inputs = arrayOf(inputImage, inputMask)
            val imageInputIndex = findInputIndex(interpreter, 3)
            val maskInputIndex = findInputIndex(interpreter, 1, imageInputIndex)
            val ordered = arrayOfNulls<Any>(interpreter.inputTensorCount)
            ordered[imageInputIndex] = inputImage
            ordered[maskInputIndex] = inputMask
            interpreter.runForMultipleInputsOutputs(ordered.filterNotNull().toTypedArray(), mapOf(0 to out))
            val pixels = IntArray(SIZE * SIZE)
            for (y in 0 until SIZE) for (x in 0 until SIZE) {
                val c = out[0][y][x]
                pixels[y * SIZE + x] = Color.rgb(c[0].toInt() and 0xff, c[1].toInt() and 0xff, c[2].toInt() and 0xff)
            }
            val generated = Bitmap.createBitmap(pixels, SIZE, SIZE, Bitmap.Config.ARGB_8888)
            val fullMask = Bitmap.createScaledBitmap(selection, source.width, source.height, true)
            val fill = Bitmap.createScaledBitmap(generated, source.width, source.height, true)
            val srcPixels = IntArray(source.width * source.height)
            val fillPixels = IntArray(source.width * source.height)
            val alpha = IntArray(source.width * source.height)
            source.getPixels(srcPixels, 0, source.width, 0, 0, source.width, source.height)
            fill.getPixels(fillPixels, 0, source.width, 0, 0, source.width, source.height)
            fullMask.getPixels(alpha, 0, source.width, 0, 0, source.width, source.height)
            for (i in srcPixels.indices) {
                val a = ((alpha[i] ushr 24) and 255) / 255f
                if (a <= 0f) continue
                val o = srcPixels[i]; val n = fillPixels[i]
                srcPixels[i] = Color.rgb(
                    (Color.red(o) * (1f - a) + Color.red(n) * a).toInt(),
                    (Color.green(o) * (1f - a) + Color.green(n) * a).toInt(),
                    (Color.blue(o) * (1f - a) + Color.blue(n) * a).toInt()
                )
            }
            image.recycle(); mask.recycle(); generated.recycle(); fill.recycle(); fullMask.recycle()
            return Bitmap.createBitmap(srcPixels, source.width, source.height, Bitmap.Config.ARGB_8888)
        } finally {
            interpreter.close()
        }
    }

    private fun findInputIndex(interpreter: Interpreter, channels: Int, except: Int = -1): Int {
        for (i in 0 until interpreter.inputTensorCount) {
            if (i == except) continue
            val shape = interpreter.getInputTensor(i).shape()
            if (shape.isNotEmpty() && shape.lastOrNull() == channels) return i
            if (channels == 1 && shape.contentEquals(intArrayOf(1, SIZE, SIZE))) return i
        }
        // Published contract is image then mask.
        return if (except == 0) 1 else 0
    }
}
