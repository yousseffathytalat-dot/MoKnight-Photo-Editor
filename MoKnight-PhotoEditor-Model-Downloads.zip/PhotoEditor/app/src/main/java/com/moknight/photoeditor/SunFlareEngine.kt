package com.moknight.photoeditor

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/**
 * Renders a sun / lens-flare light onto a transparent bitmap the same size as the photo.
 * The result is added to the editor as an independent [BitmapLayer] (SCREEN blend), so it can be
 * moved, scaled, rotated, re-blended and masked from the layers panel like any other layer.
 */
object SunFlareEngine {
    data class Params(
        val x: Float = 0.75f,            // 0..1 across the image
        val y: Float = 0.2f,             // 0..1 down the image
        val size: Float = 0.35f,         // core glow radius as fraction of image diagonal
        val intensity: Float = 0.9f,     // 0..1.5
        val softness: Float = 0.6f,      // 0..1, spread of the halo
        val temperatureK: Float = 5800f, // light color temperature
        val opacity: Float = 1f,
        val rays: Int = 0,               // 0 = no rays
        val rayAngle: Float = 0f,        // degrees
        val rayLength: Float = 0.8f,     // 0..1 relative to diagonal
        val flareCircles: Int = 0        // lens ghost circles along the axis through the center
    )

    /** Approximate black-body color (Tanner Helland), clamped 1500K..12000K. */
    fun kelvinToColor(kelvin: Float): Int {
        val t = kelvin.coerceIn(1500f, 12000f) / 100.0
        val r = if (t <= 66) 255.0 else (329.698727446 * (t - 60).pow(-0.1332047592)).coerceIn(0.0, 255.0)
        val g = if (t <= 66) (99.4708025861 * ln(t) - 161.1195681661).coerceIn(0.0, 255.0)
        else (288.1221695283 * (t - 60).pow(-0.0755148492)).coerceIn(0.0, 255.0)
        val b = when {
            t >= 66 -> 255.0
            t <= 19 -> 0.0
            else -> (138.5177312231 * ln(t - 10) - 305.0447927307).coerceIn(0.0, 255.0)
        }
        return Color.rgb(r.toInt(), g.toInt(), b.toInt())
    }

    private fun withAlpha(color: Int, a: Float) =
        Color.argb((a.coerceIn(0f, 1f) * 255f).toInt(), Color.red(color), Color.green(color), Color.blue(color))

    /** Output is capped to [maxSide] to limit memory; the layer is stretched to the photo when composited. */
    fun render(width: Int, height: Int, p: Params, maxSide: Int = 2048): Bitmap {
        val scale = min(1f, maxSide.toFloat() / max(width, height))
        val w = max(1, (width * scale).toInt()); val h = max(1, (height * scale).toInt())
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val diag = hypot(w.toFloat(), h.toFloat())
        val cx = p.x * w; val cy = p.y * h
        val tint = kelvinToColor(p.temperatureK)
        val white = Color.WHITE
        val k = p.intensity.coerceIn(0f, 1.5f)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        // 1) wide soft halo (spread controlled by softness)
        val haloR = max(2f, diag * p.size * (1f + p.softness * 2.2f))
        paint.shader = RadialGradient(cx, cy, haloR,
            intArrayOf(withAlpha(tint, .55f * k), withAlpha(tint, .22f * k), withAlpha(tint, .06f * k), 0),
            floatArrayOf(0f, .25f, .6f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, haloR, paint)

        // 2) rays: tapered wedges with a gradient that fades with distance
        if (p.rays > 0) {
            val len = diag * p.rayLength.coerceIn(.05f, 1.5f)
            val wedge = (PI / (p.rays * 2.6)).toFloat() * (1f - p.softness * .5f)
            val rp = Paint(Paint.ANTI_ALIAS_FLAG)
            for (i in 0 until p.rays) {
                // deterministic pseudo-random variation so rays are not uniform
                val jitter = ((i * 7919) % 100) / 100f
                val a = Math.toRadians(p.rayAngle.toDouble()).toFloat() + (2f * PI.toFloat() * i / p.rays)
                val l = len * (.55f + .45f * jitter)
                val ex = cx + cos(a) * l; val ey = cy + sin(a) * l
                rp.shader = LinearGradient(cx, cy, ex, ey,
                    withAlpha(tint, .42f * k * (.5f + .5f * jitter)), 0, Shader.TileMode.CLAMP)
                val path = Path().apply {
                    moveTo(cx, cy)
                    lineTo(cx + cos(a - wedge) * l, cy + sin(a - wedge) * l)
                    lineTo(cx + cos(a + wedge) * l, cy + sin(a + wedge) * l)
                    close()
                }
                c.drawPath(path, rp)
            }
        }

        // 3) lens ghosts along the line from the light through the image center
        if (p.flareCircles > 0) {
            val ax = w / 2f - cx; val ay = h / 2f - cy
            val gp = Paint(Paint.ANTI_ALIAS_FLAG)
            for (i in 1..p.flareCircles) {
                val t = .35f + i * (1.9f / (p.flareCircles + 1))
                val gx = cx + ax * t; val gy = cy + ay * t
                val gr = diag * (.015f + .035f * (((i * 37) % 10) / 10f + .3f))
                val gc = if (i % 2 == 0) tint else Color.rgb(
                    (Color.red(tint) * .6f + 90).toInt().coerceAtMost(255),
                    (Color.green(tint) * .8f).toInt(), 255)
                gp.shader = RadialGradient(gx, gy, gr,
                    intArrayOf(withAlpha(gc, .02f * k), withAlpha(gc, .12f * k), withAlpha(gc, .30f * k), 0),
                    floatArrayOf(0f, .7f, .92f, 1f), Shader.TileMode.CLAMP)
                c.drawCircle(gx, gy, gr, gp)
            }
        }

        // 4) hot core
        val coreR = max(2f, diag * p.size * .22f)
        paint.shader = RadialGradient(cx, cy, coreR,
            intArrayOf(withAlpha(white, min(1f, k)), withAlpha(white, .85f * min(1f, k)), withAlpha(tint, .3f * k), 0),
            floatArrayOf(0f, .25f, .7f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, coreR, paint)

        // global opacity of the rendered light
        if (p.opacity < 1f) {
            val faded = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            Canvas(faded).drawBitmap(out, 0f, 0f, Paint().apply { alpha = (p.opacity.coerceIn(0f, 1f) * 255).toInt() })
            out.recycle(); return faded
        }
        return out
    }
}
