package com.moknight.photoeditor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.framework.image.ByteBufferExtractor
import com.google.mediapipe.framework.image.MPImage
import com.google.mediapipe.tasks.components.containers.NormalizedKeypoint
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.imagesegmenter.ImageSegmenter
import com.google.mediapipe.tasks.vision.imagesegmenter.ImageSegmenterResult
import com.google.mediapipe.tasks.vision.imagesegmenter.ImageSegmenter.ImageSegmenterOptions
import com.google.mediapipe.tasks.vision.interactivesegmenter.InteractiveSegmenter
import com.google.mediapipe.tasks.vision.interactivesegmenter.InteractiveSegmenter.RegionOfInterest
import java.nio.ByteOrder
import java.util.concurrent.Executors

/** Offline MediaPipe models. Model files are fetched by the Gradle preBuild task and packaged in assets. */
object MediaPipeOfflineModels {
    private val worker = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    fun selectObjectAt(context: Context, source: Bitmap, x: Float, y: Float, callback: (Result<Bitmap>) -> Unit) {
        worker.execute {
            val result = runCatching {
                val options = InteractiveSegmenter.InteractiveSegmenterOptions.builder()
                    .setBaseOptions(BaseOptions.builder().setModelAssetPath("magic_touch.tflite").build())
                    .build()
                val segmenter = InteractiveSegmenter.createFromOptions(context, options)
                val image = BitmapImageBuilder(source).build()
                try {
                    val roi = RegionOfInterest.create(
                        NormalizedKeypoint.create(
                            (x / source.width).coerceIn(0f, 1f),
                            (y / source.height).coerceIn(0f, 1f)
                        )
                    )
                    val segmented = segmenter.segment(image, roi)
                    try {
                        confidenceMaskToBitmap(segmented, source.width, source.height)
                    } finally {
                        segmented.confidenceMasks().ifPresent { masks -> masks.forEach { it.close() } }
                        segmented.categoryMask().ifPresent { it.close() }
                    }
                } finally {
                    image.close()
                    segmenter.close()
                }
            }
            main.post { callback(result) }
        }
    }

    fun segmentHair(context: Context, source: Bitmap, callback: (Result<Bitmap>) -> Unit) {
        worker.execute {
            val result = runCatching {
                val options = ImageSegmenterOptions.builder()
                    .setBaseOptions(BaseOptions.builder().setModelAssetPath("hair_segmenter.tflite").build())
                    .setRunningMode(RunningMode.IMAGE)
                    .setOutputCategoryMask(false)
                    .setOutputConfidenceMasks(true)
                    .build()
                val segmenter = ImageSegmenter.createFromOptions(context, options)
                val image = BitmapImageBuilder(source).build()
                try {
                    val segmented = segmenter.segment(image)
                    try {
                        val masks = segmented.confidenceMasks().orElseThrow { IllegalStateException("Hair model returned no confidence masks") }
                        // HairSegmenter labels are [background, hair].
                        val hair = masks.getOrNull(1) ?: masks.lastOrNull()
                            ?: throw IllegalStateException("Hair mask is missing")
                        floatMaskToBitmap(hair, source.width, source.height)
                    } finally {
                        segmented.confidenceMasks().ifPresent { masks -> masks.forEach { it.close() } }
                        segmented.categoryMask().ifPresent { it.close() }
                    }
                } finally {
                    image.close()
                    segmenter.close()
                }
            }
            main.post { callback(result) }
        }
    }

    private fun confidenceMaskToBitmap(result: ImageSegmenterResult, width: Int, height: Int): Bitmap {
        val masks = result.confidenceMasks().orElse(null)
        if (!masks.isNullOrEmpty()) {
            // Interactive binary segmentation returns a foreground confidence channel.
            return floatMaskToBitmap(masks.last(), width, height)
        }
        val category = result.categoryMask().orElseThrow { IllegalStateException("No segmentation mask returned") }
        val buffer = ByteBufferExtractor.extract(category).duplicate()
        val pixels = IntArray(category.width * category.height)
        for (i in pixels.indices) {
            val value = if (buffer.hasRemaining()) buffer.get().toInt() and 0xff else 0
            val alpha = if (value > 0) 255 else 0
            pixels[i] = (alpha shl 24) or Color.WHITE
        }
        val raw = Bitmap.createBitmap(pixels, category.width, category.height, Bitmap.Config.ARGB_8888)
        return Bitmap.createScaledBitmap(raw, width, height, true)
    }

    private fun floatMaskToBitmap(mask: MPImage, width: Int, height: Int): Bitmap {
        val buffer = ByteBufferExtractor.extract(mask, MPImage.IMAGE_FORMAT_VEC32F1)
            .order(ByteOrder.nativeOrder()).asFloatBuffer()
        val pixels = IntArray(mask.width * mask.height)
        for (i in pixels.indices) {
            val confidence = if (buffer.hasRemaining()) buffer.get().coerceIn(0f, 1f) else 0f
            val alpha = (confidence * 255f).toInt()
            pixels[i] = (alpha shl 24) or Color.WHITE
        }
        val raw = Bitmap.createBitmap(pixels, mask.width, mask.height, Bitmap.Config.ARGB_8888)
        return Bitmap.createScaledBitmap(raw, width, height, true)
    }
}
