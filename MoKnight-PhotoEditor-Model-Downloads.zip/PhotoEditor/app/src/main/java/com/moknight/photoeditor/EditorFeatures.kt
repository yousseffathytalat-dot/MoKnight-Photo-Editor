package com.moknight.photoeditor

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Reusable local editing primitives for MoKnight Photo Editor.
 * These functions operate on-device and do not require a network connection.
 */
object EditorFeatures {
    enum class LayerKind { IMAGE, TEXT, SHAPE, DRAWING, ADJUSTMENT }

    data class Layer(
        val id: Long,
        val name: String,
        val kind: LayerKind,
        val bitmap: Bitmap? = null,
        val text: String? = null,
        val visible: Boolean = true,
        val opacity: Float = 1f,
        val offsetX: Float = 0f,
        val offsetY: Float = 0f,
        val blendMode: AdvancedImageOps.BlendMode = AdvancedImageOps.BlendMode.NORMAL
    )

    /** Composite a visible ordered layer stack into a new bitmap. */
    fun renderLayers(width: Int, height: Int, layers: List<Layer>): Bitmap {
        val out = Bitmap.createBitmap(width.coerceAtLeast(1), height.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        layers.filter { it.visible && it.bitmap != null }.forEach { layer ->
            val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                alpha = (layer.opacity.coerceIn(0f, 1f) * 255f).toInt()
                xfermode = PorterDuffXfermode(when (layer.blendMode) {
                    AdvancedImageOps.BlendMode.MULTIPLY -> PorterDuff.Mode.MULTIPLY
                    AdvancedImageOps.BlendMode.SCREEN -> PorterDuff.Mode.SCREEN
                    AdvancedImageOps.BlendMode.OVERLAY -> PorterDuff.Mode.OVERLAY
                    AdvancedImageOps.BlendMode.LIGHTEN -> PorterDuff.Mode.LIGHTEN
                    AdvancedImageOps.BlendMode.DARKEN -> PorterDuff.Mode.DARKEN
                    AdvancedImageOps.BlendMode.ADD -> PorterDuff.Mode.ADD
                    AdvancedImageOps.BlendMode.SRC_ATOP -> PorterDuff.Mode.SRC_ATOP
                    AdvancedImageOps.BlendMode.XOR -> PorterDuff.Mode.XOR
                    else -> PorterDuff.Mode.SRC_OVER
                })
            }
            val b = layer.bitmap!!
            if (layer.blendMode == AdvancedImageOps.BlendMode.DIFFERENCE && android.os.Build.VERSION.SDK_INT >= 29) paint.blendMode = android.graphics.BlendMode.DIFFERENCE
            canvas.drawBitmap(b, layer.offsetX, layer.offsetY, paint)
            paint.xfermode = null
            if (android.os.Build.VERSION.SDK_INT >= 29) paint.blendMode = null
        }
        return out
    }

    /** Paint white/black on a grayscale mask. Coordinates and radius are bitmap pixels. */
    fun paintMask(mask: Bitmap, x: Float, y: Float, radius: Float, add: Boolean, hardness: Float = 0.65f): Bitmap {
        val out = mask.copy(Bitmap.Config.ARGB_8888, true)
        val w=out.width; val h=out.height; val pixels=IntArray(w*h); out.getPixels(pixels,0,w,0,0,w,h)
        val r=radius.coerceAtLeast(1f); val hard=hardness.coerceIn(0f,.99f)
        val left=max(0,(x-r).toInt()); val right=min(w-1,(x+r).toInt())
        val top=max(0,(y-r).toInt()); val bottom=min(h-1,(y+r).toInt())
        for(py in top..bottom) for(px in left..right) {
            val d=kotlin.math.sqrt((px-x)*(px-x)+(py-y)*(py-y))
            if(d<=r) {
                val t=((d/r-hard)/(1f-hard).coerceAtLeast(.001f)).coerceIn(0f,1f)
                val coverage=(1f-t).let { it*it*(3f-2f*it) }
                val i=py*w+px; val old=pixels[i] ushr 24
                val next=if(add) max(old,(coverage*255).toInt()) else (old*(1f-coverage)).toInt()
                pixels[i]=(next shl 24) or 0x00FFFFFF
            }
        }
        out.setPixels(pixels,0,w,0,0,w,h)
        return out
    }

    fun featherMask(mask: Bitmap, amount: Float): Bitmap {
        val scale = (1f - amount.coerceIn(0f, 1f) * 0.85f).coerceIn(0.08f, 1f)
        val small = Bitmap.createScaledBitmap(mask, max(1, (mask.width * scale).toInt()), max(1, (mask.height * scale).toInt()), true)
        return Bitmap.createScaledBitmap(small, mask.width, mask.height, true)
    }

    /** Morphological mask expansion/contraction. Positive radius expands; negative contracts. */
    fun expandOrShrinkMask(mask: Bitmap, radius: Int, expand: Boolean): Bitmap {
        val w = mask.width; val h = mask.height
        val src = IntArray(w * h); mask.getPixels(src, 0, w, 0, 0, w, h)
        val out = IntArray(src.size)
        val r = radius.coerceIn(1, 24)
        for (y in 0 until h) for (x in 0 until w) {
            var value = if (expand) 0 else 255
            val y0 = max(0, y-r); val y1 = min(h-1, y+r)
            val x0 = max(0, x-r); val x1 = min(w-1, x+r)
            loop@ for (ny in y0..y1) for (nx in x0..x1) {
                val a = src[ny*w+nx] ushr 24
                value = if (expand) max(value, a) else min(value, a)
                if ((expand && value == 255) || (!expand && value == 0)) break@loop
            }
            out[y*w+x] = (value shl 24) or 0x00FFFFFF
        }
        return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
    }

    fun combineMasks(first: Bitmap, second: Bitmap, subtract: Boolean = false): Bitmap {
        val w = first.width; val h = first.height
        val a = IntArray(w * h); val b = IntArray(w * h)
        first.getPixels(a, 0, w, 0, 0, w, h)
        Bitmap.createScaledBitmap(second, w, h, true).getPixels(b, 0, w, 0, 0, w, h)
        for (i in a.indices) {
            val aa = a[i] ushr 24
            val bb = b[i] ushr 24
            val v = if (subtract) (aa - bb).coerceAtLeast(0) else max(aa, bb)
            a[i] = (v shl 24) or 0x00FFFFFF
        }
        return Bitmap.createBitmap(a, w, h, Bitmap.Config.ARGB_8888)
    }

    data class RgbCurve(val red: List<AdvancedImageOps.CurvePoint>, val green: List<AdvancedImageOps.CurvePoint>, val blue: List<AdvancedImageOps.CurvePoint>)

    /** Apply independent channel curves; empty channel points mean a linear channel. */
    fun applyRgbCurves(source: Bitmap, curves: RgbCurve): Bitmap {
        fun lut(points: List<AdvancedImageOps.CurvePoint>): IntArray {
            val sorted = (listOf(AdvancedImageOps.CurvePoint(0f, 0f)) + points + AdvancedImageOps.CurvePoint(1f, 1f)).sortedBy { it.x }
            return IntArray(256) { value ->
                val x = value / 255f
                val idx = (0 until sorted.lastIndex).firstOrNull { x <= sorted[it + 1].x } ?: sorted.lastIndex - 1
                val p = sorted[idx]; val q = sorted[idx + 1]
                val t = ((x - p.x) / (q.x - p.x).coerceAtLeast(0.0001f)).coerceIn(0f, 1f)
                (255f * (p.y + (q.y - p.y) * t).coerceIn(0f, 1f)).toInt()
            }
        }
        val rl = lut(curves.red); val gl = lut(curves.green); val bl = lut(curves.blue)
        val w = source.width; val h = source.height; val px = IntArray(w * h)
        source.getPixels(px, 0, w, 0, 0, w, h)
        for (i in px.indices) {
            val c = px[i]
            px[i] = (c and -0x1000000) or (rl[(c shr 16) and 255] shl 16) or (gl[(c shr 8) and 255] shl 8) or bl[c and 255]
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    /** Local contrast / clarity with a lightweight unsharp-mask approximation. */
    fun clarity(source: Bitmap, amount: Float): Bitmap {
        val strength = amount.coerceIn(-1f, 1f)
        if (abs(strength) < 0.001f) return source.copy(Bitmap.Config.ARGB_8888, true)
        val w = source.width; val h = source.height
        val src = IntArray(w * h); source.getPixels(src, 0, w, 0, 0, w, h)
        val out = IntArray(src.size)
        for (y in 0 until h) for (x in 0 until w) {
            val i = y * w + x
            val l = src[y * w + max(0, x - 1)]; val r = src[y * w + min(w - 1, x + 1)]
            val u = src[max(0, y - 1) * w + x]; val d = src[min(h - 1, y + 1) * w + x]
            val c = src[i]
            fun channel(shift: Int): Int {
                val center = (c shr shift) and 255
                val avg = (((l shr shift) and 255) + ((r shr shift) and 255) + ((u shr shift) and 255) + ((d shr shift) and 255)) / 4f
                return (center + (center - avg) * strength * 1.6f).toInt().coerceIn(0, 255)
            }
            out[i] = (c and -0x1000000) or (channel(16) shl 16) or (channel(8) shl 8) or channel(0)
        }
        return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
    }

    /** Resize/crop using a normalized rectangle (0..1), clamped to valid image bounds. */
    fun cropNormalized(source: Bitmap, left: Float, top: Float, right: Float, bottom: Float): Bitmap {
        val l = (left.coerceIn(0f, 0.99f) * source.width).toInt()
        val t = (top.coerceIn(0f, 0.99f) * source.height).toInt()
        val r = (right.coerceIn(0.01f, 1f) * source.width).toInt().coerceIn(l + 1, source.width)
        val b = (bottom.coerceIn(0.01f, 1f) * source.height).toInt().coerceIn(t + 1, source.height)
        return Bitmap.createBitmap(source, l, t, r - l, b - t)
    }

    /**
     * Soft patch repair using a user-chosen clean source point. This is a manual healing aid,
     * not AI inpainting; callers must let the user choose the source and target areas.
     */
    fun healFromPatch(source: Bitmap, sourceRect: RectF, targetRect: RectF, opacity: Float = 1f, feather: Float = 0.2f): Bitmap {
        val out = source.copy(Bitmap.Config.ARGB_8888, true)
        val c = Canvas(out)
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { alpha = (opacity.coerceIn(0f, 1f) * 255).toInt() }
        val save = c.save()
        val inset = min(targetRect.width(), targetRect.height()) * feather.coerceIn(0f, 0.49f)
        val clip = RectF(targetRect.left + inset, targetRect.top + inset, targetRect.right - inset, targetRect.bottom - inset)
        c.clipRect(clip)
        c.drawBitmap(source, sourceRect, targetRect, p)
        c.restoreToCount(save)
        return out
    }
}
