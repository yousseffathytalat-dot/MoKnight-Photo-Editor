package com.moknight.photoeditor

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** MoKnight neon indigo/violet palette with a cyan accent (matches the reference mockups). */
object MoKnightColors {
    val CanvasBg = Color(0xFF0C0926)
    val Background = Color(0xFF0A0720)
    val Panel = Color(0xFF140F38)
    val PanelHigh = Color(0xFF21185A)
    var Primary by mutableStateOf(Color(0xFF7C4DFF))
    var PrimaryBright by mutableStateOf(Color(0xFF9B6BFF))
    var Accent by mutableStateOf(Color(0xFF38BDF8))
    val OnDark = Color(0xFFF3F0FF)
    val Muted = Color(0xFFA9A3D9)
    var Outline by mutableStateOf(Color(0xFF4B3AA6))
    var Divider by mutableStateOf(Color(0xFF2A2166))

    val BackgroundBrush get() = Brush.verticalGradient(listOf(Primary.copy(alpha=.22f), Background))
    val PanelBrush get() = Brush.verticalGradient(listOf(PanelHigh, Panel))
    val BorderBrush get() = Brush.linearGradient(listOf(PrimaryBright, Accent.copy(alpha=.6f), Primary))

    fun applyPreset(id: Int) {
        when (id) {
            1 -> { Primary=Color(0xFF00AFA0); PrimaryBright=Color(0xFF39DCCB); Accent=Color(0xFF80DEEA); Outline=Color(0xFF176D70); Divider=Color(0xFF164A50) }
            2 -> { Primary=Color(0xFFFF6B35); PrimaryBright=Color(0xFFFF9A62); Accent=Color(0xFFFFD166); Outline=Color(0xFF98502F); Divider=Color(0xFF57321F) }
            3 -> { Primary=Color(0xFF3978E8); PrimaryBright=Color(0xFF78A7FF); Accent=Color(0xFF70E1FF); Outline=Color(0xFF315AA0); Divider=Color(0xFF233B69) }
            4 -> { Primary=Color(0xFFE0529C); PrimaryBright=Color(0xFFFF83C2); Accent=Color(0xFFFFC1E1); Outline=Color(0xFF8E3768); Divider=Color(0xFF512344) }
            else -> { Primary=Color(0xFF7C4DFF); PrimaryBright=Color(0xFF9B6BFF); Accent=Color(0xFF38BDF8); Outline=Color(0xFF4B3AA6); Divider=Color(0xFF2A2166) }
        }
    }
}

private fun makeScheme() = darkColorScheme(
    primary = MoKnightColors.Primary,
    onPrimary = Color.White,
    secondary = MoKnightColors.Accent,
    onSecondary = Color.Black,
    background = MoKnightColors.Background,
    onBackground = MoKnightColors.OnDark,
    surface = MoKnightColors.Panel,
    onSurface = MoKnightColors.OnDark,
    surfaceVariant = MoKnightColors.PanelHigh,
    onSurfaceVariant = MoKnightColors.Muted,
    surfaceContainer = MoKnightColors.Panel,
    surfaceContainerHigh = MoKnightColors.PanelHigh,
    surfaceContainerHighest = MoKnightColors.Outline,
    outline = MoKnightColors.Outline,
    outlineVariant = MoKnightColors.Divider,
    primaryContainer = MoKnightColors.PanelHigh,
    onPrimaryContainer = MoKnightColors.OnDark,
    secondaryContainer = MoKnightColors.Primary.copy(alpha = .45f),
    onSecondaryContainer = MoKnightColors.OnDark
)

private val shapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp)
)

private val typography = Typography(
    titleMedium = TextStyle(fontSize = 15.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge = TextStyle(fontSize = 14.sp),
    bodyMedium = TextStyle(fontSize = 13.sp),
    labelLarge = TextStyle(fontSize = 13.sp, fontWeight = FontWeight.Medium),
    labelMedium = TextStyle(fontSize = 12.sp)
)

@Composable
fun MoKnightTheme(content: @Composable () -> Unit) {
    val scheme = makeScheme()
    MaterialTheme(colorScheme = scheme, shapes = shapes, typography = typography, content = content)
}
