package com.moknight.photoeditor

import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.AssistChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/** Native Compose AI panel. Effects are intentionally lightweight for mid-range Android phones. */
@Composable
fun AiStudioPanel(
    prompt: String,
    onPromptChange: (String) -> Unit,
    onRunPrompt: () -> Unit,
    busy: Boolean,
    status: String,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "aiStudioMotion")
    val sweep by transition.animateFloat(
        initialValue = -0.9f,
        targetValue = 1.9f,
        animationSpec = infiniteRepeatable(tween(3600, easing = LinearEasing), RepeatMode.Restart),
        label = "lightSweep"
    )
    val pulse by transition.animateFloat(
        initialValue = 0.22f,
        targetValue = 0.52f,
        animationSpec = infiniteRepeatable(tween(1700), RepeatMode.Reverse),
        label = "softGlow"
    )
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier = modifier
            .fillMaxWidth()
            .animateContentSize()
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xFF1B1240), Color(0xFF100B27), Color(0xFF0D0A20))))
            .drawBehind {
                // A restrained violet halo plus a slow diagonal light sweep.
                drawRect(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0x557C4DFF).copy(alpha = pulse), Color.Transparent),
                        center = Offset(size.width * .08f, size.height * .02f),
                        radius = size.width * .8f
                    )
                )
                val x = size.width * sweep
                drawRect(
                    brush = Brush.linearGradient(
                        colors = listOf(Color.Transparent, Color(0x167C4DFF), Color(0x2038BDF8), Color.Transparent),
                        start = Offset(x - size.width * .22f, 0f),
                        end = Offset(x + size.width * .22f, size.height)
                    )
                )
            }
            .border(
                1.dp,
                Brush.linearGradient(listOf(Color(0xFF9B6BFF), Color(0x665140A8), Color(0xFF38BDF8))),
                shape
            )
            .padding(13.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            Surface(
                color = Color(0xFF6D35C8).copy(alpha = .92f),
                shape = RoundedCornerShape(12.dp),
                shadowElevation = 7.dp
            ) {
                Text("✦ AI", color = Color.White, modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp))
            }
            Column(modifier = Modifier.weight(1f)) {
                Text("MoKnight AI Studio", style = MaterialTheme.typography.titleMedium, color = Color.White)
                Text("مساعد التحديد والتحرير الذكي", style = MaterialTheme.typography.bodySmall, color = Color(0xFFBEB4E8))
            }
            Surface(color = if (busy) Color(0xFF684B19) else Color(0xFF174A3B), shape = RoundedCornerShape(30.dp)) {
                Text(
                    if (busy) "يعمل…" else "جاهز",
                    color = if (busy) Color(0xFFFFD166) else Color(0xFF72E0B2),
                    style = MaterialTheme.typography.labelMedium,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                )
            }
        }
        OutlinedTextField(
            value = prompt,
            onValueChange = onPromptChange,
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("اكتب طلبك… مثال: حدّد الشخص أو حسّن جودة الصورة") },
            minLines = 2,
            maxLines = 3,
            shape = RoundedCornerShape(14.dp)
        )
        Text("أوامر سريعة", color = Color(0xFFD9D0F5), style = MaterialTheme.typography.labelMedium)
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            listOf("حدد الشخص", "إزالة الخلفية", "تمويه الخلفية", "حسّن الجودة", "حدد الشعر", "إزالة العنصر").forEach { command ->
                AssistChip(onClick = { onPromptChange(command) }, label = { Text(command) })
            }
        }
        Button(
            onClick = onRunPrompt,
            enabled = !busy && prompt.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (busy) "جاري التنفيذ…" else "✦ تنفيذ الأمر")
        }
        Surface(color = Color(0xFF0B0820).copy(alpha = .72f), shape = RoundedCornerShape(12.dp)) {
            Text(status, color = Color(0xFFBEB4E8), style = MaterialTheme.typography.bodySmall, modifier = Modifier.fillMaxWidth().padding(10.dp))
        }
        Text(
            "ملاحظة: الأوامر المتاحة تشغّل أدوات التحرير المدمجة. إنشاء عناصر جديدة بوصف نصي يحتاج ربط نموذج توليدي خارجي.",
            color = Color(0xFF9F96C4), style = MaterialTheme.typography.bodySmall
        )
    }
}
