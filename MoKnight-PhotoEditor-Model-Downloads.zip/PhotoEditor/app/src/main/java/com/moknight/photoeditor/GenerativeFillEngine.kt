package com.moknight.photoeditor

import android.content.Context
import android.graphics.Bitmap

/**
 * Backward-compatible facade retained so older MainActivity code keeps compiling.
 * Object removal is now powered by the separate LaMa-Dilated INT8 model.
 * Text-conditioned generation is intentionally not routed through this class.
 */
object GenerativeFillEngine {
    fun isModelInstalled(context: Context): Boolean = AiModelManager.isInstalled(context, AiModelManager.objectRemoval)

    fun inpaint(
        context: Context,
        source: Bitmap,
        mask: Bitmap,
        onProgress: (String) -> Unit,
        onResult: (Result<Bitmap>) -> Unit
    ) = ObjectRemovalEngine.remove(context, source, mask, onProgress, onResult)
}
