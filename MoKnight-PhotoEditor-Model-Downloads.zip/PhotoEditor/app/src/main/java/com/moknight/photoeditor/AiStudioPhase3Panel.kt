package com.moknight.photoeditor

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun AiStudioPhase3Panel(
    context: Context,
    busy: Boolean,
    status: String,
    prompt: String,
    onPromptChange: (String) -> Unit,
    hasMask: Boolean,
    onRemoveObject: () -> Unit,
    onGenerateFill: () -> Unit,
    onDownloadRemoval: () -> Unit,
    onDownloadGenerative: () -> Unit,
    onRunPrompt: () -> Unit,
    removalReady: Boolean,
    generativeReady: Boolean,
    modifier: Modifier = Modifier
) {
    var tab by remember { mutableIntStateOf(0) }
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Color(0xFF17122D), Color(0xFF0B0918))), RoundedCornerShape(22.dp))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
            FilterChip(tab == 0, { tab = 0 }, label = { Text("إزالة العناصر") })
            FilterChip(tab == 1, { tab = 1 }, label = { Text("Generative Fill") })
            FilterChip(tab == 2, { tab = 2 }, label = { Text("الموديلات") })
        }
        when (tab) {
            0 -> {
                Text("AI Object Removal", style = MaterialTheme.typography.titleMedium)
                Text("حدّد العنصر بالفرشاة أو التحديد الذكي، ثم أزله بدون تغيير المناطق خارج القناع.", style = MaterialTheme.typography.bodySmall)
                ModelBadge("LaMa-Dilated INT8", "≈ 44 MB", removalReady, "Offline بعد التنزيل")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onDownloadRemoval, enabled = !busy) { Text(if (removalReady) "إدارة النموذج" else "تنزيل النموذج") }
                    Button(onClick = onRemoveObject, enabled = hasMask && !busy && removalReady) { Text("إزالة العنصر") }
                }
            }
            1 -> {
                Text("AI Generative Fill", style = MaterialTheme.typography.titleMedium)
                Text("اكتب ما تريد وضعه داخل المنطقة المحددة. هذا المسار منفصل عن LaMa ويحتاج نموذج توليد يدعم النص + الصورة + القناع.", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(
                    value = prompt,
                    onValueChange = onPromptChange,
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("وصف العنصر") },
                    placeholder = { Text("مثال: شجرة صغيرة بجانب المنزل، بنفس الإضاءة والمنظور") },
                    minLines = 3
                )
                ModelBadge("RealVis 6 Inpaint INT8", "≈ 1.3 GB", generativeReady, "Text + Mask / Offline بعد التجهيز")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onDownloadGenerative, enabled = !busy) { Text(if (generativeReady) "إدارة النموذج" else "تنزيل 1.3 GB") }
                    Button(onClick = onGenerateFill, enabled = hasMask && prompt.isNotBlank() && !busy && generativeReady) { Text("Generate") }
                }
                if (!generativeReady) Text("بعد تنزيل النموذج سيظهر كجاهز هنا. لا يتم استخدام نموذج إزالة العناصر بدل نموذج التوليد.", color = MaterialTheme.colorScheme.secondary, style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                    listOf("ضع شجرة صغيرة بجانب المنزل", "أضف كرسيًا خشبيًا", "ضع نباتًا بجوار النافذة").forEach { sample ->
                        FilterChip(false, { onPromptChange(sample) }, label = { Text(sample) })
                    }
                }
            }
            else -> {
                Text("Model Manager", style = MaterialTheme.typography.titleMedium)
                Text("النماذج لا تدخل داخل APK. يتم تنزيلها عند الطلب إلى مساحة التطبيق الخاصة.", style = MaterialTheme.typography.bodySmall)
                ModelCard(AiModelManager.objectRemoval, removalReady, onDownloadRemoval)
                ModelCard(AiModelManager.generativeFill, generativeReady, onDownloadGenerative)
                Text("حجم نماذج Phase 3 عند تثبيتها معًا ≈ 1.344 GB. مع نموذج Real-ESRGAN الموجود في المشروع تبقى الحزمة تحت سقف 3 GB، مع بقاء النماذج خارج APK.", style = MaterialTheme.typography.bodySmall)
                Text("ملاحظة: RealVis 6 منشور كـINT8 ONNX ومذكور في بطاقة النموذج أنه حوالي 1.3 GB، لكن تشغيله الفعلي يحتاج backend diffusion كاملًا ومتوافقًا مع الجهاز؛ لا يتم اعتبار وجود الملفات وحده اختبارًا للـinference.", color = Color(0xFFFFD166), style = MaterialTheme.typography.bodySmall)
            }
        }
        if (busy) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        Surface(color = Color(0xFF080611), shape = RoundedCornerShape(12.dp)) {
            Text(status, modifier = Modifier.fillMaxWidth().padding(10.dp), style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun ModelBadge(title: String, size: String, ready: Boolean, detail: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF141026)), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(11.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(title, style = MaterialTheme.typography.labelLarge)
            Text("$size • $detail", style = MaterialTheme.typography.bodySmall)
            Text(if (ready) "✓ جاهز على الجهاز" else "○ غير مثبت", color = if (ready) Color(0xFF72E0B2) else Color(0xFFFFD166), style = MaterialTheme.typography.labelMedium)
        }
    }
}

@Composable
private fun ModelCard(model: AiModelManager.ModelInfo, ready: Boolean, onDownload: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF141026)), shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.fillMaxWidth().padding(11.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(model.title, style = MaterialTheme.typography.labelLarge)
                Text("${model.sizeLabel} • ${model.license}", style = MaterialTheme.typography.bodySmall)
            }
            OutlinedButton(onClick = onDownload) { Text(if (ready) "إعادة" else "تنزيل") }
        }
    }
}
