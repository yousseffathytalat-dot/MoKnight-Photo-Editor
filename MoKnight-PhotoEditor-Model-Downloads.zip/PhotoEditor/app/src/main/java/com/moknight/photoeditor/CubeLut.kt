package com.moknight.photoeditor

import android.graphics.Bitmap
import kotlin.math.floor

/** Minimal .cube 3D LUT reader with trilinear interpolation (red is the fastest varying axis). */
data class CubeLut(
    val size: Int,
    private val values: FloatArray,
    private val domainMin: FloatArray = floatArrayOf(0f, 0f, 0f),
    private val domainMax: FloatArray = floatArrayOf(1f, 1f, 1f)
) {
    init { require(size in 2..64 && values.size == size * size * size * 3) }

    private fun sample(r: Int, g: Int, b: Int, channel: Int): Float =
        values[((b * size + g) * size + r) * 3 + channel]

    private fun sampleRgb(red: Float, green: Float, blue: Float, out: FloatArray, lo: IntArray, hi: IntArray, frac: FloatArray) {
        for (i in 0..2) {
            val input = when(i) { 0 -> red; 1 -> green; else -> blue }
            val span = (domainMax[i] - domainMin[i]).takeIf { it > 1e-8f } ?: 1f
            val pos = (((input - domainMin[i]) / span).coerceIn(0f, 1f)) * (size - 1)
            lo[i] = floor(pos).toInt()
            hi[i] = (lo[i] + 1).coerceAtMost(size - 1)
            frac[i] = pos - lo[i]
        }
        val r0=lo[0]; val r1=hi[0]; val g0=lo[1]; val g1=hi[1]; val b0=lo[2]; val b1=hi[2]
        val x=frac[0]; val y=frac[1]; val z=frac[2]
        for (channel in 0..2) {
            val c000=sample(r0,g0,b0,channel); val c100=sample(r1,g0,b0,channel)
            val c010=sample(r0,g1,b0,channel); val c110=sample(r1,g1,b0,channel)
            val c001=sample(r0,g0,b1,channel); val c101=sample(r1,g0,b1,channel)
            val c011=sample(r0,g1,b1,channel); val c111=sample(r1,g1,b1,channel)
            val c00=c000+(c100-c000)*x; val c10=c010+(c110-c010)*x
            val c01=c001+(c101-c001)*x; val c11=c011+(c111-c011)*x
            val c0=c00+(c10-c00)*y; val c1=c01+(c11-c01)*y
            out[channel]=c0+(c1-c0)*z
        }
    }

    fun apply(source: Bitmap): Bitmap {
        val pixels = IntArray(source.width * source.height)
        source.getPixels(pixels, 0, source.width, 0, 0, source.width, source.height)
        val mapped = FloatArray(3)
        val lo = IntArray(3); val hi = IntArray(3); val frac = FloatArray(3)
        for (i in pixels.indices) {
            val c = pixels[i]
            val r=((c ushr 16) and 255)/255f; val g=((c ushr 8) and 255)/255f; val b=(c and 255)/255f
            sampleRgb(r,g,b,mapped,lo,hi,frac)
            val nr=(mapped[0]*255f).toInt().coerceIn(0,255)
            val ng=(mapped[1]*255f).toInt().coerceIn(0,255)
            val nb=(mapped[2]*255f).toInt().coerceIn(0,255)
            pixels[i]=(c and -0x1000000) or (nr shl 16) or (ng shl 8) or nb
        }
        return Bitmap.createBitmap(pixels, source.width, source.height, Bitmap.Config.ARGB_8888)
    }

    companion object {
        fun parse(text: String): CubeLut {
            var size = 0
            val min = floatArrayOf(0f,0f,0f); val max = floatArrayOf(1f,1f,1f)
            val triples = ArrayList<Float>()
            text.lineSequence().forEach { raw ->
                val line=raw.substringBefore('#').trim()
                if(line.isEmpty() || line.startsWith("TITLE",true)) return@forEach
                val parts=line.split(Regex("\\s+")).filter { it.isNotBlank() }
                when(parts[0].uppercase()) {
                    "LUT_3D_SIZE" -> { require(parts.size==2); size=parts[1].toInt(); require(size in 2..64) }
                    "LUT_1D_SIZE" -> error("يدعم MoKnight جداول 3D LUT فقط بصيغة .cube")
                    "DOMAIN_MIN" -> { require(parts.size==4); for(i in 0..2) min[i]=parts[i+1].toFloat() }
                    "DOMAIN_MAX" -> { require(parts.size==4); for(i in 0..2) max[i]=parts[i+1].toFloat() }
                    else -> if(parts.size==3) parts.forEach { triples.add(it.toFloat()) }
                }
            }
            require(size in 2..64) { "ملف LUT لا يحتوي LUT_3D_SIZE صالحاً" }
            require(triples.size==size*size*size*3) { "عدد ألوان LUT لا يطابق الحجم المعلن" }
            require((0..2).all { max[it] > min[it] }) { "نطاق DOMAIN غير صالح" }
            return CubeLut(size, triples.toFloatArray(), min, max)
        }
    }
}
