package com.moknight.photoeditor

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Original, procedurally defined color looks and pixel effects (no third-party LUT files, so no extra licenses).
 * Every look = a parametric grade; every effect = a real per-pixel operation. [apply] mixes the result
 * with the original by `strength` (0..1), which backs the intensity slider.
 */
object LookPack {
    class Grade(
        val bright: Float = 0f, val contrast: Float = 1f, val sat: Float = 1f,
        val gain: FloatArray = floatArrayOf(1f, 1f, 1f),      // per-channel multiplier (warmth/tint)
        val shadow: FloatArray = floatArrayOf(0f, 0f, 0f),    // added in shadows (0..1 scale)
        val highlight: FloatArray = floatArrayOf(0f, 0f, 0f), // added in highlights
        val fade: Float = 0f, val vignette: Float = 0f, val mono: Boolean = false,
        val duoDark: Int? = null, val duoLight: Int? = null
    )

    class Look(val name: String, val category: String, val grade: Grade? = null, val effect: String? = null)

    private fun rgb(r: Float, g: Float, b: Float) = floatArrayOf(r, g, b)

    val categories = listOf("بشرة", "قديم", "أيام زمان", "احتفالي", "كريم", "نعناع", "ثنائي", "فيلم", "سينما", "نيون", "مؤثرات")

    val looks: List<Look> = listOf(
        Look("Skin 01", "بشرة", Grade(.03f, .96f, .92f, rgb(1.05f, 1f, .97f), fade = .04f)),
        Look("Skin 02", "بشرة", Grade(.05f, .92f, .88f, rgb(1.07f, 1.01f, .98f), highlight = rgb(.03f, .01f, 0f))),
        Look("Skin 03", "بشرة", Grade(.02f, 1.02f, 1.0f, rgb(1.04f, .99f, .96f), shadow = rgb(.02f, 0f, .01f))),
        Look("Retro 01", "قديم", Grade(0f, 1.1f, .85f, rgb(1.1f, 1f, .8f), fade = .08f, vignette = .3f)),
        Look("Retro 02", "قديم", Grade(.02f, 1.15f, .8f, rgb(1.15f, 1.02f, .78f), shadow = rgb(.03f, .01f, 0f), fade = .06f)),
        Look("Retro 03", "قديم", Grade(0f, 1.05f, .7f, rgb(1.05f, 1f, .9f), fade = .12f, vignette = .4f)),
        Look("Vintage 01", "أيام زمان", Grade(.02f, .95f, .6f, rgb(1.08f, 1.02f, .88f), fade = .15f, vignette = .25f)),
        Look("Vintage 02", "أيام زمان", Grade(0f, 1f, .5f, rgb(1.1f, 1.04f, .85f), fade = .2f, vignette = .35f)),
        Look("Vintage BW", "أيام زمان", Grade(0f, 1.1f, 0f, fade = .1f, vignette = .35f, mono = true)),
        Look("Party 01", "احتفالي", Grade(.03f, 1.15f, 1.4f, rgb(1.05f, .98f, 1.08f))),
        Look("Party 02", "احتفالي", Grade(.02f, 1.2f, 1.5f, rgb(1.1f, 1f, 1.1f), highlight = rgb(.04f, 0f, .05f))),
        Look("Cream 01", "كريم", Grade(.05f, .88f, .9f, rgb(1.06f, 1.03f, .95f), fade = .08f)),
        Look("Cream 02", "كريم", Grade(.07f, .85f, .8f, rgb(1.08f, 1.04f, .94f), fade = .12f)),
        Look("Mint 01", "نعناع", Grade(.02f, 1.05f, .95f, rgb(.92f, 1.06f, 1.02f), shadow = rgb(0f, .02f, .02f))),
        Look("Mint 02", "نعناع", Grade(.03f, 1.0f, .9f, rgb(.9f, 1.08f, 1.05f), fade = .05f)),
        Look("Duo 01", "ثنائي", Grade(duoDark = 0xFF2B1055.toInt(), duoLight = 0xFFFF7EB3.toInt())),
        Look("Duo 02", "ثنائي", Grade(duoDark = 0xFF0F2027.toInt(), duoLight = 0xFFF7D26B.toInt())),
        Look("Duo 03", "ثنائي", Grade(duoDark = 0xFF1B1B3A.toInt(), duoLight = 0xFF4DE0D0.toInt())),
        Look("Film 01", "فيلم", Grade(0f, 1.12f, .9f, rgb(1.03f, 1f, .96f), fade = .06f), effect = "grain"),
        Look("Film 02", "فيلم", Grade(0f, 1.18f, .82f, rgb(1.06f, 1.01f, .92f), fade = .1f, vignette = .2f), effect = "grain"),
        Look("Cinema 01", "سينما", Grade(0f, 1.2f, .95f, rgb(1.05f, 1f, .92f), shadow = rgb(0f, .04f, .06f), highlight = rgb(.05f, .02f, -.03f))),
        Look("Cinema 02", "سينما", Grade(-.02f, 1.25f, .9f, rgb(1.08f, 1f, .9f), shadow = rgb(-.01f, .05f, .07f), vignette = .25f)),
        Look("Cinema 03", "سينما", Grade(0f, 1.3f, .8f, rgb(.95f, 1.02f, 1.05f), shadow = rgb(0f, .05f, .05f))),
        Look("Neon 01", "نيون", Grade(0f, 1.3f, 1.7f, rgb(.95f, .9f, 1.2f), shadow = rgb(.05f, 0f, .1f))),
        Look("Neon 02", "نيون", Grade(0f, 1.35f, 1.8f, rgb(1.2f, .85f, 1.1f), shadow = rgb(0f, .04f, .09f))),
        Look("Glitch", "مؤثرات", effect = "glitch"),
        Look("RGB", "مؤثرات", effect = "rgb"),
        Look("TV", "مؤثرات", effect = "tv"),
        Look("Noise", "مؤثرات", effect = "noise")
    )

    fun apply(src: Bitmap, look: Look, strength: Float): Bitmap {
        val w = src.width; val h = src.height
        val s = strength.coerceIn(0f, 1f)
        val px = IntArray(w * h); src.getPixels(px, 0, w, 0, 0, w, h)
        val out = px.copyOf()
        look.grade?.let { gradePixels(out, w, h, it) }
        when (look.effect) {
            "grain" -> noise(out, .06f)
            "noise" -> noise(out, .22f)
            "glitch" -> glitch(out, px, w, h)
            "rgb" -> rgbSplit(out, px, w, h, max(2, w / 120))
            "tv" -> tv(out, w, h)
        }
        if (s < 1f) for (i in out.indices) out[i] = mix(px[i], out[i], s)
        val res = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        res.setPixels(out, 0, w, 0, 0, w, h)
        return res
    }

    private fun mix(a: Int, b: Int, t: Float): Int {
        fun c(sh: Int) = ((((a shr sh) and 255) * (1 - t) + ((b shr sh) and 255) * t)).toInt().coerceIn(0, 255)
        return (a and (255 shl 24)) or (c(16) shl 16) or (c(8) shl 8) or c(0)
    }

    private fun gradePixels(p: IntArray, w: Int, h: Int, g: Grade) {
        val cx = w / 2f; val cy = h / 2f; val maxD = cx * cx + cy * cy
        for (y in 0 until h) for (x in 0 until w) {
            val i = y * w + x; val c = p[i]
            var r = ((c shr 16) and 255) / 255f; var gg = ((c shr 8) and 255) / 255f; var b = (c and 255) / 255f
            var l = .2126f * r + .7152f * gg + .0722f * b
            if (g.duoDark != null && g.duoLight != null) {
                val d = g.duoDark; val u = g.duoLight
                r = ((d shr 16 and 255) * (1 - l) + (u shr 16 and 255) * l) / 255f
                gg = ((d shr 8 and 255) * (1 - l) + (u shr 8 and 255) * l) / 255f
                b = ((d and 255) * (1 - l) + (u and 255) * l) / 255f
            } else {
                if (g.mono) { r = l; gg = l; b = l } else if (g.sat != 1f) {
                    r = l + (r - l) * g.sat; gg = l + (gg - l) * g.sat; b = l + (b - l) * g.sat
                }
                r = (r - .5f) * g.contrast + .5f + g.bright; gg = (gg - .5f) * g.contrast + .5f + g.bright; b = (b - .5f) * g.contrast + .5f + g.bright
                r *= g.gain[0]; gg *= g.gain[1]; b *= g.gain[2]
                l = (.2126f * r + .7152f * gg + .0722f * b).coerceIn(0f, 1f)
                val sw = (1f - l) * (1f - l); val hw = l * l
                r += g.shadow[0] * sw + g.highlight[0] * hw
                gg += g.shadow[1] * sw + g.highlight[1] * hw
                b += g.shadow[2] * sw + g.highlight[2] * hw
                if (g.fade > 0f) { r = r * (1 - g.fade) + g.fade * .5f; gg = gg * (1 - g.fade) + g.fade * .5f; b = b * (1 - g.fade) + g.fade * .5f }
            }
            if (g.vignette > 0f) {
                val dx = x - cx; val dy = y - cy; val v = 1f - g.vignette * (dx * dx + dy * dy) / maxD
                r *= v; gg *= v; b *= v
            }
            p[i] = (c and (255 shl 24)) or ((r.coerceIn(0f, 1f) * 255).toInt() shl 16) or ((gg.coerceIn(0f, 1f) * 255).toInt() shl 8) or (b.coerceIn(0f, 1f) * 255).toInt()
        }
    }

    private fun noise(p: IntArray, amt: Float) {
        var seed = 1234567L
        for (i in p.indices) {
            seed = seed * 6364136223846793005L + 1442695040888963407L
            val n = (((seed ushr 33).toInt() and 0xFF) - 128) * amt
            val c = p[i]
            val r = (((c shr 16) and 255) + n).toInt().coerceIn(0, 255); val g = (((c shr 8) and 255) + n).toInt().coerceIn(0, 255); val b = ((c and 255) + n).toInt().coerceIn(0, 255)
            p[i] = (c and (255 shl 24)) or (r shl 16) or (g shl 8) or b
        }
    }

    private fun rgbSplit(out: IntArray, src: IntArray, w: Int, h: Int, d: Int) {
        for (y in 0 until h) for (x in 0 until w) {
            val r = (src[y * w + min(w - 1, x + d)] shr 16) and 255
            val g = (src[y * w + x] shr 8) and 255
            val b = src[y * w + max(0, x - d)] and 255
            out[y * w + x] = (src[y * w + x] and (255 shl 24)) or (r shl 16) or (g shl 8) or b
        }
    }

    private fun glitch(out: IntArray, src: IntArray, w: Int, h: Int) {
        rgbSplit(out, src, w, h, max(3, w / 90))
        var seed = 99L
        var y = 0
        while (y < h) {
            seed = seed * 6364136223846793005L + 1442695040888963407L
            val band = max(2, ((seed ushr 40).toInt() and 0xFF) * h / 4000 + h / 80)
            val shift = (((seed ushr 20).toInt() and 0x3FF) - 512) * w / 4096
            if (abs(shift) > w / 60 && (seed ushr 10) % 3L == 0L) {
                for (yy in y until min(h, y + band)) {
                    val row = out.copyOfRange(yy * w, yy * w + w)
                    for (x in 0 until w) out[yy * w + x] = row[((x - shift) % w + w) % w]
                }
            }
            y += band
        }
    }

    private fun tv(p: IntArray, w: Int, h: Int) {
        for (y in 0 until h) {
            val line = if (y % 4 < 2) 1f else .78f
            val wob = 1f + .04f * sin(y * .15f)
            for (x in 0 until w) {
                val c = p[y * w + x]
                val r = (((c shr 16) and 255) * line * wob).toInt().coerceIn(0, 255)
                val g = (((c shr 8) and 255) * line).toInt().coerceIn(0, 255)
                val b = ((c and 255) * line).toInt().coerceIn(0, 255)
                p[y * w + x] = (c and (255 shl 24)) or (r shl 16) or (g shl 8) or b
            }
        }
        noise(p, .08f)
    }
}
