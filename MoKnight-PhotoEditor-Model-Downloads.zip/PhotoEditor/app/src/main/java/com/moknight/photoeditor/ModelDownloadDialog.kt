package com.moknight.photoeditor

import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun ModelDownloadDialog(context: Context, onClose: () -> Unit) {
    val models = AiModelManager.all
    var busyId by remember { mutableStateOf<String?>(null) }
    var status by remember { mutableStateOf("لا يتم تنزيل أي نموذج تلقائيًا. اختر فقط ما تحتاجه.") }
    var progress by remember { mutableFloatStateOf(0f) }
    var refresh by remember { mutableIntStateOf(0) }
    val total = models.sumOf { it.sizeBytes }
    val installed = models.sumOf { AiModelManager.installedBytes(context, it) }

    AlertDialog(
        onDismissRequest = { if (busyId == null) onClose() },
        title = { Text("تنزيل وإدارة نماذج AI") },
        text = {
            Column(
                Modifier.fillMaxWidth().heightIn(max = 560.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    "النماذج خارج APK. البرنامج نفسه يثبت أولًا بحجم صغير، وبعدها تختار من هنا ما تريد تنزيله. بعد التنزيل تعمل النماذج بدون إنترنت.",
                    style = MaterialTheme.typography.bodySmall
                )
                Text("إجمالي الكتالوج: ${formatBytes(total)} • المثبت حاليًا: ${formatBytes(installed)}", style = MaterialTheme.typography.labelMedium)
                models.forEach { model ->
                    key(model.id, refresh) {
                        val ready = AiModelManager.isInstalled(context, model)
                        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                            Column(Modifier.padding(11.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(model.title, style = MaterialTheme.typography.titleSmall)
                                    Text(model.sizeLabel, style = MaterialTheme.typography.labelMedium)
                                }
                                Text(model.purpose, style = MaterialTheme.typography.bodySmall)
                                Text("الترخيص: ${model.license}", style = MaterialTheme.typography.bodySmall)
                                Text(if (ready) "✓ مثبت ومتحقق من سلامة الملفات" else "○ غير مثبت — لن يتم تنزيله إلا عند الضغط", style = MaterialTheme.typography.bodySmall)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(
                                        enabled = busyId == null && !ready,
                                        onClick = {
                                            busyId = model.id
                                            progress = 0f
                                            status = "جاري تنزيل ${model.title}…"
                                            AiModelManager.download(context, model,
                                                onProgress = { msg ->
                                                    status = msg
                                                    val pct = Regex("(\\d+)%").find(msg)?.groupValues?.getOrNull(1)?.toFloatOrNull()
                                                    if (pct != null) progress = pct / 100f
                                                },
                                                onResult = { result ->
                                                    busyId = null
                                                    refresh++
                                                    status = result.fold(
                                                        { "تم تنزيل ${model.title} والتحقق من SHA-256. أصبح متاحًا بدون إنترنت." },
                                                        { "تعذر تنزيل ${model.title}: ${it.localizedMessage ?: "خطأ غير معروف"}" }
                                                    )
                                                }
                                            )
                                        }
                                    ) { Text("تنزيل") }
                                    OutlinedButton(
                                        enabled = busyId == null && ready,
                                        onClick = {
                                            AiModelManager.delete(context, model)
                                            refresh++
                                            status = "تم حذف ${model.title} من مساحة التطبيق."
                                        }
                                    ) { Text("حذف") }
                                }
                            }
                        }
                    }
                }
                if (busyId != null) LinearProgressIndicator(progress = progress, modifier = Modifier.fillMaxWidth())
                Text(status, style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { OutlinedButton(enabled = busyId == null, onClick = onClose) { Text("إغلاق") } }
    )
}

private fun formatBytes(bytes: Long): String = when {
    bytes >= 1024L * 1024L * 1024L -> String.format(java.util.Locale.US, "%.2f GB", bytes / (1024.0 * 1024.0 * 1024.0))
    else -> String.format(java.util.Locale.US, "%.0f MB", bytes / (1024.0 * 1024.0))
}
