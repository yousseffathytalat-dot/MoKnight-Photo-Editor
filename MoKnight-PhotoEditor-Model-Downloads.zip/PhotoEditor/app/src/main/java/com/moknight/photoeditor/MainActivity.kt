package com.moknight.photoeditor

import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Canvas as AndroidCanvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.DashPathEffect
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import java.io.File
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.Spring
import androidx.compose.animation.animateFloatAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.graphics.Color as CColor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class AppPage { HOME, EDITOR }

class MainActivity : ComponentActivity() {
    private fun updateSystemBarsForOrientation() {
        val decor = window.decorView
        val landscape = resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
        decor.systemUiVisibility = if (landscape) {
            (android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
                or android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        } else {
            android.view.View.SYSTEM_UI_FLAG_VISIBLE
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        updateSystemBarsForOrientation()
        OpenCvImageToolkit.initialize()
        setContent {
            MoKnightTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Surface(Modifier.fillMaxSize()) { EditorScreen() }
                }
            }
        }
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        updateSystemBarsForOrientation()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) updateSystemBarsForOrientation()
    }
}

sealed interface Ov { val visible: Boolean; val opacity: Float; val locked: Boolean get() = false }
data class AdjustmentLayer(
    val layerName: String = "Adjustment Layer",
    val adjustment: ProfessionalEditing.Adjustment = ProfessionalEditing.Adjustment(),
    override val visible: Boolean = true, override val opacity: Float = 1f,
    val mask: Bitmap? = null, override val locked: Boolean = false,
    val smartFilters: List<SmartFilter> = emptyList()
) : Ov
data class BitmapLayer(
    val bitmap: Bitmap, val layerName: String,
    override val visible: Boolean = true, override val opacity: Float = 1f,
    val offsetX: Float = 0f, val offsetY: Float = 0f,
    val scale: Float = 1f, val rotation: Float = 0f,
    val blendMode: AdvancedImageOps.BlendMode = AdvancedImageOps.BlendMode.NORMAL,
    val mask: Bitmap? = null, override val locked: Boolean = false, val channelMask: Int = 7,
    val smartFilters: List<SmartFilter> = emptyList()
) : Ov
data class Stroke(val pts: List<Offset>, val color: Int, val w: Float, override val visible: Boolean = true, override val opacity: Float = 1f, override val locked: Boolean = false, val mask: Bitmap? = null) : Ov
data class PathLayer(
    val pts: List<Offset>, val color: Int, val w: Float, val closed: Boolean, val rounded: Boolean,
    val filled: Boolean = false, override val visible: Boolean = true, override val opacity: Float = 1f,
    val incoming: List<Offset> = List(pts.size) { Offset.Zero },
    val outgoing: List<Offset> = List(pts.size) { Offset.Zero },
    val smoothNodes: Set<Int> = emptySet(),
    override val locked: Boolean = false,
    val mask: Bitmap? = null,
    val booleanPath: Path? = null
) : Ov
data class Label(val text: String, val at: Offset, val color: Int, val size: Float, val strokeColor: Int = android.graphics.Color.TRANSPARENT, val strokeWidth: Float = 0f, val shadowColor: Int = android.graphics.Color.TRANSPARENT, val shadowRadius: Float = 0f, val letterSpacing: Float = 0f, val bold: Boolean = false, val fontFamily: Int = 0, override val visible: Boolean = true, override val opacity: Float = 1f, val rotation: Float = 0f, val align: Int = 1, val backgroundColor: Int = android.graphics.Color.TRANSPARENT, val backgroundPadding: Float = 0f, val typefaceName: String = "", val italic: Boolean = false, val lineSpacing: Float = 1.2f, val backgroundRadius: Float = 0f, override val locked: Boolean = false, val mask: Bitmap? = null) : Ov
fun overlayMeta(o: Ov, visible: Boolean = o.visible, opacity: Float = o.opacity): Ov = when(o) {
    is BitmapLayer -> BitmapLayer(o.bitmap,o.layerName,visible,opacity,o.offsetX,o.offsetY,o.scale,o.rotation,o.blendMode,o.mask,o.locked,o.channelMask,o.smartFilters)
    is AdjustmentLayer -> o.copy(visible=visible,opacity=opacity)
    is Stroke -> o.copy(visible=visible,opacity=opacity)
    is PathLayer -> o.copy(visible=visible,opacity=opacity)
    is Label -> o.copy(visible=visible,opacity=opacity)
}

fun overlayMask(o: Ov, mask: Bitmap?): Ov = when(o) {
    is BitmapLayer -> o.copy(mask=mask)
    is AdjustmentLayer -> o.copy(mask=mask)
    is Stroke -> o.copy(mask=mask)
    is PathLayer -> o.copy(mask=mask)
    is Label -> o.copy(mask=mask)
}

fun overlayLock(o: Ov, locked: Boolean): Ov = when(o) {
    is BitmapLayer -> o.copy(locked=locked)
    is AdjustmentLayer -> o.copy(locked=locked)
    is Stroke -> o.copy(locked=locked)
    is PathLayer -> o.copy(locked=locked)
    is Label -> o.copy(locked=locked)
}
fun overlayGetMask(o: Ov): Bitmap? = when(o) {
    is BitmapLayer -> o.mask
    is AdjustmentLayer -> o.mask
    is Stroke -> o.mask
    is PathLayer -> o.mask
    is Label -> o.mask
}


fun createPresetVectorPath(kind: String, left: Float, top: Float, right: Float, bottom: Float): Path {
    val p=Path(); val w=right-left; val h=bottom-top; val cx=(left+right)/2f; val cy=(top+bottom)/2f
    fun polygon(points: List<Offset>, close: Boolean=true){if(points.isEmpty())return;p.moveTo(points.first().x,points.first().y);points.drop(1).forEach{p.lineTo(it.x,it.y)};if(close)p.close()}
    when(kind){
        "rectangle"->p.addRect(left,top,right,bottom,Path.Direction.CW)
        "rounded_rectangle"->p.addRoundRect(RectF(left,top,right,bottom),minOf(w,h)*.12f,minOf(w,h)*.12f,Path.Direction.CW)
        "circle"->p.addOval(RectF(left,top,right,bottom),Path.Direction.CW)
        "line"->{p.moveTo(left,top);p.lineTo(right,bottom)}
        "arrow","double_arrow"->{val shaft=h*.22f;val head=w*.22f;val pts=if(kind=="arrow") listOf(Offset(left,cy-shaft/2),Offset(right-head,cy-shaft/2),Offset(right-head,top),Offset(right,bottom.coerceAtMost(top+h)),Offset(right-head,cy+shaft/2),Offset(left,cy+shaft/2)) else listOf(Offset(left,cy),Offset(left+head,top),Offset(left+head,cy-shaft/2),Offset(right-head,cy-shaft/2),Offset(right-head,top),Offset(right,cy),Offset(right-head,bottom),Offset(right-head,cy+shaft/2),Offset(left+head,cy+shaft/2),Offset(left+head,bottom));polygon(pts)}
        "triangle"->polygon(listOf(Offset(cx,top),Offset(right,bottom),Offset(left,bottom)))
        "diamond"->polygon(listOf(Offset(cx,top),Offset(right,cy),Offset(cx,bottom),Offset(left,cy)))
        "pentagon","hexagon","octagon","star"->{val count=when(kind){"pentagon"->5;"hexagon"->6;"octagon"->8;else->10};val rx=w/2f;val ry=h/2f;val pts=(0 until count).map{i->val a=-Math.PI/2.0+i*2.0*Math.PI/count;val r=if(kind=="star" && i%2==1) .43f else 1f;Offset(cx+(kotlin.math.cos(a)*rx*r).toFloat(),cy+(kotlin.math.sin(a)*ry*r).toFloat())};polygon(pts)}
        "heart"->{p.moveTo(cx,bottom);p.cubicTo(left-h*.05f,cy+h*.25f,left,top+h*.18f,cx-w*.12f,top+h*.38f);p.cubicTo(cx-w*.02f,top-h*.02f,cx+w*.02f,top-h*.02f,cx+w*.12f,top+h*.38f);p.cubicTo(right,top+h*.18f,right+h*.05f,cy+h*.25f,cx,bottom);p.close()}
        "cross"->{val t=minOf(w,h)*.32f;p.addRect(cx-t/2,top,cx+t/2,bottom,Path.Direction.CW);p.addRect(left,cy-t/2,right,cy+t/2,Path.Direction.CW)}
        "speech"->{p.addRoundRect(RectF(left,top,right,bottom-h*.18f),minOf(w,h)*.1f,minOf(w,h)*.1f,Path.Direction.CW);p.moveTo(left+w*.22f,bottom-h*.18f);p.lineTo(left+w*.12f,bottom);p.lineTo(left+w*.42f,bottom-h*.18f);p.close()}
        else->p.addRect(left,top,right,bottom,Path.Direction.CW)
    }
    return p
}

fun transformOverlayMask(mask: Bitmap?, matrix: Matrix): Bitmap? {
    if(mask==null) return null
    val out=Bitmap.createBitmap(mask.width,mask.height,Bitmap.Config.ARGB_8888)
    AndroidCanvas(out).drawBitmap(mask,matrix,Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
    return out
}
fun pathLayerBounds(layer: PathLayer): RectF {
    val path=layer.booleanPath
    if(path!=null){val r=RectF();path.computeBounds(r,true);return r}
    if(layer.pts.isEmpty()) return RectF()
    return RectF(layer.pts.minOf{it.x},layer.pts.minOf{it.y},layer.pts.maxOf{it.x},layer.pts.maxOf{it.y})
}
class Snap(val b: Bitmap?, val o: List<Ov>, val v: FloatArray, val f: Int)

enum class Tool(val label: String) {
    ADJUST("ضبط"), FILTER("فلاتر"), SMART_FILTERS("Smart Filters"), CINEMA("تلوين سينمائي"), SUN("ضوء الشمس"), EFFECTS("حدة وتأثيرات"), CROP("قص / منظور"), ROTATE("تدوير حر"), ZOOM("تقريب"), FREE("قص حر"), DRAW("رسم"), TEXT("نص"), STICKER("ملصقات"), MOVE("تحريك"), HSL("HSL"), CURVES("منحنيات"), GRADIENT("تدرج"), DOUBLE("دمج صورتين"), LAYERS("الطبقات"), AI("أدوات AI"), MASKS("التحديد والأقنعة"), HEAL("إصلاح / إزالة يدوي"), SHAPES("الأشكال"), PATH("رسم شكل بالنقاط")
}

fun rotatePointAround(point: Offset, center: Offset, degrees: Float): Offset {
    val radians=Math.toRadians(degrees.toDouble()); val dx=point.x-center.x; val dy=point.y-center.y
    return Offset(center.x+(dx*kotlin.math.cos(radians)-dy*kotlin.math.sin(radians)).toFloat(),center.y+(dx*kotlin.math.sin(radians)+dy*kotlin.math.cos(radians)).toFloat())
}

fun buildMatrix(b: Float, c: Float, s: Float, f: Int, w: Float = 0f): ColorMatrix {
    val m = ColorMatrix(); m.setSaturation(s)
    val t = (1 - c) * 128 + b
    m.postConcat(ColorMatrix(floatArrayOf(c, 0f, 0f, 0f, t, 0f, c, 0f, 0f, t, 0f, 0f, c, 0f, t, 0f, 0f, 0f, 1f, 0f)))
    m.postConcat(ColorMatrix(floatArrayOf(1f, 0f, 0f, 0f, w, 0f, 1f, 0f, 0f, 0f, 0f, 0f, 1f, 0f, -w, 0f, 0f, 0f, 1f, 0f)))
    when (f) {
        1 -> m.postConcat(ColorMatrix().apply { setSaturation(0f) })
        2 -> m.postConcat(ColorMatrix(floatArrayOf(.393f, .769f, .189f, 0f, 0f, .349f, .686f, .168f, 0f, 0f, .272f, .534f, .131f, 0f, 0f, 0f, 0f, 0f, 1f, 0f)))
        3 -> m.postConcat(ColorMatrix(floatArrayOf(-1f, 0f, 0f, 0f, 255f, 0f, -1f, 0f, 0f, 255f, 0f, 0f, -1f, 0f, 255f, 0f, 0f, 0f, 1f, 0f)))
        4 -> m.postConcat(ColorMatrix(floatArrayOf(.9f, .1f, 0f, 0f, 10f, 0f, .9f, .1f, 0f, 5f, .1f, 0f, .7f, 0f, 15f, 0f, 0f, 0f, 1f, 0f)))
        5 -> m.postConcat(ColorMatrix(floatArrayOf(.9f, 0f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 0f, 1.15f, 0f, 10f, 0f, 0f, 0f, 1f, 0f)))
        6 -> m.postConcat(ColorMatrix(floatArrayOf(1.15f, 0f, 0f, 0f, 10f, 0f, 1f, 0f, 0f, 0f, 0f, 0f, .85f, 0f, 0f, 0f, 0f, 0f, 1f, 0f)))
    }
    return m
}

class Fx(val vig: Float = 0f, val grain: Float = 0f, val blur: Float = 0f, val sh: Float = 0f, val hl: Float = 0f)

private var blurKey: Bitmap? = null
private var blurN = -1
private var blurOut: Bitmap? = null

fun blurred(b: Bitmap, lvl: Float): Bitmap {
    val n = (lvl * 20f).toInt()
    if (n <= 0) return b
    if (blurKey === b && blurN == n) blurOut?.let { return it }
    val tw = maxOf(1, b.width / (n + 1)); val th = maxOf(1, b.height / (n + 1))
    var cur = b
    while (cur.width > tw) {
        cur = Bitmap.createScaledBitmap(cur, maxOf(tw, cur.width / 2), maxOf(th, cur.height / 2), true)
    }
    blurKey = b; blurN = n; blurOut = cur
    return cur
}

val noiseBmp: Bitmap by lazy {
    val r = java.util.Random(7)
    val px = IntArray(256 * 256) {
        val a = r.nextInt(256)
        if (r.nextBoolean()) ((a shl 24) or 0xFFFFFF) else (a shl 24)
    }
    Bitmap.createBitmap(px, 256, 256, Bitmap.Config.ARGB_8888)
}

private fun sp(c: Int, l: Int, r: Int, u: Int, d: Int, sh: Int, amt: Float): Int {
    val v = (c shr sh) and 255
    val n = ((l shr sh) and 255) + ((r shr sh) and 255) + ((u shr sh) and 255) + ((d shr sh) and 255)
    return ((v + amt * (4 * v - n)).toInt().coerceIn(0, 255)) shl sh
}

fun sharpen(b: Bitmap, amt: Float): Bitmap {
    val w = b.width; val h = b.height
    val src = IntArray(w * h); b.getPixels(src, 0, w, 0, 0, w, h)
    val dst = IntArray(w * h)
    for (y in 0 until h) {
        val ym = if (y > 0) y - 1 else 0; val yp = if (y < h - 1) y + 1 else y
        for (x in 0 until w) {
            val xm = if (x > 0) x - 1 else 0; val xp = if (x < w - 1) x + 1 else x
            val c = src[y * w + x]; val l = src[y * w + xm]; val r = src[y * w + xp]
            val u = src[ym * w + x]; val d = src[yp * w + x]
            dst[y * w + x] = (c and 0xFF000000.toInt()) or sp(c, l, r, u, d, 16, amt) or sp(c, l, r, u, d, 8, amt) or sp(c, l, r, u, d, 0, amt)
        }
    }
    val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    out.setPixels(dst, 0, w, 0, 0, w, h)
    return out
}

fun zoomRect(b: Bitmap, zf: Float, zc: Offset): FloatArray {
    val w = b.width / zf; val h = b.height / zf
    val x = (zc.x - w / 2).coerceIn(0f, b.width - w); val y = (zc.y - h / 2).coerceIn(0f, b.height - h)
    return floatArrayOf(x, y, x + w, y + h)
}

fun paintAll(c: AndroidCanvas, bmp: Bitmap, cm: ColorMatrix?, ovs: List<Ov>, fx: Fx = Fx()) {
    val w = bmp.width.toFloat(); val h = bmp.height.toFloat()
    val p = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    if (cm != null) p.colorFilter = ColorMatrixColorFilter(cm)
    val src = blurred(bmp, fx.blur)
    val dst = RectF(0f, 0f, w, h)
    c.drawBitmap(src, null, dst, p)
    if (fx.sh > 0f) {
        p.xfermode = PorterDuffXfermode(PorterDuff.Mode.SCREEN); p.alpha = (fx.sh * 255).toInt()
        c.drawBitmap(src, null, dst, p)
    }
    if (fx.hl > 0f) {
        p.xfermode = PorterDuffXfermode(PorterDuff.Mode.MULTIPLY); p.alpha = (fx.hl * 255).toInt()
        c.drawBitmap(src, null, dst, p)
    }
    if (fx.vig > 0f) {
        val r = Math.hypot(w.toDouble(), h.toDouble()).toFloat() / 2f
        val vp = Paint()
        vp.shader = RadialGradient(w / 2, h / 2, r, intArrayOf(0x00000000, 0x00000000, ((fx.vig * 230).toInt() shl 24)), floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, vp)
    }
    if (fx.grain > 0f) {
        val gp = Paint()
        val shd = BitmapShader(noiseBmp, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
        val k = maxOf(1f, maxOf(w, h) / 1000f)
        shd.setLocalMatrix(Matrix().apply { setScale(k, k) })
        gp.shader = shd; gp.alpha = (fx.grain * 200).toInt()
        c.drawRect(0f, 0f, w, h, gp)
    }
    val q = Paint(Paint.ANTI_ALIAS_FLAG)
    fun drawMaskedLayer(mask: Bitmap?, opacity: Float, draw: (AndroidCanvas) -> Unit) {
        if (mask == null) { draw(c); return }
        val temp = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
        draw(AndroidCanvas(temp))
        val masked = ProfessionalEditing.applyMask(temp, mask)
        c.drawBitmap(masked, 0f, 0f, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { alpha=(opacity.coerceIn(0f,1f)*255).toInt() })
        masked.recycle(); temp.recycle()
    }
    for ((layerIndex, o) in ovs.withIndex()) {
        if (!o.visible) continue
        q.alpha = (o.opacity.coerceIn(0f,1f)*255).toInt()
        when (o) {
        is AdjustmentLayer -> {
            val index = layerIndex
            if (index >= 0) {
                val snapshot = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
                paintAll(AndroidCanvas(snapshot), bmp, cm, ovs.take(index), fx)
                val adjusted = ProfessionalEditing.applyAdjustment(snapshot, o.adjustment)
                val filteredAdjusted = if (o.smartFilters.isNotEmpty()) SmartFilterEngine.apply(adjusted, o.smartFilters) else adjusted
                if (filteredAdjusted !== adjusted) adjusted.recycle()
                val masked = o.mask?.let { ProfessionalEditing.applyMask(filteredAdjusted, it) } ?: filteredAdjusted
                val ap = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { alpha=(o.opacity.coerceIn(0f,1f)*255).toInt() }
                c.drawBitmap(masked, 0f, 0f, ap)
                if (masked !== filteredAdjusted) masked.recycle()
                filteredAdjusted.recycle(); snapshot.recycle()
            }
        }
        is BitmapLayer -> {
            q.style=Paint.Style.FILL
            q.xfermode = PorterDuffXfermode(when(o.blendMode) {
                AdvancedImageOps.BlendMode.MULTIPLY -> PorterDuff.Mode.MULTIPLY
                AdvancedImageOps.BlendMode.SCREEN -> PorterDuff.Mode.SCREEN
                AdvancedImageOps.BlendMode.OVERLAY -> PorterDuff.Mode.OVERLAY
                AdvancedImageOps.BlendMode.LIGHTEN -> PorterDuff.Mode.LIGHTEN
                AdvancedImageOps.BlendMode.DARKEN -> PorterDuff.Mode.DARKEN
                AdvancedImageOps.BlendMode.ADD -> PorterDuff.Mode.ADD
                AdvancedImageOps.BlendMode.SRC_ATOP -> PorterDuff.Mode.SRC_ATOP
                AdvancedImageOps.BlendMode.XOR -> PorterDuff.Mode.XOR
                else -> PorterDuff.Mode.SRC_OVER
            })
            if (o.blendMode == AdvancedImageOps.BlendMode.DIFFERENCE && android.os.Build.VERSION.SDK_INT >= 29) q.blendMode = android.graphics.BlendMode.DIFFERENCE
            val cx=w/2f; val cy=h/2f
            c.save(); c.translate(cx+o.offsetX,cy+o.offsetY); c.rotate(o.rotation); c.scale(o.scale,o.scale)
            val filteredBitmap = if (o.smartFilters.isNotEmpty()) SmartFilterEngine.apply(o.bitmap, o.smartFilters) else o.bitmap
            val layerBitmap = o.mask?.let { ProfessionalEditing.applyMask(filteredBitmap, it) } ?: filteredBitmap
            if(o.channelMask!=7){ val cm=ColorMatrix(floatArrayOf(
                if(o.channelMask and 1 != 0) 1f else 0f,0f,0f,0f,0f,
                0f,if(o.channelMask and 2 != 0) 1f else 0f,0f,0f,0f,
                0f,0f,if(o.channelMask and 4 != 0) 1f else 0f,0f,0f,
                0f,0f,0f,1f,0f)); q.colorFilter=ColorMatrixColorFilter(cm) }
            c.drawBitmap(layerBitmap,null,RectF(-cx,-cy,cx,cy),q); c.restore(); if(layerBitmap !== filteredBitmap) layerBitmap.recycle(); if(filteredBitmap !== o.bitmap) filteredBitmap.recycle(); q.xfermode=null; q.colorFilter=null; if(android.os.Build.VERSION.SDK_INT>=29) q.blendMode=null
        }
        is Stroke -> drawMaskedLayer(o.mask, o.opacity) { layerCanvas ->
            q.style = Paint.Style.STROKE; q.strokeCap = Paint.Cap.ROUND; q.strokeJoin = Paint.Join.ROUND
            q.color = o.color; q.alpha=android.graphics.Color.alpha(o.color); q.strokeWidth = o.w
            val path = Path()
            o.pts.forEachIndexed { i, pt -> if (i == 0) path.moveTo(pt.x, pt.y) else path.lineTo(pt.x, pt.y) }
            if (o.pts.size == 1) path.lineTo(o.pts[0].x + 0.1f, o.pts[0].y)
            layerCanvas.drawPath(path, q)
        }
        is PathLayer -> drawMaskedLayer(o.mask, o.opacity) { layerCanvas ->
            val path = o.booleanPath ?: if (o.pts.size >= 2) Path().apply {
                moveTo(o.pts.first().x,o.pts.first().y)
                for(i in 1 until o.pts.size){val a=o.pts[i-1];val b=o.pts[i];val c1=a+o.outgoing.getOrElse(i-1){Offset.Zero};val c2=b+o.incoming.getOrElse(i){Offset.Zero};if(o.outgoing.getOrElse(i-1){Offset.Zero}!=Offset.Zero || o.incoming.getOrElse(i){Offset.Zero}!=Offset.Zero)cubicTo(c1.x,c1.y,c2.x,c2.y,b.x,b.y) else if(o.rounded && o.pts.size>=3){val mx=(a.x+b.x)/2f;val my=(a.y+b.y)/2f;quadTo(a.x,a.y,mx,my)}else lineTo(b.x,b.y)}
                if(o.closed) close()
            } else null
            if(path!=null){q.color=o.color;q.alpha=android.graphics.Color.alpha(o.color);q.strokeWidth=o.w;q.strokeJoin=Paint.Join.ROUND;q.strokeCap=Paint.Cap.ROUND;q.style=if(o.filled) Paint.Style.FILL_AND_STROKE else Paint.Style.STROKE;layerCanvas.drawPath(path,q)}
        }
        is Label -> drawMaskedLayer(o.mask, o.opacity) { layerCanvas ->
            val align = when(o.align){0->Paint.Align.LEFT;2->Paint.Align.RIGHT;else->Paint.Align.CENTER}
            q.textSize=o.size; q.textAlign=align; q.letterSpacing=o.letterSpacing
            val style=when { o.bold && o.italic -> android.graphics.Typeface.BOLD_ITALIC; o.bold -> android.graphics.Typeface.BOLD; o.italic -> android.graphics.Typeface.ITALIC; else -> android.graphics.Typeface.NORMAL }
            val family=if(o.typefaceName.isNotBlank()) o.typefaceName else when(o.fontFamily){1->"serif";2->"monospace";3->"sans-serif-condensed";4->"casual";5->"cursive";else->"sans-serif"}
            q.typeface=try { if(family.startsWith("/") && File(family).exists()) android.graphics.Typeface.createFromFile(family) else android.graphics.Typeface.create(family,style) } catch (_:Throwable) { android.graphics.Typeface.create("sans-serif",style) }
            val lines=o.text.split('\n'); val lineHeight=o.size*o.lineSpacing.coerceIn(0.8f,2.5f)
            val textW=lines.maxOfOrNull{q.measureText(it)} ?: 0f
            val left=when(o.align){0->o.at.x;2->o.at.x-textW;else->o.at.x-textW/2f}
            val save=layerCanvas.save(); layerCanvas.rotate(o.rotation,o.at.x,o.at.y)
            if(o.backgroundColor!=android.graphics.Color.TRANSPARENT){
                val pad=o.backgroundPadding
                q.style=Paint.Style.FILL; q.color=o.backgroundColor; q.alpha=android.graphics.Color.alpha(o.backgroundColor)
                layerCanvas.drawRoundRect(RectF(left-pad,o.at.y-o.size-pad,left+textW+pad,o.at.y+(lines.size-1)*lineHeight+o.size*.22f+pad),o.backgroundRadius.coerceAtLeast(pad*.2f),o.backgroundRadius.coerceAtLeast(pad*.2f),q)
            }
            if(o.shadowRadius>0f && o.shadowColor!=android.graphics.Color.TRANSPARENT) q.setShadowLayer(o.shadowRadius,o.shadowRadius*.35f,o.shadowRadius*.35f,o.shadowColor)
            lines.forEachIndexed { index,line ->
                val baseline=o.at.y+index*lineHeight
                if(o.strokeWidth>0f && o.strokeColor!=android.graphics.Color.TRANSPARENT){q.style=Paint.Style.STROKE;q.strokeJoin=Paint.Join.ROUND;q.strokeWidth=o.strokeWidth;q.color=o.strokeColor;q.alpha=android.graphics.Color.alpha(o.strokeColor);layerCanvas.drawText(line,o.at.x,baseline,q)}
                q.style=Paint.Style.FILL;q.color=o.color;q.alpha=android.graphics.Color.alpha(o.color);layerCanvas.drawText(line,o.at.x,baseline,q)
            }
            q.clearShadowLayer();layerCanvas.restoreToCount(save)
        }
        }
    }
}

/** Build a lightweight contour path from the alpha mask for a visible selection boundary. */
fun buildSelectionOutline(mask: Bitmap): Path {
    val maxSide = 1000
    val scale = minOf(1f, maxSide.toFloat() / maxOf(mask.width, mask.height).coerceAtLeast(1))
    val sw = maxOf(1, (mask.width * scale).toInt())
    val sh = maxOf(1, (mask.height * scale).toInt())
    val sample = if (sw == mask.width && sh == mask.height) mask else Bitmap.createScaledBitmap(mask, sw, sh, true)
    val pixels = IntArray(sw * sh)
    sample.getPixels(pixels, 0, sw, 0, 0, sw, sh)
    val sx = mask.width.toFloat() / sw
    val sy = mask.height.toFloat() / sh
    val path = Path()
    fun selected(x: Int, y: Int) = x in 0 until sw && y in 0 until sh && (pixels[y * sw + x] ushr 24) >= 112
    for (y in 0 until sh) for (x in 0 until sw) {
        if (!selected(x, y)) continue
        val l = x * sx; val r = (x + 1) * sx
        val t = y * sy; val b = (y + 1) * sy
        if (!selected(x, y - 1)) { path.moveTo(l, t); path.lineTo(r, t) }
        if (!selected(x + 1, y)) { path.moveTo(r, t); path.lineTo(r, b) }
        if (!selected(x, y + 1)) { path.moveTo(r, b); path.lineTo(l, b) }
        if (!selected(x - 1, y)) { path.moveTo(l, b); path.lineTo(l, t) }
    }
    if (sample !== mask) sample.recycle()
    return path
}

fun cropRatio(b: Bitmap, rw: Int, rh: Int): Bitmap {
    var w = b.width; var h = w * rh / rw
    if (h > b.height) { h = b.height; w = h * rw / rh }
    return Bitmap.createBitmap(b, (b.width - w) / 2, (b.height - h) / 2, w, h)
}

fun inscribedSize(w: Float, h: Float, deg: Float): Pair<Float, Float> {
    val a = Math.toRadians(Math.abs(deg).toDouble())
    val sinA = Math.abs(Math.sin(a)); val cosA = Math.abs(Math.cos(a))
    if (sinA < 1e-6) return w to h
    val wide = w >= h
    val longS = maxOf(w, h).toDouble(); val shortS = minOf(w, h).toDouble()
    val wr: Double; val hr: Double
    if (shortS <= 2 * sinA * cosA * longS || Math.abs(sinA - cosA) < 1e-10) {
        val x = 0.5 * shortS
        if (wide) { wr = x / sinA; hr = x / cosA } else { wr = x / cosA; hr = x / sinA }
    } else {
        val c2 = cosA * cosA - sinA * sinA
        wr = (w * cosA - h * sinA) / c2; hr = (h * cosA - w * sinA) / c2
    }
    return wr.toFloat() to hr.toFloat()
}

fun rotateFree(b: Bitmap, deg: Float): Bitmap {
    if (deg == 0f) return b
    val (cw, ch) = inscribedSize(b.width.toFloat(), b.height.toFloat(), deg)
    val out = Bitmap.createBitmap(cw.toInt().coerceIn(1, b.width), ch.toInt().coerceIn(1, b.height), Bitmap.Config.ARGB_8888)
    val c = AndroidCanvas(out)
    c.translate(out.width / 2f, out.height / 2f)
    c.rotate(deg)
    c.translate(-b.width / 2f, -b.height / 2f)
    c.drawBitmap(b, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
    return out
}

val palette = listOf(0xFFFFFFFF, 0xFF000000, 0xFFE53935, 0xFFFB8C00, 0xFFFDD835, 0xFF43A047, 0xFF1E88E5, 0xFF8E24AA)
val emojis = listOf("😀", "😍", "😂", "🔥", "❤️", "⭐", "👍", "🎉", "🌹", "👑")

@Composable
fun EditorScreen() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("moknight_preferences", android.content.Context.MODE_PRIVATE) }
    var showSettings by remember { mutableStateOf(false) }
    var showModelManager by remember { mutableStateOf(false) }
    var appPage by remember { mutableStateOf(AppPage.HOME) }
    var editorMode by remember { mutableStateOf("تحرير") }
    val editorScope = rememberCoroutineScope()
    var importedLut by remember { mutableStateOf<CubeLut?>(null) }
    var importedLutName by remember { mutableStateOf("") }
    var lutBusy by remember { mutableStateOf(false) }
    var themePreset by remember { mutableIntStateOf(prefs.getInt("theme_preset", 0)) }
    var lastProjectUri by remember { mutableStateOf(prefs.getString("last_project_uri", null)) }
    var lastProjectName by remember { mutableStateOf(prefs.getString("last_project_name", null)) }
    LaunchedEffect(Unit) { MoKnightColors.applyPreset(themePreset) }
    val configuration = LocalConfiguration.current
    val isLandscape = configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
    BackHandler(enabled = appPage == AppPage.EDITOR) { appPage = AppPage.HOME }
    var base by remember { mutableStateOf<Bitmap?>(null) }
    val ovs = remember { mutableStateListOf<Ov>() }
    var tool by remember { mutableStateOf(Tool.ADJUST) }
    var bright by remember { mutableFloatStateOf(0f) }
    var contrast by remember { mutableFloatStateOf(1f) }
    var sat by remember { mutableFloatStateOf(1f) }
    var filter by remember { mutableIntStateOf(0) }
    var color by remember { mutableLongStateOf(0xFFE53935) }
    var penSize by remember { mutableFloatStateOf(0.012f) }
    var emoji by remember { mutableStateOf(emojis[0]) }
    var cur by remember { mutableStateOf<List<Offset>>(emptyList()) }
    var box by remember { mutableStateOf(IntSize.Zero) }
    var askAt by remember { mutableStateOf<Offset?>(null) }
    var txt by remember { mutableStateOf("") }
    var warmth by remember { mutableFloatStateOf(0f) }
    var exposure by remember { mutableFloatStateOf(0f) }
    var highlights by remember { mutableFloatStateOf(0f) }
    var shadows by remember { mutableFloatStateOf(0f) }
    var tint by remember { mutableFloatStateOf(0f) }
    var hslTarget by remember { mutableFloatStateOf(0f) }
    var hslHue by remember { mutableFloatStateOf(0f) }
    var hslSat by remember { mutableFloatStateOf(0f) }
    var hslLight by remember { mutableFloatStateOf(0f) }
    var curvePreset by remember { mutableIntStateOf(0) }
    var rgbChannel by remember { mutableIntStateOf(0) }
    var curveInput by remember { mutableFloatStateOf(.5f) }
    var curveOutput by remember { mutableFloatStateOf(.5f) }
    val curvePoints = remember { mutableStateListOf<AdvancedImageOps.CurvePoint>() }
    var straightenAngle by remember { mutableFloatStateOf(0f) }
    val perspectiveCorners = remember { mutableStateListOf<Offset>() }
    var selectedPerspectiveCorner by remember { mutableIntStateOf(-1) }
    var textureAmt by remember { mutableFloatStateOf(0f) }
    var gradientOpacity by remember { mutableFloatStateOf(0.35f) }
    var gradientAngle by remember { mutableFloatStateOf(45f) }
    var gradientStart by remember { mutableIntStateOf(0xFF243B80.toInt()) }
    var gradientEnd by remember { mutableIntStateOf(0xFFF04B8A.toInt()) }
    var gradientAlpha by remember { mutableFloatStateOf(1f) }
    var textStrokeWidth by remember { mutableFloatStateOf(0f) }
    var textBold by remember { mutableStateOf(false) }
    var textFamily by remember { mutableIntStateOf(0) }
    var textOutlineColor by remember { mutableIntStateOf(android.graphics.Color.BLACK) }
    var textSpacing by remember { mutableFloatStateOf(0f) }
    var textShadow by remember { mutableFloatStateOf(0f) }
    var pathPoints by remember { mutableStateOf<List<Offset>>(emptyList()) }
    var pathClosed by remember { mutableStateOf(true) }
    var pathRounded by remember { mutableStateOf(true) }
    var pathFilled by remember { mutableStateOf(false) }
    var pathEditIndex by remember { mutableIntStateOf(-1) }
    var pathSelectedPoint by remember { mutableIntStateOf(-1) }
    var booleanSecondIndex by remember { mutableIntStateOf(-1) }
    var bitmapTransformMode by remember { mutableIntStateOf(0) } // 0 move, 1 scale, 2 rotate
    var bitmapTransformStartDistance by remember { mutableFloatStateOf(1f) }
    var bitmapTransformStartAngle by remember { mutableFloatStateOf(0f) }
    var bitmapTransformStartScale by remember { mutableFloatStateOf(1f) }
    var bitmapTransformStartRotation by remember { mutableFloatStateOf(0f) }
    var overlayTransformMode by remember { mutableIntStateOf(0) } // 0 move, 1 scale, 2 rotate
    var overlayTransformStartDistance by remember { mutableFloatStateOf(1f) }
    var overlayTransformStartSize by remember { mutableFloatStateOf(1f) }
    var overlayTransformStartRotation by remember { mutableFloatStateOf(0f) }
    var overlayTransformStartAngle by remember { mutableFloatStateOf(0f) }
    var overlayTransformCenter by remember { mutableStateOf(Offset.Zero) }
    var cinemaWarmth by remember { mutableFloatStateOf(0f) }
    var cinemaTeal by remember { mutableFloatStateOf(0f) }
    var cinemaContrast by remember { mutableFloatStateOf(0f) }
    var cinemaVignette by remember { mutableFloatStateOf(0f) }
    var lookCategory by remember { mutableStateOf(LookPack.categories.first()) }
    var lookStrength by remember { mutableFloatStateOf(1f) }
    var lookStatus by remember { mutableStateOf("") }
    var cinemaBloom by remember { mutableFloatStateOf(0f) }
    var sunX by remember { mutableFloatStateOf(.75f) }
    var sunY by remember { mutableFloatStateOf(.2f) }
    var sunSize by remember { mutableFloatStateOf(.35f) }
    var sunIntensity by remember { mutableFloatStateOf(.9f) }
    var sunSoft by remember { mutableFloatStateOf(.6f) }
    var sunTemp by remember { mutableFloatStateOf(5800f) }
    var sunOpacity by remember { mutableFloatStateOf(1f) }
    var sunRays by remember { mutableFloatStateOf(0f) }
    var sunRayAngle by remember { mutableFloatStateOf(0f) }
    var sunRayLen by remember { mutableFloatStateOf(.8f) }
    var sunGhosts by remember { mutableFloatStateOf(0f) }
    var gradeExposure by remember { mutableFloatStateOf(0f) }
    var gradeHighlights by remember { mutableFloatStateOf(0f) }
    var gradeShadows by remember { mutableFloatStateOf(0f) }
    var gradeWhites by remember { mutableFloatStateOf(0f) }
    var gradeBlacks by remember { mutableFloatStateOf(0f) }
    var gradeTint by remember { mutableFloatStateOf(0f) }
    var gradeVibrance by remember { mutableFloatStateOf(0f) }
    var gradeSaturation by remember { mutableFloatStateOf(0f) }
    var shadowHue by remember { mutableFloatStateOf(210f) }
    var shadowAmount by remember { mutableFloatStateOf(0f) }
    var midHue by remember { mutableFloatStateOf(35f) }
    var midAmount by remember { mutableFloatStateOf(0f) }
    var highlightHue by remember { mutableFloatStateOf(42f) }
    var highlightAmount by remember { mutableFloatStateOf(0f) }
    var gradeBalance by remember { mutableFloatStateOf(0f) }
    var creativeFxId by remember { mutableIntStateOf(0) }
    var creativeFxAmount by remember { mutableFloatStateOf(.35f) }
    var hairEdgeContrast by remember { mutableFloatStateOf(1.25f) }
    var hairEdgeFeather by remember { mutableFloatStateOf(.12f) }
    var textBgColor by remember { mutableIntStateOf(0xCC101820.toInt()) }
    var textBgOpacity by remember { mutableFloatStateOf(0.8f) }
    var textBgPadding by remember { mutableFloatStateOf(0.018f) }
    var textRotation by remember { mutableFloatStateOf(0f) }
    var textAlign by remember { mutableIntStateOf(1) }
    var textTypefaceName by remember { mutableStateOf("") }
    var textItalic by remember { mutableStateOf(false) }
    var textLineSpacing by remember { mutableFloatStateOf(1.2f) }
    var textBgRadius by remember { mutableFloatStateOf(0.02f) }
    var textBehindSubject by remember { mutableStateOf(false) }
    var smartRepair by remember { mutableStateOf(false) }
    var maskBrushRadius by remember { mutableFloatStateOf(60f) }
    var maskFeather by remember { mutableFloatStateOf(.18f) }
    var maskErase by remember { mutableStateOf(false) }
    var editLayerMask by remember { mutableStateOf(false) }
    var blendOpacity by remember { mutableFloatStateOf(0.5f) }
    var blendMode by remember { mutableStateOf(AdvancedImageOps.BlendMode.SCREEN) }
    var blendChannels by remember { mutableIntStateOf(7) }
    var blendIfEnabled by remember { mutableStateOf(false) }
    var blendUseSelectionMask by remember { mutableStateOf(false) }
    var blendIfShadow by remember { mutableFloatStateOf(.08f) }
    var blendIfHighlight by remember { mutableFloatStateOf(.94f) }
    var blendIfSoftness by remember { mutableFloatStateOf(.16f) }
    var blendScale by remember { mutableFloatStateOf(1f) }
    var blendRotation by remember { mutableFloatStateOf(0f) }
    var blendOffsetX by remember { mutableFloatStateOf(0f) }
    var blendOffsetY by remember { mutableFloatStateOf(0f) }
    var shapeLeft by remember { mutableFloatStateOf(.2f) }
    var shapeTop by remember { mutableFloatStateOf(.2f) }
    var shapeWidth by remember { mutableFloatStateOf(.6f) }
    var shapeHeight by remember { mutableFloatStateOf(.6f) }
    var previousMask by remember { mutableStateOf<Bitmap?>(null) }
    var maskHardness by remember { mutableFloatStateOf(.72f) }
    var maskName by remember { mutableStateOf("تحديد 1") }
    var layerRename by remember { mutableStateOf("") }
    var overlayBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var subjectMask by remember { mutableStateOf<Bitmap?>(null) }
    val selectionOutline = remember(subjectMask) { subjectMask?.let(::buildSelectionOutline) }
    var aiPickMode by remember { mutableStateOf(false) }
    var aiBusy by remember { mutableStateOf(false) }
    var aiStatus by remember { mutableStateOf("اختر صورة ثم شغّل التحديد الذكي") }
    var aiPrompt by remember { mutableStateOf("") }
    var removalModelReady by remember { mutableStateOf(AiModelManager.isInstalled(ctx, AiModelManager.objectRemoval)) }
    var generativeModelReady by remember { mutableStateOf(AiModelManager.isInstalled(ctx, AiModelManager.generativeFill)) }
    var htmlDraft by remember { mutableStateOf("<b style='color:#FFC107;font-size:32px'>MoKnight</b>") }
    var gpuStatus by remember { mutableStateOf("") }
    var healSource by remember { mutableStateOf<Offset?>(null) }
    var healRadius by remember { mutableFloatStateOf(48f) }
    var shapeKind by remember { mutableStateOf("rectangle") }
    var shapeFilled by remember { mutableStateOf(false) }
    var showOrig by remember { mutableStateOf(false) }
    var sel by remember { mutableIntStateOf(-1) }
    var crop by remember { mutableStateOf<FloatArray?>(null) }
    var corner by remember { mutableIntStateOf(-1) }
    var angle by remember { mutableFloatStateOf(0f) }
    var vig by remember { mutableFloatStateOf(0f) }
    var grain by remember { mutableFloatStateOf(0f) }
    var blur by remember { mutableFloatStateOf(0f) }
    var shad by remember { mutableFloatStateOf(0f) }
    var hil by remember { mutableFloatStateOf(0f) }
    var sharpAmt by remember { mutableFloatStateOf(0.5f) }
    var clarityAmt by remember { mutableFloatStateOf(0f) }
    var vs by remember { mutableFloatStateOf(1f) }
    var vo by remember { mutableStateOf(Offset.Zero) }
    var zf by remember { mutableFloatStateOf(1f) }
    var zc by remember { mutableStateOf(Offset.Zero) }
    fun fx() = Fx(vig, grain, blur, shad, hil)
    val hist = remember { mutableStateListOf<Snap>() }
    var hi by remember { mutableIntStateOf(-1) }
    var activeToolGroup by remember { mutableStateOf("أساسي") }
    val toolGroups = listOf(
        "أساسي" to listOf(Tool.ADJUST, Tool.CROP, Tool.ROTATE, Tool.ZOOM, Tool.FREE, Tool.MOVE),
        "الألوان" to listOf(Tool.FILTER, Tool.SMART_FILTERS, Tool.CINEMA, Tool.SUN, Tool.HSL, Tool.CURVES, Tool.EFFECTS, Tool.GRADIENT),
        "AI والتحديد" to listOf(Tool.AI, Tool.MASKS, Tool.HEAL),
        "التصميم والطبقات" to listOf(Tool.LAYERS, Tool.DRAW, Tool.TEXT, Tool.STICKER, Tool.SHAPES, Tool.PATH, Tool.DOUBLE)
    )

    fun commit() {
        while (hist.size > hi + 1) hist.removeAt(hist.lastIndex)
        hist.add(Snap(base, ovs.toList(), floatArrayOf(bright, contrast, sat, warmth, vig, grain, blur, shad, hil), filter))
        if (hist.size > 25) hist.removeAt(1)
        hi = hist.lastIndex
    }
    fun restore(i: Int) {
        val s = hist[i]; hi = i; base = s.b; ovs.clear(); ovs.addAll(s.o)
        bright = s.v[0]; contrast = s.v[1]; sat = s.v[2]; warmth = s.v[3]; vig = s.v[4]; grain = s.v[5]; blur = s.v[6]; shad = s.v[7]; hil = s.v[8]; filter = s.f; sel = -1
    }
    LaunchedEffect(tool, base) {
        val b = base
        crop = if (tool == Tool.FREE && b != null) floatArrayOf(b.width * .1f, b.height * .1f, b.width * .9f, b.height * .9f) else null
        perspectiveCorners.clear()
        if (b != null) perspectiveCorners.addAll(listOf(
            Offset(0f, 0f), Offset(b.width.toFloat(), 0f),
            Offset(b.width.toFloat(), b.height.toFloat()), Offset(0f, b.height.toFloat())
        ))
        selectedPerspectiveCorner = -1
        angle = 0f; zf = 1f
        zc = if (b != null) Offset(b.width / 2f, b.height / 2f) else Offset.Zero
    }

    val pickFont = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if(uri!=null){
            runCatching {
                val dir=File(ctx.filesDir,"fonts").apply{mkdirs()}
                val file=File(dir,"font_${System.currentTimeMillis()}.ttf")
                ctx.contentResolver.openInputStream(uri)?.use { input -> file.outputStream().use { output -> input.copyTo(output) } }
                textTypefaceName=file.absolutePath
                (ovs.getOrNull(sel) as? Label)?.let { selected -> ovs[sel]=selected.copy(typefaceName=file.absolutePath) }
                Toast.makeText(ctx,"تم استيراد الخط",Toast.LENGTH_SHORT).show()
            }.onFailure { Toast.makeText(ctx,"تعذر استيراد الخط",Toast.LENGTH_SHORT).show() }
        }
    }

    val pickCubeLut = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                val source = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: error("تعذر قراءة ملف LUT")
                importedLut = CubeLut.parse(source)
                importedLutName = uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':') ?: "LUT.cube"
                Toast.makeText(ctx, "تم تحميل LUT: $importedLutName", Toast.LENGTH_SHORT).show()
            }.onFailure { Toast.makeText(ctx, "ملف LUT غير صالح: ${it.message}", Toast.LENGTH_LONG).show() }
        }
    }

    val pickOverlay = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) { overlayBitmap = ImageDecoder.decodeBitmap(ImageDecoder.createSource(ctx.contentResolver, uri)) { d, info, _ -> d.isMutableRequired = true; val sample = maxOf(info.size.width, info.size.height) / 2048; if (sample > 1) d.setTargetSampleSize(sample) } }
    }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            appPage = AppPage.EDITOR
            editorMode = "تحرير"
            base = ImageDecoder.decodeBitmap(ImageDecoder.createSource(ctx.contentResolver, uri)) { d, info, _ ->
                d.isMutableRequired = true
                val s = maxOf(info.size.width, info.size.height) / 2048
                if (s > 1) d.setTargetSampleSize(s)
            }
            ovs.clear(); sel=-1; subjectMask = null; aiPickMode=false; aiStatus = "الصورة جاهزة للتحليل"; bright = 0f; contrast = 1f; sat = 1f; warmth = 0f; vig = 0f; grain = 0f; blur = 0f; shad = 0f; hil = 0f
            filter = 0; vs = 1f; vo = Offset.Zero; hist.clear(); hi = -1; commit()
        }
    }

    fun maxDim() = base?.let { maxOf(it.width, it.height).toFloat() } ?: 1f
    fun sc() = base?.let { minOf(box.width.toFloat() / it.width, box.height.toFloat() / it.height) * vs } ?: 1f
    fun clampVo(o: Offset, z: Float): Offset {
        val mx = box.width * (z - 1f) / 2f; val my = box.height * (z - 1f) / 2f
        return Offset(o.x.coerceIn(-mx, mx), o.y.coerceIn(-my, my))
    }
    fun toBmp(p: Offset): Offset {
        val b = base!!
        val sc0 = minOf(box.width.toFloat() / b.width, box.height.toFloat() / b.height)
        val c = Offset(box.width / 2f, box.height / 2f)
        val pf = (p - c - vo) / vs + c
        return Offset((pf.x - (box.width - b.width * sc0) / 2) / sc0, (pf.y - (box.height - b.height * sc0) / 2) / sc0)
    }
    fun bake() {
        val b = base ?: return
        if (ovs.isEmpty()) return
        val o = Bitmap.createBitmap(b.width, b.height, Bitmap.Config.ARGB_8888)
        paintAll(AndroidCanvas(o), b, null, ovs.toList())
        base = o; ovs.clear()
    }
    fun geo(f: (Bitmap) -> Bitmap) { bake(); base = base?.let(f); commit() }
    fun saveSvg(): Uri? {
        val b = base ?: return null
        val raster = Bitmap.createBitmap(b.width, b.height, Bitmap.Config.ARGB_8888)
        paintAll(AndroidCanvas(raster), b, buildMatrix(bright, contrast, sat, filter, warmth), ovs.filterNot { it is PathLayer && it.mask == null && it.booleanPath == null }, fx())
        val vectors = ovs.filterIsInstance<PathLayer>().filter { it.visible && it.mask == null && it.booleanPath == null }.map { path ->
            val nodes = path.pts.mapIndexed { index, point ->
                val incoming = path.incoming.getOrElse(index) { Offset.Zero }
                val outgoing = path.outgoing.getOrElse(index) { Offset.Zero }
                ProfessionalEditing.VectorNode(
                    point.x, point.y, incoming.x, incoming.y, outgoing.x, outgoing.y,
                    if (index in path.smoothNodes) ProfessionalEditing.NodeType.SMOOTH else ProfessionalEditing.NodeType.CORNER
                )
            }
            ProfessionalEditing.VectorShape(
                name = "Vector path", nodes = nodes, closed = path.closed,
                fillColor = if (path.filled) path.color else android.graphics.Color.TRANSPARENT,
                strokeColor = path.color, strokeWidth = path.w
            )
        }
        val svg = ProfessionalEditing.exportSvg(raster, vectors, b.width, b.height)
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, "moknight_${System.currentTimeMillis()}.svg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/svg+xml")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/MoKnight")
        }
        val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
        if (uri != null) ctx.contentResolver.openOutputStream(uri)?.use { it.write(svg.toByteArray(Charsets.UTF_8)) }
        Toast.makeText(ctx, if (uri != null) "تم تصدير SVG إلى التنزيلات" else "تعذر تصدير SVG", Toast.LENGTH_SHORT).show()
        raster.recycle()
        return uri
    }
    fun saveAppIcon(): Uri? {
        val b = base ?: return null
        val composed = Bitmap.createBitmap(b.width, b.height, Bitmap.Config.ARGB_8888)
        paintAll(AndroidCanvas(composed), b, buildMatrix(bright, contrast, sat, filter, warmth), ovs.toList(), fx())
        val icon = ProfessionalEditing.makeAppIconArtwork(composed, 1024, android.graphics.Color.BLACK, .12f)
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "moknight_app_icon_${System.currentTimeMillis()}.png")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/png")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/MoKnightIcons")
        }
        val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        if (uri != null) ctx.contentResolver.openOutputStream(uri)?.use { icon.compress(Bitmap.CompressFormat.PNG, 100, it) }
        Toast.makeText(ctx, if (uri != null) "تم حفظ أيقونة 1024×1024" else "تعذر حفظ الأيقونة", Toast.LENGTH_SHORT).show()
        composed.recycle(); icon.recycle()
        return uri
    }
    fun save(): Uri? {
        val b = base ?: return null
        val o = Bitmap.createBitmap(b.width, b.height, Bitmap.Config.ARGB_8888)
        paintAll(AndroidCanvas(o), b, buildMatrix(bright, contrast, sat, filter, warmth), ovs.toList(), fx())
        val v = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "edit_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/PhotoEditor")
        }
        val u = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)
        if (u != null) {
            ctx.contentResolver.openOutputStream(u)?.use { o.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            lastProjectUri = u.toString()
            lastProjectName = "مشروع ${System.currentTimeMillis()}"
            prefs.edit().putString("last_project_uri", lastProjectUri).putString("last_project_name", lastProjectName).apply()
            Toast.makeText(ctx, "تم الحفظ في الصور", Toast.LENGTH_SHORT).show()
        }
        return u
    }

    if (appPage == AppPage.HOME) {
        HomeScreen(
            lastProjectName = lastProjectName,
            onAddImage = { pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
            onOpenProject = {
                val uri = lastProjectUri?.let(Uri::parse)
                if (uri != null) {
                    runCatching {
                        appPage = AppPage.EDITOR
                        editorMode = "تحرير"
                        base = ImageDecoder.decodeBitmap(ImageDecoder.createSource(ctx.contentResolver, uri)) { d, info, _ ->
                            d.isMutableRequired = true
                            val sample = maxOf(info.size.width, info.size.height) / 2048
                            if (sample > 1) d.setTargetSampleSize(sample)
                        }
                        ovs.clear(); sel = -1; subjectMask = null; hist.clear(); hi = -1
                        commit()
                    }.onFailure { Toast.makeText(ctx, "تعذر فتح آخر مشروع", Toast.LENGTH_SHORT).show() }
                } else Toast.makeText(ctx, "لا يوجد مشروع محفوظ بعد", Toast.LENGTH_SHORT).show()
            },
            onSettings = { showSettings = true }
        )
        if (showSettings) {
            SettingsDialog(prefs = prefs, themePreset = themePreset, onTheme = { id -> themePreset=id; MoKnightColors.applyPreset(id); prefs.edit().putInt("theme_preset",id).apply() }, onModels = { showModelManager = true }, onClose = { showSettings=false })
        }
        if (showModelManager) ModelDownloadDialog(ctx) { showModelManager = false }
        return
    }

    Column(
        Modifier.fillMaxSize().background(MoKnightColors.BackgroundBrush)
            .then(if (isLandscape) Modifier else Modifier.statusBarsPadding().navigationBarsPadding())
    ) {
        val toolPanel: @Composable (Modifier) -> Unit = { panelModifier ->
        val panelAlpha = remember { Animatable(0f) }
        LaunchedEffect(tool) { panelAlpha.snapTo(0f); panelAlpha.animateTo(1f, tween(240)) }
        Column(
            panelModifier
                .animateContentSize()
                .graphicsLayer { this.alpha = panelAlpha.value }
                .then(if (isLandscape) Modifier else Modifier.heightIn(max = 230.dp))
                .verticalScroll(rememberScrollState())
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            when (tool) {
                Tool.ADJUST -> {
                    Sl("السطوع", bright, -100f..100f, { commit() }) { bright = it }
                    Sl("التباين", contrast, 0f..2f, { commit() }) { contrast = it }
                    Sl("التشبع", sat, 0f..2f, { commit() }) { sat = it }
                    Sl("الدفء", warmth, -40f..40f, { commit() }) { warmth = it }
                    Sl("الإضاءة Exposure", exposure, -2f..2f) { exposure=it }
                    Sl("الإضاءات Highlights", highlights, -1f..1f) { highlights=it }
                    Sl("الظلال Shadows", shadows, -1f..1f) { shadows=it }
                    Sl("الصبغة Tint", tint, -1f..1f) { tint=it }
                    Button({ val e=exposure; val h=highlights; val sh=shadows; val te=tint; geo { AdvancedImageOps.adjustExposure(it,e,h,sh,warmth/40f,te) }; exposure=0f; highlights=0f; shadows=0f; tint=0f }) { Text("تطبيق الإضاءة المتقدمة") }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedButton({ bright = 0f; contrast = 1f; sat = 1f; warmth = 0f; exposure=0f; highlights=0f; shadows=0f; tint=0f; commit() }) { Text("إعادة ضبط") }
                        Text("السطوع: ${bright.toInt()}  •  التباين: ${"%.2f".format(contrast)}", style=MaterialTheme.typography.bodySmall, color=MoKnightColors.Muted)
                    }
                }
                Tool.SMART_FILTERS -> Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    val selectedLayer = ovs.getOrNull(sel)
                    val currentFilters = when(selectedLayer) {
                        is BitmapLayer -> selectedLayer.smartFilters
                        is AdjustmentLayer -> selectedLayer.smartFilters
                        else -> emptyList()
                    }
                    fun writeFilters(next: List<SmartFilter>) {
                        when(val target=ovs.getOrNull(sel)) {
                            is BitmapLayer -> ovs[sel]=target.copy(smartFilters=next)
                            is AdjustmentLayer -> ovs[sel]=target.copy(smartFilters=next)
                        }
                    }
                    val supported = selectedLayer is BitmapLayer || selectedLayer is AdjustmentLayer
                    if (!supported) {
                        Text("اختر طبقة صورة أو Adjustment Layer من لوحة الطبقات أولاً.", color = MoKnightColors.Muted)
                    } else {
                        Text("Smart Filters — فلاتر غير تدميرية محفوظة على الطبقة المحددة")
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            SmartFilterType.values().forEach { type ->
                                OutlinedButton(onClick = {
                                    writeFilters(currentFilters + SmartFilter(System.nanoTime(), type, if(type==SmartFilterType.GRAYSCALE) 1f else .5f)); commit()
                                }, enabled = selectedLayer?.locked != true) { Text(type.title) }
                            }
                        }
                        if (currentFilters.isEmpty()) Text("لا توجد فلاتر على هذه الطبقة بعد.", color = MoKnightColors.Muted)
                        currentFilters.forEachIndexed { index, item ->
                            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                                Column(Modifier.fillMaxWidth().padding(9.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                        Text(item.type.title, modifier = Modifier.weight(1f))
                                        FilterChip(item.enabled, { writeFilters(currentFilters.toMutableList().also { it[index]=item.copy(enabled=!item.enabled) }) ; commit() }, { Text(if(item.enabled) "مفعّل" else "متوقف") })
                                        OutlinedButton(onClick={if(index>0){val list=currentFilters.toMutableList();val v=list.removeAt(index);list.add(index-1,v);writeFilters(list);commit()}},enabled=index>0){Text("↑")}
                                        OutlinedButton(onClick={if(index<currentFilters.lastIndex){val list=currentFilters.toMutableList();val v=list.removeAt(index);list.add(index+1,v);writeFilters(list);commit()}},enabled=index<currentFilters.lastIndex){Text("↓")}
                                        OutlinedButton(onClick={writeFilters(currentFilters.filterIndexed{ i,_->i!=index });commit()}){Text("حذف")}
                                    }
                                    Sl("القوة ${(item.amount*100).toInt()}%", item.amount, 0f..1f, done={commit()}, enabled=selectedLayer?.locked != true) { value ->
                                        val list=currentFilters.toMutableList();list[index]=item.copy(amount=value);writeFilters(list)
                                    }
                                }
                            }
                        }
                        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(onClick={writeFilters(emptyList());commit()},enabled=currentFilters.isNotEmpty() && selectedLayer?.locked != true){Text("إزالة كل الفلاتر")}
                            Text("${currentFilters.size} فلتر", color = MoKnightColors.Muted)
                        }
                        Text("يمكن تعديل القوة أو تعطيل أو إعادة ترتيب أو حذف كل فلتر منفرداً. المصدر الأصلي للطبقة لا يتغير. يدعم Adjustment Layer التأثير على التركيب الموجود أسفلها.", style = MaterialTheme.typography.bodySmall, color = MoKnightColors.Muted)
                    }
                }
                Tool.FILTER -> Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("الأصل", "أبيض وأسود", "سيبيا", "عكس", "قديم", "بارد", "دافئ").forEachIndexed { i, n -> FilterChip(filter == i, { filter = i; commit() }, { Text(n) }) }
                    }
                    Text("فلاتر ومؤثرات جاهزة")
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        LookPack.categories.forEach { cat -> FilterChip(lookCategory == cat, { lookCategory = cat }, { Text(cat) }) }
                    }
                    Sl("القيمة ${(lookStrength * 100).toInt()}", lookStrength, 0f..1f) { lookStrength = it }
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        LookPack.looks.filter { it.category == lookCategory }.forEach { look ->
                            OutlinedButton(onClick = {
                                val st = lookStrength
                                runCatching { geo { LookPack.apply(it, look, st) } }
                                    .onSuccess { lookStatus = "تم تطبيق ${look.name}" }
                                    .onFailure { lookStatus = "تعذر التطبيق: ${it.message}" }
                            }, enabled = base != null) { Text(look.name) }
                        }
                    }
                    if (lookStatus.isNotEmpty()) Text(lookStatus, color = MaterialTheme.colorScheme.secondary)
                    Text("فلاتر GPU (GPUImage-Plus) — تُطبَّق على الصورة مباشرة ويمكن التراجع عنها")
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(
                            "GPU وضوح" to (GpuImageEffects.contrast(1.15f) + " " + GpuImageEffects.saturation(1.2f)),
                            "GPU فينيت" to GpuImageEffects.vignette(0.35f, 0.85f),
                            "GPU دافئ" to (GpuImageEffects.hsl(0.02f, 0.1f, 0.03f) + " " + GpuImageEffects.brightness(0.04f))
                        ).forEach { (name, rule) ->
                            OutlinedButton(onClick = {
                                runCatching { geo { GpuImageEffects.apply(it, rule) } }
                                    .onSuccess { gpuStatus = "تم تطبيق $name" }
                                    .onFailure { gpuStatus = "تعذر تطبيق فلتر GPU: ${it.message}" }
                            }, enabled = base != null) { Text(name) }
                        }
                    }
                    if (gpuStatus.isNotEmpty()) Text(gpuStatus, color = MaterialTheme.colorScheme.secondary)
                }
                Tool.CROP -> Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("استقامة الصورة وتصحيح المنظور — اسحب كل ركن لمكانه")
                    Sl("استقامة / Straighten",straightenAngle,-45f..45f){straightenAngle=it}
                    Text("شبكة محاذاة 3×3 وأربع نقاط تحكم مباشرة على الصورة")
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                        Button({
                            val a=straightenAngle; val points=perspectiveCorners.toList()
                            geo { AdvancedImageOps.straighten(OpenCvImageToolkit.correctPerspectiveOrNull(it, points) ?: AdvancedImageOps.correctPerspectiveFourPoint(it, points), a) }
                            straightenAngle=0f
                        }) { Text("تطبيق التصحيح") }
                        TextButton({
                            base?.let { b -> perspectiveCorners.clear(); perspectiveCorners.addAll(listOf(
                                Offset(0f,0f),Offset(b.width.toFloat(),0f),
                                Offset(b.width.toFloat(),b.height.toFloat()),Offset(0f,b.height.toFloat())
                            )) }
                            straightenAngle=0f
                        }) { Text("إعادة ضبط") }
                    }
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton({ geo { Bitmap.createBitmap(it, 0, 0, it.width, it.height, Matrix().apply { postRotate(90f) }, true) } }) { Text("تدوير") }
                        OutlinedButton({ geo { Bitmap.createBitmap(it, 0, 0, it.width, it.height, Matrix().apply { postScale(-1f, 1f) }, true) } }) { Text("قلب") }
                        listOf("1:1" to (1 to 1), "4:3" to (4 to 3), "3:4" to (3 to 4), "16:9" to (16 to 9)).forEach { (n, r) ->
                            OutlinedButton({ geo { cropRatio(it, r.first, r.second) } }) { Text("قص $n") }
                        }
                    }
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(75, 50, 25).forEach { p ->
                            OutlinedButton({ geo { Bitmap.createScaledBitmap(it, it.width * p / 100, it.height * p / 100, true) } }) { Text("حجم $p%") }
                        }
                    }
                }
                Tool.EFFECTS -> Column(Modifier.heightIn(max = 200.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Sl("فينيت", vig, 0f..1f, { commit() }) { vig = it }
                    Sl("حبيبات", grain, 0f..1f, { commit() }) { grain = it }
                    Sl("تمويه", blur, 0f..1f, { commit() }) { blur = it }
                    Sl("الظلال", shad, 0f..1f, { commit() }) { shad = it }
                    Sl("الإضاءات", hil, 0f..1f, { commit() }) { hil = it }
                    Sl("قوة الحدة", sharpAmt, 0f..2f) { sharpAmt = it }
                    Sl("Clarity وضوح التفاصيل", clarityAmt, -1f..1f) { clarityAmt = it }
                    Sl("Texture التفاصيل الدقيقة",textureAmt,-1f..1f){textureAmt=it}
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Button({ val a = sharpAmt; val cl = clarityAmt; val tx=textureAmt; geo { AdvancedImageOps.texture(EditorFeatures.clarity(sharpen(it,a),cl),tx) }; sharpAmt=.5f; clarityAmt=0f; textureAmt=0f }) { Text("تطبيق الحدة والوضوح والتفاصيل") }
                        TextButton({ vig = 0f; grain = 0f; blur = 0f; shad = 0f; hil = 0f; commit() }) { Text("إعادة ضبط") }
                    }
                }
                Tool.SUN -> Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Sl("موضع الشمس أفقيًا", sunX, 0f..1f) { sunX = it }
                    Sl("موضع الشمس رأسيًا", sunY, 0f..1f) { sunY = it }
                    Sl("حجم الضوء", sunSize, .05f..1f) { sunSize = it }
                    Sl("شدة الإضاءة", sunIntensity, 0f..1.5f) { sunIntensity = it }
                    Sl("الانتشار والنعومة", sunSoft, 0f..1f) { sunSoft = it }
                    Sl("درجة حرارة اللون (K) ${sunTemp.toInt()}", sunTemp, 2000f..10000f) { sunTemp = it }
                    Sl("الشفافية", sunOpacity, 0f..1f) { sunOpacity = it }
                    Sl("عدد الأشعة ${sunRays.toInt()}", sunRays, 0f..24f) { sunRays = it }
                    Sl("اتجاه الأشعة", sunRayAngle, 0f..360f) { sunRayAngle = it }
                    Sl("طول الأشعة", sunRayLen, .1f..1.5f) { sunRayLen = it }
                    Sl("دوائر Lens Flare ${sunGhosts.toInt()}", sunGhosts, 0f..8f) { sunGhosts = it }
                    Button({
                        val image = base
                        if (image != null) {
                            val bmp = SunFlareEngine.render(image.width, image.height, SunFlareEngine.Params(
                                sunX, sunY, sunSize, sunIntensity, sunSoft, sunTemp, sunOpacity,
                                sunRays.toInt(), sunRayAngle, sunRayLen, sunGhosts.toInt()))
                            ovs.add(BitmapLayer(bmp, "ضوء الشمس", blendMode = AdvancedImageOps.BlendMode.SCREEN))
                            sel = ovs.lastIndex
                            commit()
                        }
                    }) { Text("إضافة ضوء الشمس كطبقة مستقلة") }
                }
                Tool.CINEMA -> Column(Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("تلوين سينمائي يدوي — كل قيمة مستقلة، من غير Looks أو فلاتر جاهزة", style = MaterialTheme.typography.titleMedium)
                    Text("الإضاءة والنطاق الديناميكي", style = MaterialTheme.typography.titleSmall)
                    Sl("Exposure / التعريض",gradeExposure,-3f..3f){gradeExposure=it}
                    Sl("Contrast / التباين",cinemaContrast,-1f..1f){cinemaContrast=it}
                    Sl("Highlights / الإضاءات",gradeHighlights,-1f..1f){gradeHighlights=it}
                    Sl("Shadows / الظلال",gradeShadows,-1f..1f){gradeShadows=it}
                    Sl("Whites / الأبيض",gradeWhites,-1f..1f){gradeWhites=it}
                    Sl("Blacks / الأسود",gradeBlacks,-1f..1f){gradeBlacks=it}
                    Divider()
                    Text("White Balance / توازن اللون", style = MaterialTheme.typography.titleSmall)
                    Sl("Temperature / بارد ↔ دافئ",cinemaWarmth,-1f..1f){cinemaWarmth=it}
                    Sl("Tint / أخضر ↔ أرجواني",gradeTint,-1f..1f){gradeTint=it}
                    Sl("Vibrance / حيوية الألوان",gradeVibrance,-1f..1f){gradeVibrance=it}
                    Sl("Saturation / التشبع",gradeSaturation,-1f..1f){gradeSaturation=it}
                    Divider()
                    Text("Color Wheels — عجلة الألوان لكل نطاق", style = MaterialTheme.typography.titleSmall)
                    Text("Shadows / الظلال")
                    Sl("لون الظلال",shadowHue,0f..360f){shadowHue=it}
                    Sl("قوة لون الظلال",shadowAmount,-1f..1f){shadowAmount=it}
                    Text("Midtones / الدرجات المتوسطة")
                    Sl("لون الدرجات المتوسطة",midHue,0f..360f){midHue=it}
                    Sl("قوة لون الدرجات المتوسطة",midAmount,-1f..1f){midAmount=it}
                    Text("Highlights / الإضاءات")
                    Sl("لون الإضاءات",highlightHue,0f..360f){highlightHue=it}
                    Sl("قوة لون الإضاءات",highlightAmount,-1f..1f){highlightAmount=it}
                    Sl("Balance / موازنة الظلال والإضاءات",gradeBalance,-1f..1f){gradeBalance=it}
                    Button(onClick={
                        val grade=AdvancedImageOps.CinematicGrade(
                            exposure=gradeExposure, contrast=cinemaContrast, highlights=gradeHighlights, shadows=gradeShadows,
                            whites=gradeWhites, blacks=gradeBlacks, temperature=cinemaWarmth, tint=gradeTint,
                            vibrance=gradeVibrance, saturation=gradeSaturation, shadowHue=shadowHue, shadowAmount=shadowAmount,
                            midHue=midHue, midAmount=midAmount, highlightHue=highlightHue, highlightAmount=highlightAmount, balance=gradeBalance
                        )
                        geo { AdvancedImageOps.applyCinematicGrade(it,grade) }
                    }, modifier=Modifier.fillMaxWidth()) { Text("تطبيق التلوين اليدوي على الصورة") }
                    TextButton(onClick={
                        gradeExposure=0f;cinemaContrast=0f;gradeHighlights=0f;gradeShadows=0f;gradeWhites=0f;gradeBlacks=0f
                        cinemaWarmth=0f;gradeTint=0f;gradeVibrance=0f;gradeSaturation=0f;shadowAmount=0f;midAmount=0f;highlightAmount=0f;gradeBalance=0f
                    }) { Text("إعادة ضبط كل إعدادات التلوين") }
                    Divider()
                    Text("مؤثرات إبداعية مستقلة — اختار تأثيرًا واضبط شدته", style = MaterialTheme.typography.titleSmall)
                    val fxNames=listOf("Matte Fade — بهتان سينمائي","Posterize — تقليل مستويات اللون","Solarize — سولارايز","Duotone — لونان","Soft Highlight Lift — رفع الإضاءات","Edge Burn — تعتيم الأطراف","Emboss — نقش بارز","Threshold — أبيض وأسود حاد")
                    Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                        fxNames.forEachIndexed { idx,name -> FilterChip(creativeFxId==idx,{creativeFxId=idx},{Text(name)}) }
                    }
                    Sl("قوة التأثير",creativeFxAmount,0f..1f){creativeFxAmount=it}
                    Button(onClick={val id=creativeFxId;val amount=creativeFxAmount;geo{AdvancedImageOps.creativeEffect(it,id,amount)}},modifier=Modifier.fillMaxWidth()) { Text("تطبيق التأثير المحدد") }
                    Text("كل عملية تُطبّق على نسخة الصورة الحالية ويمكن التراجع عنها. لا توجد درجات لونية مفروضة أو أنماط جاهزة.",style=MaterialTheme.typography.bodySmall)
                }
                Tool.HSL -> Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp), verticalAlignment=Alignment.CenterVertically) {
                        OutlinedButton(onClick={pickCubeLut.launch(arrayOf("*/*"))}) { Text("استيراد LUT .cube") }
                        Text(if(importedLut!=null) "${importedLutName} • ${importedLut?.size}³" else "لم يتم تحميل LUT",style=MaterialTheme.typography.bodySmall,color=MoKnightColors.Muted)
                    }
                    Button(enabled=importedLut!=null && base!=null && !lutBusy,onClick={
                        val lut=importedLut ?: return@Button
                        val original=base ?: return@Button
                        val layerSnapshot=ovs.toList()
                        lutBusy=true
                        editorScope.launch {
                            runCatching { withContext(Dispatchers.Default) {
                                val source=if(layerSnapshot.isEmpty()) original else Bitmap.createBitmap(original.width,original.height,Bitmap.Config.ARGB_8888).also { composed ->
                                    paintAll(AndroidCanvas(composed),original,null,layerSnapshot)
                                }
                                lut.apply(source)
                            } }
                                .onSuccess { result -> base=result; ovs.clear(); sel=-1; commit(); Toast.makeText(ctx,"تم تطبيق LUT",Toast.LENGTH_SHORT).show() }
                                .onFailure { Toast.makeText(ctx,"فشل تطبيق LUT: ${it.message}",Toast.LENGTH_LONG).show() }
                            lutBusy=false
                        }
                    }) { Text(if(lutBusy) "جارٍ تطبيق LUT…" else "تطبيق LUT على الصورة") }
                    Text("يدعم ملفات 3D .cube حتى حجم 64³، وتتم المعالجة في الخلفية مع الحفاظ على الشفافية.",style=MaterialTheme.typography.bodySmall,color=MoKnightColors.Muted)
                    Text("عجلة اختيار نطاق اللون — اسحب المؤشر لاختيار Hue")
                    HueWheelPicker(hslTarget) { hslTarget = it }
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("أحمر" to 0f,"أصفر" to 60f,"أخضر" to 120f,"سماوي" to 180f,"أزرق" to 240f,"أرجواني" to 300f).forEach { (n,h) -> FilterChip(hslTarget==h,{hslTarget=h},{Text(n)}) } }
                    Sl("تحريك اللون", hslHue, -180f..180f) { hslHue = it }
                    Sl("التشبع", hslSat, -1f..1f) { hslSat = it }
                    Sl("الإضاءة", hslLight, -1f..1f) { hslLight = it }
                    Button({ geo { AdvancedImageOps.adjustHsl(it, hslTarget, hslHue, hslSat, hslLight) }; hslHue=0f; hslSat=0f; hslLight=0f }) { Text("تطبيق HSL") }
                }
                Tool.CURVES -> Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("منحنيات RGB — أضف نقاط تحكم متعددة لكل قناة")
                    Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                        listOf("RGB" to 0,"أحمر" to 1,"أخضر" to 2,"أزرق" to 3).forEach { (name,id) -> FilterChip(rgbChannel==id,{rgbChannel=id;curvePoints.clear()},{Text(name)}) }
                    }
                    Sl("موضع الإدخال",curveInput,0f..1f){curveInput=it}
                    Sl("قيمة الإخراج",curveOutput,0f..1f){curveOutput=it}
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                        Button({ curvePoints.removeAll { kotlin.math.abs(it.x-curveInput)<.015f }; curvePoints.add(AdvancedImageOps.CurvePoint(curveInput,curveOutput)); curvePoints.sortBy{it.x} }) { Text("إضافة / تحديث نقطة") }
                        OutlinedButton({curvePoints.clear();curveInput=.5f;curveOutput=.5f}){Text("مسح نقاط القناة")}
                    }
                    Text("النقاط الحالية: ${curvePoints.size} — ${curvePoints.sortedBy{it.x}.joinToString { "${(it.x*100).toInt()}→${(it.y*100).toInt()}" }}")
                    Button({ val pts=curvePoints.toList(); val ch=rgbChannel; geo { image ->
                        when(ch){1->EditorFeatures.applyRgbCurves(image,EditorFeatures.RgbCurve(pts,emptyList(),emptyList()));2->EditorFeatures.applyRgbCurves(image,EditorFeatures.RgbCurve(emptyList(),pts,emptyList()));3->EditorFeatures.applyRgbCurves(image,EditorFeatures.RgbCurve(emptyList(),emptyList(),pts));else->AdvancedImageOps.applyCurve(image,pts)}
                    };curvePoints.clear() }) { Text("تطبيق منحنى القناة") }
                    Text("يمكنك إضافة عدة نقاط ثم تطبيق منحنى RGB أو قناة الأحمر أو الأخضر أو الأزرق بشكل مستقل.",style=MaterialTheme.typography.bodySmall)
                }
                Tool.GRADIENT -> Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("تدرج متعدد التحكم في اللون والشفافية والاتجاه")
                    Text("لون البداية")
                    Swatches(gradientStart.toLong() and 0xffffffffL) { gradientStart=it.toInt() }
                    Text("لون النهاية")
                    Swatches(gradientEnd.toLong() and 0xffffffffL) { gradientEnd=it.toInt() }
                    Sl("شفافية التدرج",gradientOpacity,0f..1f){gradientOpacity=it}
                    Sl("شفافية اللونين",gradientAlpha,0f..1f){gradientAlpha=it}
                    Sl("زاوية التدرج",gradientAngle,0f..360f){gradientAngle=it}
                    Button({ val a=(gradientStart and 0x00FFFFFF) or ((gradientAlpha*255).toInt().shl(24)); val b=(gradientEnd and 0x00FFFFFF) or ((gradientAlpha*255).toInt().shl(24)); geo { AdvancedImageOps.gradientOverlay(it,a,b,gradientAngle,gradientOpacity) } }) { Text("تطبيق التدرج") }
                }
                Tool.DOUBLE -> Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(if (overlayBitmap==null) "اختر صورة ثانية لدمجها" else "تم اختيار صورة الدمج")
                    OutlinedButton({ pickOverlay.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) { Text("اختيار الصورة الثانية") }
                    Sl("شفافية الدمج", blendOpacity, 0f..1f) { blendOpacity=it }
                    Text("نمط الدمج")
                    Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(5.dp)) {
                        AdvancedImageOps.BlendMode.values().forEach { mode -> FilterChip(blendMode==mode,{blendMode=mode},{Text(when(mode){AdvancedImageOps.BlendMode.NORMAL->"عادي";AdvancedImageOps.BlendMode.MULTIPLY->"ضرب";AdvancedImageOps.BlendMode.SCREEN->"تفتيح";AdvancedImageOps.BlendMode.OVERLAY->"تراكب";AdvancedImageOps.BlendMode.LIGHTEN->"الأفتح";AdvancedImageOps.BlendMode.DARKEN->"الأغمق";AdvancedImageOps.BlendMode.ADD->"إضافة";AdvancedImageOps.BlendMode.DIFFERENCE->"فرق";AdvancedImageOps.BlendMode.SRC_ATOP->"داخل المصدر";AdvancedImageOps.BlendMode.XOR->"XOR"})}) }
                    }
                    OutlinedButton(onClick={ val second=overlayBitmap; val original=base; if(second!=null && original!=null){val mask=subjectMask?.let{Bitmap.createScaledBitmap(it,second.width,second.height,true)}; val layer=BitmapLayer(second,"تعريض مزدوج بقناع",true,blendOpacity,blendOffsetX*original.width,blendOffsetY*original.height,blendScale,blendRotation,blendMode,mask,false,blendChannels);ovs.add(layer);sel=ovs.lastIndex;commit()} },enabled=overlayBitmap!=null && subjectMask!=null){Text("إضافة الدمج بقناع التحديد الحالي")}
                    Text("قنوات الدمج المتقدمة")
                    Text("تقدر تربط قناع التحديد بالصورة الثانية، ثم تعدل القناع من أداة الأقنعة والطبقات.",style=MaterialTheme.typography.bodySmall)
                    Text("قنوات RGB في الدمج")
                    Row(horizontalArrangement=Arrangement.spacedBy(5.dp)) { listOf("الأحمر R" to 1,"الأخضر G" to 2,"الأزرق B" to 4).forEach{(label,bit)->FilterChip(blendChannels and bit != 0,{blendChannels=if(blendChannels and bit != 0) blendChannels and bit.inv() else blendChannels or bit},{Text(label)})} }
                    FilterChip(blendIfEnabled,{blendIfEnabled=!blendIfEnabled},{Text("Blend If حسب إضاءة الصورة الأساسية")})
                    if(blendIfEnabled){Sl("عتبة الظلال",blendIfShadow,0f..0.5f){blendIfShadow=it};Sl("عتبة الإضاءات",blendIfHighlight,.5f..1f){blendIfHighlight=it};Sl("نعومة الانتقال",blendIfSoftness,.01f..0.5f){blendIfSoftness=it}}
                    FilterChip(blendUseSelectionMask,{blendUseSelectionMask=!blendUseSelectionMask},{Text("استخدام قناع التحديد الحالي")},enabled=subjectMask!=null)
                    Text("تحويل الصورة الثانية")
                    Sl("الحجم",blendScale,.2f..2.5f){blendScale=it}
                    Sl("الدوران",blendRotation,-180f..180f){blendRotation=it}
                    Sl("الإزاحة الأفقية",blendOffsetX,-.5f.. .5f){blendOffsetX=it}
                    Sl("الإزاحة الرأسية",blendOffsetY,-.5f.. .5f){blendOffsetY=it}
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                        OutlinedButton({blendScale=1f;blendRotation=0f;blendOffsetX=0f;blendOffsetY=0f;blendOpacity=.5f;blendMode=AdvancedImageOps.BlendMode.SCREEN}){Text("إعادة ضبط")}
                        OutlinedButton(onClick={
                            val second=overlayBitmap; val original=base
                            if(second!=null && original!=null){
                                val layer=BitmapLayer(second,"تعريض مزدوج",true,blendOpacity,blendOffsetX*original.width,blendOffsetY*original.height,blendScale,blendRotation,blendMode,null,false,blendChannels)
                                ovs.add(layer);sel=ovs.lastIndex;commit()
                            }
                        },enabled=overlayBitmap!=null && base!=null){Text("إضافة كطبقة مستقلة")}
                        Button({ val second=overlayBitmap; if(second!=null) geo { original ->
                            val transformed=Bitmap.createBitmap(original.width,original.height,Bitmap.Config.ARGB_8888)
                            val canvas=AndroidCanvas(transformed); val matrix=Matrix().apply { val cx=original.width/2f;val cy=original.height/2f;postTranslate(-second.width/2f,-second.height/2f);postScale(blendScale,blendScale);postRotate(blendRotation);postTranslate(cx+blendOffsetX*original.width,cy+blendOffsetY*original.height) }
                            canvas.drawBitmap(second,matrix,Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
                            val withBlendIf=if(blendIfEnabled) AdvancedImageOps.blendIfByLuminance(original,transformed,blendIfShadow,blendIfHighlight,blendIfSoftness) else transformed
                            val masked=if(blendUseSelectionMask) subjectMask?.let{ProfessionalEditing.applyMask(withBlendIf,it)} ?: withBlendIf else withBlendIf
                            val channelSelected=AdvancedImageOps.selectSourceChannels(masked,blendChannels)
                            val result=AdvancedImageOps.composite(original,channelSelected,blendOpacity,blendMode)
                            channelSelected.recycle();if(masked!==withBlendIf)masked.recycle();if(withBlendIf!==transformed)withBlendIf.recycle();transformed.recycle();result
                        } }, enabled=overlayBitmap!=null) { Text("تطبيق التعريض المزدوج") }
                    }
                }
                Tool.HEAL -> Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        FilterChip(!smartRepair,{smartRepair=false;healSource=null},{Text("نسخ Clone Stamp")})
                        FilterChip(smartRepair,{smartRepair=true;healSource=null},{Text("إصلاح ذكي محلي")})
                    }
                    Text(if(smartRepair) "اسحب فوق العيب لإصلاحه محلياً" else if (healSource == null) "اسحب من منطقة سليمة لتحديد مصدر النسخ، ثم اسحب فوق العيب" else "اضغط على الجزء المراد إصلاحه")
                    Sl("حجم الفرشاة", healRadius, 8f..180f) { healRadius = it }
                    TextButton({ healSource = null }) { Text("إلغاء نقطة المصدر") }
                    Text(if(smartRepair) "يستخدم ملء أقرب بكسل مع تنعيم الحافة؛ مناسب للعلامات الصغيرة وليس إزالة AI توليدية." else "Clone Stamp ينسخ نسيج منطقة إلى أخرى يدوياً.", style = MaterialTheme.typography.bodySmall)
                }
                Tool.SHAPES -> Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("rectangle" to "مستطيل", "rounded_rectangle" to "مستطيل دائري", "circle" to "دائرة", "line" to "خط", "arrow" to "سهم", "double_arrow" to "سهمين", "triangle" to "مثلث", "diamond" to "معين", "pentagon" to "خماسي", "hexagon" to "سداسي", "octagon" to "ثماني", "star" to "نجمة", "heart" to "قلب", "cross" to "علامة +", "speech" to "فقاعة").forEach { (key, label) ->
                            FilterChip(shapeKind == key, { shapeKind = key }, { Text(label) })
                        }
                    }
                    Swatches(color) { color = it }
                    Text("موضع وحجم الشكل Vector قابل للتحرير")
                    Sl("الموضع الأفقي",shapeLeft,0f..0.8f){shapeLeft=it;shapeWidth=shapeWidth.coerceAtMost(1f-shapeLeft)}
                    Sl("الموضع الرأسي",shapeTop,0f..0.8f){shapeTop=it;shapeHeight=shapeHeight.coerceAtMost(1f-shapeTop)}
                    Sl("العرض",shapeWidth,.05f..(1f-shapeLeft)){shapeWidth=it}
                    Sl("الارتفاع",shapeHeight,.05f..(1f-shapeTop)){shapeHeight=it}
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = shapeFilled, onCheckedChange = { shapeFilled = it })
                        Text("شكل ممتلئ")
                    }
                    Button(onClick = {
                        val fill = shapeFilled
                        val kind = shapeKind
                        val tint = color.toInt()
                        val b = base
                        if (b != null) {
                            val vector=createPresetVectorPath(kind,b.width*shapeLeft,b.height*shapeTop,b.width*(shapeLeft+shapeWidth),b.height*(shapeTop+shapeHeight))
                            ovs.add(PathLayer(emptyList(),tint,maxOf(4f,maxDim()*0.008f),true,false,fill,booleanPath=vector));sel=ovs.lastIndex;commit()
                        }
                    }, enabled = base != null) { Text("إضافة شكل Vector قابل للتحرير") }
                }
                Tool.AI -> Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    AiStudioPhase3Panel(
                        context = ctx,
                        prompt = aiPrompt,
                        onPromptChange = { aiPrompt = it },
                        busy = aiBusy,
                        status = aiStatus,
                        hasMask = subjectMask != null,
                        removalReady = removalModelReady,
                        generativeReady = generativeModelReady,
                        onDownloadRemoval = {
                            if (!aiBusy) {
                                aiBusy = true; aiStatus = "جاري تجهيز نموذج إزالة العناصر…"
                                AiModelManager.download(ctx, AiModelManager.objectRemoval,
                                    onProgress = { aiStatus = it },
                                    onResult = { result -> aiBusy = false; result.onSuccess { removalModelReady = true; aiStatus = "تم تنزيل LaMa-Dilated INT8 والتحقق من الملف." }.onFailure { aiStatus = "تعذر تنزيل نموذج الإزالة: ${it.localizedMessage ?: "خطأ"}" } }
                                )
                            }
                        },
                        onRunPrompt = {
                            aiStatus = "استخدم Generate داخل Generative Fill بعد تجهيز النموذج. الأوامر القديمة ما زالت تعمل من شريط الأدوات."
                        },
                        onDownloadGenerative = {
                            if (!aiBusy) {
                                aiBusy = true; aiStatus = "جاري تنزيل حزمة RealVis 6 Inpaint (حوالي 1.3 GB)…"
                                AiModelManager.download(ctx, AiModelManager.generativeFill,
                                    onProgress = { aiStatus = it },
                                    onResult = { result -> aiBusy = false; result.onSuccess { generativeModelReady = true; aiStatus = "تم تنزيل حزمة Generative Fill. جاهزة للتشغيل بعد ربط backend diffusion المتوافق." }.onFailure { aiStatus = "تعذر تنزيل حزمة Generative Fill: ${it.localizedMessage ?: "خطأ"}" } }
                                )
                            }
                        },
                        onRemoveObject = {
                            val image = base; val mask = subjectMask
                            if (image != null && mask != null && !aiBusy) {
                                aiBusy = true
                                ObjectRemovalEngine.remove(ctx, image, mask, { aiStatus = it }) { result ->
                                    aiBusy = false
                                    result.onSuccess { filled -> base = filled; commit(); aiStatus = "تمت إزالة العنصر بنموذج LaMa-Dilated INT8 محليًا." }
                                        .onFailure { aiStatus = "تعذر إزالة العنصر: ${it.localizedMessage ?: "خطأ غير معروف"}" }
                                }
                            }
                        },
                        onGenerateFill = {
                            aiStatus = "النموذج التوليدي تم تنزيله كحزمة منفصلة، لكن Generate لن يستخدم LaMa ولن يعرض نتيجة وهمية. يحتاج هذا الزر backend diffusion فعليًا على الجهاز قبل تفعيله."
                        },
)
                    Text("أدوات الذكاء الاصطناعي — التحديد والإزالة والتحسين محليًا على الجهاز")
                    Text(aiStatus, color = MaterialTheme.colorScheme.secondary)
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick={aiPickMode=!aiPickMode;aiStatus=if(aiPickMode) "اضغط على العنصر المطلوب داخل الصورة" else "تم إلغاء وضع تحديد العنصر"},enabled=!aiBusy && base!=null){Text(if(aiPickMode) "إلغاء تحديد العنصر" else "التحديد الذكي: اضغط على العنصر")}
                        OutlinedButton(onClick={val image=base;if(image!=null&&!aiBusy){aiBusy=true;aiStatus="جاري تحديد الشعر بدقة…";MediaPipeOfflineModels.segmentHair(ctx,image){result->aiBusy=false;result.onSuccess{subjectMask=it;aiStatus="تم تحديد الشعر. يمكنك قصه أو تطبيق تأثير عليه."}.onFailure{aiStatus="تعذر تحديد الشعر: ${it.localizedMessage ?: "خطأ"}"}}}},enabled=!aiBusy && base!=null){Text("تحديد الشعر")}
                    }
                    Button(onClick = {
                        val image = base
                        if (image == null) {
                            aiStatus = "افتح صورة أولاً"
                        } else if (!aiBusy) {
                            aiBusy = true
                            aiStatus = "جاري تحديد الشخص… قد يستغرق ذلك لحظات"
                            OfflineAiTools.segmentPerson(ctx, image) { result ->
                                aiBusy = false
                                result.onSuccess { mask ->
                                    subjectMask = mask
                                    aiStatus = "تم تحديد الشخص بنجاح. تقدر تزيل الخلفية أو تعزلها بالتمويه."
                                }.onFailure { error ->
                                    aiStatus = "تعذر تحديد الشخص: ${error.localizedMessage ?: "خطأ غير معروف"}"
                                }
                            }
                        }
                    }, enabled = !aiBusy && base != null) { Text(if (aiBusy) "جاري التحليل…" else "تحديد الشخص تلقائياً") }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            val image = base; val mask = subjectMask
                            if (image != null && mask != null) {
                                base = OfflineAiTools.cutoutPerson(image, mask, refineEdges = true)
                                commit()
                                aiStatus = "تم حذف الخلفية من الصورة الحالية. استخدم التراجع لاسترجاع الأصل."
                            }
                        }, enabled = subjectMask != null && !aiBusy) { Text("إزالة الخلفية من الصورة") }
                        OutlinedButton(onClick = {
                            val image = base; val mask = subjectMask
                            if (image != null && mask != null) {
                                base = OfflineAiTools.blurBackground(image, mask)
                                commit()
                                aiStatus = "تم تمويه الخلفية مع إبقاء الشخص واضحاً"
                            }
                        }, enabled = subjectMask != null && !aiBusy) { Text("تمويه الخلفية") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            val image = base; val mask = subjectMask
                            if (image != null && mask != null) {
                                val cutout = OfflineAiTools.cutoutPerson(image, mask, refineEdges = true)
                                ovs.add(BitmapLayer(cutout, "العنصر المعزول - أمام النصوص"))
                                sel = ovs.lastIndex
                                commit()
                                aiStatus = "اتضاف العنصر المحدد كطبقة شفافة فوق الصورة الأصلية. النصوص الموجودة أسفله ستظهر خلف العنصر."
                            }
                        }, enabled = subjectMask != null && !aiBusy) { Text("فصل التحديد كطبقة أمامية") }
                        OutlinedButton(onClick = {
                            val image = base; val mask = subjectMask
                            if (image != null && mask != null && !aiBusy) {
                                aiBusy = true
                                aiStatus = "سيتم تنزيل نموذج LaMa-Dilated INT8 أول مرة، ثم تعمل إزالة العنصر محلياً بدون إنترنت."
                                ObjectRemovalEngine.remove(ctx, image, mask,
                                    onProgress = { message -> aiStatus = message },
                                    onResult = { result ->
                                        aiBusy = false
                                        result.onSuccess { filled -> base = filled; commit(); aiStatus = "اكتملت إزالة العنصر محلياً باستخدام LaMa-Dilated INT8." }
                                            .onFailure { error -> aiStatus = "تعذر الملء التوليدي: ${error.localizedMessage ?: "خطأ غير معروف"}" }
                                    })
                            }
                        }, enabled = subjectMask != null && !aiBusy) { Text(if (aiBusy) "جاري إزالة العنصر…" else "إزالة العنصر بالذكاء الاصطناعي (LaMa-Dilated INT8)") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            subjectMask = subjectMask?.let { OfflineAiTools.refinePersonMask(it, 0.18f) }
                            aiStatus = "تم تنعيم حواف تحديد الشخص"
                        }, enabled = subjectMask != null && !aiBusy) { Text("تحسين الحواف") }
                        OutlinedButton(onClick = {
                            val image = base; val mask = subjectMask
                            if (image != null && mask != null) {
                                base = OfflineAiTools.replaceBackground(image, mask, android.graphics.Color.rgb(35, 48, 75))
                                commit()
                                aiStatus = "تم استبدال الخلفية بلون ثابت"
                            }
                        }, enabled = subjectMask != null && !aiBusy) { Text("خلفية بلون جديد") }
                        OutlinedButton(onClick = {
                            subjectMask = subjectMask?.let { OfflineAiTools.invertMask(it) }
                            aiStatus = "تم عكس منطقة التحديد"
                        }, enabled = subjectMask != null) { Text("عكس التحديد") }
                        TextButton(onClick = { subjectMask = null; aiStatus = "تم مسح التحديد" }, enabled = subjectMask != null) { Text("مسح التحديد") }
                    }
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick={val image=base;val mask=subjectMask;if(image!=null&&mask!=null){base=AdvancedImageOps.inpaintMask(image,mask);commit();aiStatus="تمت إزالة المنطقة المحددة بملء محلي تقليدي؛ ليست Generative Fill."}},enabled=subjectMask!=null&&!aiBusy){Text("إزالة العنصر المحدد")}
                        OutlinedButton(onClick={val image=base;val mask=subjectMask;if(image!=null&&mask!=null){
                            val result=if(OpenCvImageToolkit.initialize()) runCatching{OpenCvImageToolkit.removeMarkedObject(image,mask,5.0)}.getOrNull() else null
                            if(result!=null){base=result;commit();aiStatus="تمت الإزالة بخوارزمية OpenCV (Telea)؛ ليست Generative Fill."} else aiStatus="تعذر تشغيل OpenCV على هذه الصورة."
                        }},enabled=subjectMask!=null&&!aiBusy){Text("إزالة OpenCV")}
                        OutlinedButton(onClick={val image=base;val mask=subjectMask;if(image!=null&&mask!=null){base=AdvancedImageOps.applyAlphaMask(image,mask);commit();aiStatus="تم قص المنطقة المحددة بخلفية شفافة."}},enabled=subjectMask!=null&&!aiBusy){Text("قص التحديد")}
                    }
                    OutlinedButton(onClick = {
                        val image = base
                        if (image == null) aiStatus = "افتح صورة أولاً" else if (!aiBusy) {
                            aiBusy = true
                            aiStatus = "سيتم تنزيل نموذج Real-ESRGAN x4plus لأول مرة، ثم يعمل التحسين على الجهاز."
                            AiUpscaleEngine.upscale4x(ctx, image,
                                onProgress = { message -> aiStatus = message },
                                onResult = { result ->
                                    aiBusy = false
                                    result.onSuccess { enhanced ->
                                        base = enhanced
                                        commit()
                                        aiStatus = "اكتمل تحسين الصورة بنموذج Real-ESRGAN x4plus. الناتج حتى 4× وبحد أقصى 4096 بكسل للضلع الأطول."
                                    }.onFailure { error -> aiStatus = "تعذر تحسين الدقة: ${error.localizedMessage ?: "خطأ غير معروف"}" }
                                })
                        }
                    }, enabled = base != null && !aiBusy) { Text(if (aiBusy) "جاري تحسين الدقة…" else "تحسين الدقة بالذكاء الاصطناعي 4×") }
                    Text("AI Upscale يستخدم Real-ESRGAN x4plus. أول استخدام يحتاج تنزيل نموذج كبير؛ بعد ذلك تتم المعالجة محليًا. الصور الكبيرة تُعالج على دفعات، ويُحد الناتج إلى 4096 بكسل للضلع الأطول لتقليل استهلاك الذاكرة. قد تختلف السرعة والجودة حسب الهاتف.", style = MaterialTheme.typography.bodySmall)
                    Text("إزالة العناصر بالذكاء الاصطناعي: حدّد العنصر بالفرشاة أو التحديد الذكي، ثم استخدم LaMa Generative Fill لإعادة بناء المنطقة من سياق الصورة. النموذج لا يقبل وصفًا نصيًا لما يجب وضعه مكان العنصر.", style = MaterialTheme.typography.bodySmall)
                    Text("التحديد الذكي: اضغط على العنصر داخل الصورة لتشغيل MediaPipe MagicTouch، أو استخدم تحديد الشخص/الشعر. يمكنك بعدها تنقيح القناع يدويًا.", style = MaterialTheme.typography.bodySmall)
                    Text("تحسين حواف الشعر يدويًا")
                    Sl("حدة تفاصيل الحواف",hairEdgeContrast,0.5f..2.5f){hairEdgeContrast=it}
                    Sl("نعومة حواف الشعر",hairEdgeFeather,0f..0.45f){hairEdgeFeather=it}
                    OutlinedButton(onClick={subjectMask=subjectMask?.let{OfflineAiTools.refineHairMask(it,hairEdgeContrast,hairEdgeFeather)};aiStatus="تم تحسين انتقالات حواف التحديد يدويًا"},enabled=subjectMask!=null){Text("تطبيق تحسين الحواف")}
                    Text("التحسين اليدوي يضبط انتقالات قناع التحديد؛ لا ينشئ تفاصيل شعر غير موجودة ولا يغني عن نموذج متخصص.",style=MaterialTheme.typography.bodySmall)
                    Text("Generative Fill يستخدم نموذج LaMa ONNX بدقة إدخال 512×512. أول استخدام يحتاج إنترنت لتنزيل النموذج والتحقق من بصمته؛ بعد ذلك تتم المعالجة على الجهاز بدون رفع الصورة. الملء يعتمد على محتوى الصورة المحيط ولا يقبل وصفاً نصياً للمحتوى الجديد.", style = MaterialTheme.typography.bodySmall)
                    Text("لفصل شخص أو عنصر ووضع نص خلفه: حدّد الشخص أو العنصر، اضغط (فصل التحديد كطبقة أمامية)، ثم أضف النص واختر (ضع النص خلف الشخص/العنصر المعزول). تظل الصورة الأصلية في الخلفية والعنصر المحدد طبقة شفافة مستقلة.", style = MaterialTheme.typography.bodySmall)
                }
                Tool.MASKS -> Column(verticalArrangement=Arrangement.spacedBy(6.dp)) {
                    Text("تحديد يدوي بالفرشاة أو ابدأ بتحديد الشخص من أدوات AI")
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                        FilterChip(!maskErase,{maskErase=false},{Text("إضافة للتحديد")})
                        FilterChip(maskErase,{maskErase=true},{Text("مسح من التحديد")})
                    }
                    Sl("حجم الفرشاة",maskBrushRadius,8f..220f){maskBrushRadius=it}
                    Sl("صلابة الفرشاة",maskHardness,.05f..1f){maskHardness=it}
                    TextField(maskName,{maskName=it},label={Text("اسم التحديد")},singleLine=true)
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick={subjectMask?.let { ProfessionalEditing.saveNamedMask(ctx.filesDir,maskName,it); aiStatus="تم حفظ التحديد باسم $maskName" }},enabled=subjectMask!=null){Text("حفظ باسم")}
                        OutlinedButton(onClick={subjectMask=ProfessionalEditing.loadNamedMask(ctx.filesDir,maskName)},enabled=ProfessionalEditing.listNamedMasks(ctx.filesDir).isNotEmpty()){Text("استعادة")}
                    }
                    Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(4.dp)) {
                        ProfessionalEditing.listNamedMasks(ctx.filesDir).forEach { saved -> FilterChip(maskName==saved,{maskName=saved;subjectMask=ProfessionalEditing.loadNamedMask(ctx.filesDir,saved)},{Text(saved)}) }
                    }
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick={subjectMask=Bitmap.createBitmap(base?.width?:1,base?.height?:1,Bitmap.Config.ARGB_8888)}){Text("تحديد جديد")}
                        OutlinedButton(onClick={subjectMask=subjectMask?.let{OfflineAiTools.invertMask(it)}} ,enabled=subjectMask!=null){Text("عكس")}
                        OutlinedButton(onClick={subjectMask=null}){Text("مسح")}
                    }
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick={if(subjectMask!=null){previousMask=subjectMask?.copy(Bitmap.Config.ARGB_8888,false)}} ,enabled=subjectMask!=null){Text("حفظ التحديد الحالي")}
                        OutlinedButton(onClick={if(subjectMask!=null && previousMask!=null) subjectMask=EditorFeatures.combineMasks(subjectMask!!,previousMask!!,false)},enabled=subjectMask!=null && previousMask!=null){Text("دمج مع التحديد المحفوظ")}
                    }
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick={subjectMask=subjectMask?.let{EditorFeatures.expandOrShrinkMask(it,6,true)}},enabled=subjectMask!=null){Text("توسيع 6px")}
                        OutlinedButton(onClick={subjectMask=subjectMask?.let{EditorFeatures.expandOrShrinkMask(it,6,false)}},enabled=subjectMask!=null){Text("تقليص 6px")}
                    }
                    Sl("تنعيم الحواف",maskFeather,0f..0.5f){maskFeather=it}
                    Button(onClick={
                        subjectMask=subjectMask?.let{EditorFeatures.featherMask(it,maskFeather)}
                        val image=base; val mask=subjectMask
                        if(image!=null && mask!=null){base=AdvancedImageOps.applyAlphaMask(image,mask);commit();aiStatus="تم تطبيق القناع اليدوي"}
                    },enabled=subjectMask!=null && base!=null){Text("قص المنطقة المحددة")}
                    Text("اسحب بإصبعك فوق أي شخص أو عنصر لتحديده يدويًا. التحديد التلقائي لأي عنصر والشعر يحتاجان نماذج segmentation إضافية.",style=MaterialTheme.typography.bodySmall)
                }
                Tool.LAYERS -> Column(Modifier.heightIn(max=230.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(6.dp)) {
                    Text("طبقات العناصر: ${ovs.size} — اختر طبقة للتحكم فيها")
                    OutlinedButton(onClick={ovs.add(AdjustmentLayer("تعديلات جديدة"));sel=ovs.lastIndex;commit()}){Text("إضافة Adjustment Layer")}
                    OutlinedButton(onClick={val image=overlayBitmap;if(image!=null){val layer=Bitmap.createBitmap(image.width,image.height,Bitmap.Config.ARGB_8888);AndroidCanvas(layer).drawBitmap(image,0f,0f,Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG));ovs.add(BitmapLayer(layer,"طبقة صورة"));sel=ovs.lastIndex;commit()}},enabled=overlayBitmap!=null){Text("إضافة الصورة الثانية كطبقة مستقلة")}
                    ovs.indices.reversed().forEach { i ->
                        val item=ovs[i]
                        Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(4.dp)) {
                            FilterChip(sel==i,{sel=i},{Text(when(item){is Label->"نص ${i+1}";is BitmapLayer->item.layerName;is AdjustmentLayer->item.layerName;is Stroke->"رسم ${i+1}";is PathLayer->"مسار قابل للتحرير ${i+1}"})})
                            Text(if(item.visible) "ظاهرة" else "مخفية",style=MaterialTheme.typography.bodySmall)
                            IconButton(onClick={ovs[i]=overlayMeta(item,visible=!item.visible);commit()}) { Text(if(item.visible) "◉" else "○") }
                            IconButton(onClick={if(i>0){val x=ovs.removeAt(i);ovs.add(i-1,x);sel=i-1;commit()}}){Text("↑")}
                            IconButton(onClick={if(i<ovs.lastIndex){val x=ovs.removeAt(i);ovs.add(i+1,x);sel=i+1;commit()}}){Text("↓")}
                        }
                    }
                    if(sel in ovs.indices) {
                        val selected=ovs[sel]
                        Sl("شفافية الطبقة",selected.opacity,0f..1f,{commit()}){v->ovs[sel]=overlayMeta(selected,opacity=v)}
                        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(onClick={subjectMask?.let{ovs[sel]=overlayMask(selected,it.copy(Bitmap.Config.ARGB_8888,true));commit()}},enabled=subjectMask!=null){Text("ربط قناع التحديد بالطبقة")}
                            OutlinedButton(onClick={ovs[sel]=overlayMask(selected,null);commit()},enabled=overlayGetMask(selected)!=null){Text("إزالة قناع الطبقة")}
                        }
                        OutlinedButton(onClick={ovs[sel]=overlayLock(selected,!selected.locked);commit()}){Text(if(selected.locked) "فتح قفل الطبقة" else "قفل الطبقة")}
                        (selected as? AdjustmentLayer)?.let { adjustmentLayer ->
                            TextField(layerRename.ifBlank { adjustmentLayer.layerName },{layerRename=it},label={Text("اسم طبقة التعديل")},singleLine=true)
                            Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                                OutlinedButton(onClick={ovs[sel]=adjustmentLayer.copy(layerName=layerRename.ifBlank { adjustmentLayer.layerName });layerRename="";commit()}){Text("إعادة تسمية")}
                                OutlinedButton(onClick={ovs[sel]=adjustmentLayer.copy(locked=!adjustmentLayer.locked);commit()}){Text(if(adjustmentLayer.locked) "فتح القفل" else "قفل الطبقة")}
                            }
                            val a=adjustmentLayer.adjustment
                            Sl("التعريض",a.exposure,-3f..3f, enabled = !adjustmentLayer.locked){v->ovs[sel]=adjustmentLayer.copy(adjustment=a.copy(exposure=v))}
                            Sl("التباين",a.contrast,0f..2f, enabled = !adjustmentLayer.locked){v->ovs[sel]=adjustmentLayer.copy(adjustment=a.copy(contrast=v))}
                            Sl("التشبع",a.saturation,0f..2f, enabled = !adjustmentLayer.locked){v->ovs[sel]=adjustmentLayer.copy(adjustment=a.copy(saturation=v))}
                            Sl("الحرارة",a.temperature,-1f..1f, enabled = !adjustmentLayer.locked){v->ovs[sel]=adjustmentLayer.copy(adjustment=a.copy(temperature=v))}
                            Sl("الصبغة",a.tint,-1f..1f, enabled = !adjustmentLayer.locked){v->ovs[sel]=adjustmentLayer.copy(adjustment=a.copy(tint=v))}
                            Sl("الوضوح",a.clarity,-1f..1f, enabled = !adjustmentLayer.locked){v->ovs[sel]=adjustmentLayer.copy(adjustment=a.copy(clarity=v))}
                            Sl("الحدة",a.sharpen,0f..2f, enabled = !adjustmentLayer.locked){v->ovs[sel]=adjustmentLayer.copy(adjustment=a.copy(sharpen=v))}
                            OutlinedButton(onClick={ovs[sel]=adjustmentLayer.copy(mask=subjectMask?.copy(Bitmap.Config.ARGB_8888,true))},enabled=subjectMask!=null){Text("ربط قناع التحديد")}
                        }
                        (selected as? PathLayer)?.let { vectorLayer ->
                            Text("خصائص طبقة Vector")
                            Swatches(vectorLayer.color.toLong() and 0xffffffffL){v->ovs[sel]=vectorLayer.copy(color=v.toInt());commit()}
                            Sl("سمك حد الشكل",vectorLayer.w/maxDim(),0.002f..0.08f){v->ovs[sel]=vectorLayer.copy(w=v*maxDim());commit()}
                            FilterChip(vectorLayer.filled,{ovs[sel]=vectorLayer.copy(filled=!vectorLayer.filled);commit()},{Text("تعبئة الشكل")})
                            if(vectorLayer.booleanPath!=null) Text("هذا الشكل محفوظ كمسار Vector ويمكن تحريكه وتغيير حجمه ودورانه وتغيير لونه وحدوده. عمليات Boolean تحول المسار إلى هندسة مركبة.",style=MaterialTheme.typography.bodySmall)
                        }
                        (selected as? Label)?.let { textLayer ->
                            Text("تحويل النص من الإطار الظاهر على الصورة: اسحب الزاوية لتغيير الحجم، والمقبض العلوي للدوران، وداخل الإطار للتحريك.",style=MaterialTheme.typography.bodySmall)
                        }
                        (selected as? BitmapLayer)?.let { bitmapLayer ->
                            TextField(layerRename.ifBlank { bitmapLayer.layerName },{layerRename=it},label={Text("اسم الطبقة")},singleLine=true)
                            Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                                OutlinedButton(onClick={ovs[sel]=bitmapLayer.copy(layerName=layerRename.ifBlank { bitmapLayer.layerName });layerRename="";commit()}){Text("إعادة تسمية")}
                                OutlinedButton(onClick={ovs[sel]=bitmapLayer.copy(locked=!bitmapLayer.locked);commit()}){Text(if(bitmapLayer.locked) "فتح القفل" else "قفل الطبقة")}
                                OutlinedButton(onClick={ovs[sel]=bitmapLayer.copy(mask=subjectMask?.copy(Bitmap.Config.ARGB_8888,true));commit()},enabled=subjectMask!=null){Text("ربط التحديد كقناع")}
                                OutlinedButton(onClick={ovs[sel]=bitmapLayer.copy(mask=null);commit()},enabled=bitmapLayer.mask!=null){Text("إزالة القناع")}
                            }
                            Text(if(bitmapLayer.locked) "الطبقة مقفولة" else "الطبقة مفتوحة")
                            Text("قنوات المصدر المستخدمة")
                            Row(horizontalArrangement=Arrangement.spacedBy(5.dp)) {
                                listOf("R" to 1,"G" to 2,"B" to 4).forEach { (label,bit) ->
                                    FilterChip(bitmapLayer.channelMask and bit != 0,{ val next=if(bitmapLayer.channelMask and bit != 0) bitmapLayer.channelMask and bit.inv() else bitmapLayer.channelMask or bit; ovs[sel]=bitmapLayer.copy(channelMask=next);commit() },{Text(label)})
                                }
                            }
                            Text("تحويل طبقة الصورة")
                            Sl("الحجم",bitmapLayer.scale,.1f..3f, enabled = !bitmapLayer.locked){v->ovs[sel]=bitmapLayer.copy(scale=v)}
                            Sl("الدوران",bitmapLayer.rotation,-180f..180f, enabled = !bitmapLayer.locked){v->ovs[sel]=bitmapLayer.copy(rotation=v)}
                            Sl("الإزاحة الأفقية",bitmapLayer.offsetX/base!!.width,-.5f.. .5f, enabled = !bitmapLayer.locked){v->ovs[sel]=bitmapLayer.copy(offsetX=v*base!!.width)}
                            Sl("الإزاحة الرأسية",bitmapLayer.offsetY/base!!.height,-.5f.. .5f, enabled = !bitmapLayer.locked){v->ovs[sel]=bitmapLayer.copy(offsetY=v*base!!.height)}
                            Text("نمط مزج الطبقة")
                            Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(4.dp)) { AdvancedImageOps.BlendMode.values().forEach { mode -> FilterChip(bitmapLayer.blendMode==mode,{ovs[sel]=bitmapLayer.copy(blendMode=mode)},{Text(mode.name)}) } }
                        }
                        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                            OutlinedButton({if(sel in ovs.indices){ovs.removeAt(sel);sel=-1;commit()} }){Text("حذف")}
                            OutlinedButton({if(sel in ovs.indices){val item=ovs[sel];ovs.add(sel+1,when(item){is Label->item.copy(at=item.at+Offset(24f,24f));is Stroke->item.copy(pts=item.pts.map{it+Offset(24f,24f)},mask=item.mask?.copy(Bitmap.Config.ARGB_8888,true),locked=false);is BitmapLayer->BitmapLayer(item.bitmap,item.layerName+" نسخة",item.visible,item.opacity,item.offsetX,item.offsetY,item.scale,item.rotation,item.blendMode,item.mask?.copy(Bitmap.Config.ARGB_8888,true),false,item.channelMask,item.smartFilters.toList());is AdjustmentLayer->item.copy(layerName=item.layerName+" نسخة",mask=item.mask?.copy(Bitmap.Config.ARGB_8888,true),locked=false);is PathLayer->item.copy(pts=item.pts.map{it+Offset(24f,24f)})});sel++;commit()}}){Text("تكرار")}
                        }
                    }
                    Text("تحويل مباشر لمقابض الصور والنصوص والأشكال، وأقنعة مستقلة لكل طبقة بما فيها الرسم والتعديلات. طبقات Adjustment غير مدمرة وتؤثر على الطبقات الموجودة أسفلها.",style=MaterialTheme.typography.bodySmall)
                }
                Tool.ZOOM -> Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Sl("التقريب", zf, 1f..5f) { zf = it }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Button({
                            val b0 = base
                            if (b0 != null && zf > 1.01f) {
                                val r = zoomRect(b0, zf, zc)
                                geo { b ->
                                    val x = r[0].toInt().coerceIn(0, b.width - 1); val y = r[1].toInt().coerceIn(0, b.height - 1)
                                    val cw = (r[2] - r[0]).toInt().coerceIn(1, b.width - x); val ch = (r[3] - r[1]).toInt().coerceIn(1, b.height - y)
                                    Bitmap.createScaledBitmap(Bitmap.createBitmap(b, x, y, cw, ch), b.width, b.height, true)
                                }
                                zf = 1f
                            }
                        }, enabled = zf > 1.01f) { Text("تطبيق التقريب") }
                        OutlinedButton({ zf = (zf - 0.5f).coerceAtLeast(1f) }) { Text("−") }
                        OutlinedButton({ zf = (zf + 0.5f).coerceAtMost(5f) }) { Text("+") }
                    }
                    Text("اسحب الصورة لتحديد مركز التقريب")
                }
                Tool.ROTATE -> Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Sl("الزاوية", angle, -45f..45f) { angle = (Math.round(it * 2f) / 2f) }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Button({ if (angle != 0f) { val a = angle; angle = 0f; geo { rotateFree(it, a) } } }, enabled = angle != 0f) { Text("تطبيق") }
                        OutlinedButton({ angle = 0f }, enabled = angle != 0f) { Text("إعادة") }
                        Text("${angle}° — الإطار الأزرق = المنطقة التي ستبقى")
                    }
                }
                Tool.FREE -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Button({ crop?.let { r -> geo { Bitmap.createBitmap(it, r[0].toInt(), r[1].toInt(), (r[2] - r[0]).toInt(), (r[3] - r[1]).toInt()) } } }) { Text("تطبيق القص") }
                    Text("اسحب زوايا الإطار")
                }
                Tool.MOVE -> Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedButton({ if (sel in ovs.indices) { ovs.removeAt(sel); sel = -1; commit() } }) { Text("حذف المحدد") }
                        Text("اسحب النص أو الشكل من الداخل، أو اسحب مقابض الإطار لتغيير الحجم والدوران")
                    }
                    (ovs.getOrNull(sel) as? Label)?.let { l ->
                        Text("خصائص النص المحدد")
                        TextField(l.text,{ovs[sel]=l.copy(text=it)},label={Text("محتوى النص")},minLines=1)
                        OutlinedButton(onClick={
                            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                                textSize=l.size; letterSpacing=l.letterSpacing
                                val style=when { l.bold && l.italic -> android.graphics.Typeface.BOLD_ITALIC; l.bold -> android.graphics.Typeface.BOLD; l.italic -> android.graphics.Typeface.ITALIC; else -> android.graphics.Typeface.NORMAL }
                                val family=if(l.typefaceName.isNotBlank()) l.typefaceName else when(l.fontFamily){1->"serif";2->"monospace";3->"sans-serif-condensed";4->"casual";5->"cursive";else->"sans-serif"}
                                typeface=try { if(family.startsWith("/") && File(family).exists()) android.graphics.Typeface.createFromFile(family) else android.graphics.Typeface.create(family,style) } catch(_:Throwable){android.graphics.Typeface.DEFAULT}
                            }
                            val pieces=mutableListOf<Label>()
                            l.text.split('\n').forEachIndexed { lineIndex,line ->
                                val words=Regex("\\S+").findAll(line).map{it.value}.toList()
                                val widths=words.map{paint.measureText(it)}
                                val space=paint.measureText(" ")
                                val total=widths.sum()+space*(words.size-1).coerceAtLeast(0)
                                var cursor=when(l.align){0->l.at.x;2->l.at.x-total;else->l.at.x-total/2f}
                                val rtl = !java.text.Bidi(line, java.text.Bidi.DIRECTION_DEFAULT_LEFT_TO_RIGHT).baseIsLeftToRight()
                                val wordOrder = if(rtl) words.indices.reversed() else words.indices
                                wordOrder.forEach { wi ->
                                    val word=words[wi]; val w=widths[wi]; val center=cursor+w/2f
                                    pieces.add(l.copy(text=word,at=Offset(center,l.at.y+lineIndex*l.size*l.lineSpacing),align=1,backgroundColor=android.graphics.Color.TRANSPARENT,backgroundPadding=0f,backgroundRadius=0f))
                                    cursor+=w+space
                                }
                            }
                            if(pieces.isNotEmpty()){ovs.removeAt(sel);ovs.addAll(sel,pieces);sel=sel;commit()}
                        }, enabled=l.text.trim().contains(Regex("\\s"))) { Text("فصل الكلمات: تحكم مستقل في كل كلمة") }
                        Text("بعد الفصل، اختر أي كلمة من لوحة الطبقات وعدّل حجمها ولونها وخطها ودورانها منفردة.",style=MaterialTheme.typography.bodySmall,color=MoKnightColors.Muted)
                        Text("لون النص")
                        Swatches(l.color.toLong() and 0xffffffffL){v->ovs[sel]=l.copy(color=v.toInt())}
                        Text("لون الحدود")
                        Swatches(l.strokeColor.toLong() and 0xffffffffL){v->ovs[sel]=l.copy(strokeColor=v.toInt())}
                        Text("لون الظل")
                        Swatches(l.shadowColor.toLong() and 0xffffffffL){v->ovs[sel]=l.copy(shadowColor=v.toInt())}
                        Sl("شفافية النص",l.opacity,0f..1f){v->ovs[sel]=l.copy(opacity=v)}
                        Sl("الحجم", l.size / maxDim(), 0.02f..0.4f) { v -> ovs[sel]=l.copy(size=v*maxDim()) }
                        Sl("الدوران",l.rotation,-180f..180f){v->ovs[sel]=l.copy(rotation=v)}
                        Sl("سمك الحد",l.strokeWidth/maxDim(),0f..0.04f){v->ovs[sel]=l.copy(strokeWidth=v*maxDim())}
                        Sl("الظل",l.shadowRadius/maxDim(),0f..0.05f){v->ovs[sel]=l.copy(shadowRadius=v*maxDim())}
                        Sl("تباعد الحروف",l.letterSpacing,-.1f..0.5f){v->ovs[sel]=l.copy(letterSpacing=v)}
                        Sl("المسافة بين السطور",l.lineSpacing,0.8f..2.5f){v->ovs[sel]=l.copy(lineSpacing=v)}
                        Text("محاذاة النص")
                        Row(horizontalArrangement=Arrangement.spacedBy(5.dp)) { listOf("يسار" to 0,"وسط" to 1,"يمين" to 2).forEach{(n,v)->FilterChip(l.align==v,{ovs[sel]=l.copy(align=v)},{Text(n)})} }
                        Text("خلفية النص")
                        Swatches(l.backgroundColor.toLong() and 0xffffffffL){v->ovs[sel]=l.copy(backgroundColor=v.toInt())}
                        Sl("حشو الخلفية",l.backgroundPadding/maxDim(),0f..0.06f){v->ovs[sel]=l.copy(backgroundPadding=v*maxDim())}
                        Sl("استدارة خلفية النص",l.backgroundRadius/maxDim(),0f..0.08f){v->ovs[sel]=l.copy(backgroundRadius=v*maxDim())}
                        Sl("شفافية الخلفية",((l.backgroundColor ushr 24) and 255)/255f,0f..1f){v->ovs[sel]=l.copy(backgroundColor=(l.backgroundColor and 0x00FFFFFF) or ((v*255).toInt() shl 24))}
                        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                            FilterChip(l.bold,{ovs[sel]=l.copy(bold=!l.bold)},{Text("عريض")})
                            FilterChip(l.italic,{ovs[sel]=l.copy(italic=!l.italic)},{Text("مائل")})
                            listOf("Sans" to 0,"Serif" to 1,"Mono" to 2,"Condensed" to 3,"Casual" to 4,"Cursive" to 5).forEach{(n,v)->FilterChip(l.fontFamily==v,{ovs[sel]=l.copy(fontFamily=v,typefaceName="")},{Text(n)})}
                        }
                        Text("الخطوط المخصصة")
                        OutlinedButton(onClick={pickFont.launch(arrayOf("font/ttf","font/otf","application/octet-stream"))}){Text("استيراد ملف خط TTF / OTF")}
                        Text(if(l.typefaceName.startsWith("/")) "خط مستورد: ${File(l.typefaceName).name}" else "اسم الخط: ${l.typefaceName.ifBlank { "افتراضي" }}",style=MaterialTheme.typography.bodySmall)
                    }
                }
                Tool.DRAW -> { Swatches(color) { color = it }; Sl("سمك القلم", penSize, 0.004f..0.04f) { penSize = it } }
                Tool.PATH -> Column(verticalArrangement=Arrangement.spacedBy(6.dp)) {
                    Text("اضغط على الصورة لإضافة نقاط الشكل بالترتيب")
                    Swatches(color){color=it}
                    Sl("سمك الحد",penSize,0.004f..0.04f){penSize=it}
                    Row(verticalAlignment=Alignment.CenterVertically) { Checkbox(pathClosed,{pathClosed=it}); Text("إغلاق الشكل") ; Spacer(Modifier.width(12.dp)); Checkbox(pathRounded,{pathRounded=it}); Text("تدوير الزوايا"); Spacer(Modifier.width(8.dp)); Checkbox(pathFilled,{pathFilled=it}); Text("تعبئة") }
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                        OutlinedButton({if(pathPoints.isNotEmpty()) pathPoints=pathPoints.dropLast(1)}){Text("حذف آخر نقطة")}
                        OutlinedButton({pathPoints=emptyList()}){Text("مسح النقاط")}
                        Button(enabled=pathPoints.size>=2,onClick={val width=maxOf(4f,maxDim()*penSize);ovs.add(PathLayer(pathPoints,color.toInt(),width,pathClosed,pathRounded,pathFilled));sel=ovs.lastIndex;commit();pathPoints=emptyList()}){Text("اعتماد الشكل القابل للتعديل")}
                    }
                    Text("بعد اعتماد الشكل: اختاره من الطبقات، ثم اسحب أي نقطة لتغيير شكل المسار. اضغط بعيداً عن النقاط لإضافة نقطة جديدة.",style=MaterialTheme.typography.bodySmall)
                    val otherPaths=ovs.indices.filter{it!=sel && ovs[it] is PathLayer}
                    if(otherPaths.isNotEmpty()){
                        Text("عمليات دمج الأشكال Vector")
                        Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(4.dp)){otherPaths.forEach{i->FilterChip(booleanSecondIndex==i,{booleanSecondIndex=i},{Text("شكل ${i+1}")})}}
                    }
                    (ovs.getOrNull(sel) as? PathLayer)?.let { path ->
                        if(path.booleanPath==null && booleanSecondIndex in ovs.indices && ovs[booleanSecondIndex] is PathLayer){
                            val other=ovs[booleanSecondIndex] as PathLayer
                            fun asPath(item:PathLayer):Path {val pp=Path();if(item.booleanPath!=null){pp.set(item.booleanPath)}else if(item.pts.size>=2){pp.moveTo(item.pts.first().x,item.pts.first().y);for(i in 1 until item.pts.size){val a=item.pts[i-1];val b=item.pts[i];val c1=a+item.outgoing.getOrElse(i-1){Offset.Zero};val c2=b+item.incoming.getOrElse(i){Offset.Zero};if(item.outgoing.getOrElse(i-1){Offset.Zero}!=Offset.Zero||item.incoming.getOrElse(i){Offset.Zero}!=Offset.Zero)pp.cubicTo(c1.x,c1.y,c2.x,c2.y,b.x,b.y)else pp.lineTo(b.x,b.y)};if(item.closed)pp.close()};return pp}
                            Row(horizontalArrangement=Arrangement.spacedBy(5.dp)){
                                OutlinedButton(onClick={val result=asPath(path);result.op(asPath(other),Path.Op.UNION);ovs[sel]=path.copy(pts=emptyList(),incoming=emptyList(),outgoing=emptyList(),booleanPath=result,filled=true);commit()}){Text("اتحاد") }
                                OutlinedButton(onClick={val result=asPath(path);result.op(asPath(other),Path.Op.DIFFERENCE);ovs[sel]=path.copy(pts=emptyList(),incoming=emptyList(),outgoing=emptyList(),booleanPath=result,filled=true);commit()}){Text("طرح") }
                                OutlinedButton(onClick={val result=asPath(path);result.op(asPath(other),Path.Op.INTERSECT);ovs[sel]=path.copy(pts=emptyList(),incoming=emptyList(),outgoing=emptyList(),booleanPath=result,filled=true);commit()}){Text("تقاطع") }
                                OutlinedButton(onClick={val result=asPath(path);result.op(asPath(other),Path.Op.XOR);ovs[sel]=path.copy(pts=emptyList(),incoming=emptyList(),outgoing=emptyList(),booleanPath=result,filled=true);commit()}){Text("استبعاد متبادل") }
                            }
                        }
                        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(onClick={ if(pathSelectedPoint in path.pts.indices){ val i=pathSelectedPoint; val prev=path.pts.getOrNull(i-1)?:path.pts[i]; val next=path.pts.getOrNull(i+1)?:path.pts[i]; val tangent=Offset((next.x-prev.x)/6f,(next.y-prev.y)/6f); val inc=path.incoming.toMutableList();val out=path.outgoing.toMutableList();inc[i]=Offset(-tangent.x,-tangent.y);out[i]=tangent;ovs[sel]=path.copy(incoming=inc,outgoing=out,smoothNodes=path.smoothNodes+i);commit()} },enabled=pathSelectedPoint in path.pts.indices){Text("تحويل النقطة لناعمة")}
                            OutlinedButton(onClick={ if(pathSelectedPoint in path.pts.indices){val i=pathSelectedPoint;val inc=path.incoming.toMutableList();val out=path.outgoing.toMutableList();inc[i]=Offset.Zero;out[i]=Offset.Zero;ovs[sel]=path.copy(incoming=inc,outgoing=out,smoothNodes=path.smoothNodes-i);commit()} },enabled=pathSelectedPoint in path.pts.indices){Text("نقطة حادة")}
                        }
                        Text("اسحب مقابض التحكم الظاهرة بجانب النقطة لتعديل انحناء Bézier مباشرة.",style=MaterialTheme.typography.bodySmall)
                        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(onClick={val pts=path.pts.dropLast(1);ovs[sel]=path.copy(pts=pts,incoming=path.incoming.dropLast(1),outgoing=path.outgoing.dropLast(1),smoothNodes=path.smoothNodes.filter{it<pts.size}.toSet());pathSelectedPoint=-1;commit()},enabled=path.pts.size>2){Text("حذف آخر نقطة")}
                            OutlinedButton(onClick={if(pathSelectedPoint in path.pts.indices && path.pts.size>2){val pts=path.pts.toMutableList().apply{removeAt(pathSelectedPoint)};val inc=path.incoming.toMutableList().apply{removeAt(pathSelectedPoint)};val out=path.outgoing.toMutableList().apply{removeAt(pathSelectedPoint)};ovs[sel]=path.copy(pts=pts,incoming=inc,outgoing=out,smoothNodes=path.smoothNodes.filter{it<pts.size}.toSet());pathSelectedPoint=-1;commit()}},enabled=pathSelectedPoint in path.pts.indices && path.pts.size>2){Text("حذف النقطة المحددة")}
                            OutlinedButton(onClick={ovs[sel]=path.copy(closed=!path.closed);commit()}){Text(if(path.closed) "فتح المسار" else "إغلاق المسار")}
                        }
                    }
                }
                Tool.TEXT -> Column(verticalArrangement=Arrangement.spacedBy(5.dp)) {
                    Text("معاينة نص HTML/CSS (معاينة فقط — لا تُضاف كطبقة، والـ JavaScript معطّل)")
                    OutlinedTextField(value = htmlDraft, onValueChange = { htmlDraft = it }, modifier = Modifier.fillMaxWidth(), maxLines = 3)
                    HtmlTextLayerPreview(html = htmlDraft, modifier = Modifier.fillMaxWidth().height(90.dp), backgroundColor = "#222222")
                    Text("لون النص")
                    Swatches(color) { color = it }
                    Text("لون الحدود")
                    Swatches(textOutlineColor.toLong() and 0xffffffffL) { textOutlineColor=it.toInt() }
                    Sl("حجم الخط", penSize, 0.004f..0.08f) { penSize = it }
                    Sl("حد النص",textStrokeWidth,0f..0.025f){textStrokeWidth=it}
                    Sl("تباعد الحروف",textSpacing,-.1f..0.5f){textSpacing=it}
                    Sl("الظل",textShadow,0f..0.04f){textShadow=it}
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp),verticalAlignment=Alignment.CenterVertically) {
                        FilterChip(textBold,{textBold=!textBold},{Text("عريض")})
                        listOf("Sans" to 0,"Serif" to 1,"Mono" to 2,"Condensed" to 3,"Casual" to 4,"Cursive" to 5).forEach{(n,v)->FilterChip(textFamily==v,{textFamily=v},{Text(n)})}
                    }
                    Text("الخطوط المخصصة")
                    OutlinedButton(onClick={pickFont.launch(arrayOf("font/ttf","font/otf","application/octet-stream"))}){Text("استيراد خط TTF / OTF")}
                    Text("اضغط على الصورة لإضافة نص بهذه الإعدادات")
                }
                Tool.STICKER -> Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    emojis.forEach { e -> FilterChip(emoji == e, { emoji = e }, { Text(e) }) }
                }
            }
        }
        }

        var menuOpen by remember { mutableStateOf(false) }
        var moreOpen by remember { mutableStateOf(false) }
        var zoomOpen by remember { mutableStateOf(false) }
        fun closeMenus() { menuOpen = false; moreOpen = false }

        val layersPanel: @Composable (Modifier) -> Unit = { m ->
            PsLayersPanel(
                ovs = ovs, sel = sel, base = base, selOpacity = ovs.getOrNull(sel)?.opacity ?: 1f,
                onSelect = { sel = it },
                onToggle = { i -> ovs[i] = overlayMeta(ovs[i], visible = !ovs[i].visible); commit() },
                onAdd = { ovs.add(AdjustmentLayer("تعديلات جديدة")); sel = ovs.lastIndex; commit() },
                onUp = { if (sel in 0 until ovs.lastIndex) { val x = ovs.removeAt(sel); ovs.add(sel + 1, x); sel += 1; commit() } },
                onDown = { if (sel in 1..ovs.lastIndex) { val x = ovs.removeAt(sel); ovs.add(sel - 1, x); sel -= 1; commit() } },
                onDuplicate = { if(sel in ovs.indices){val item=ovs[sel];ovs.add(sel+1,when(item){is Label->item.copy(at=item.at+Offset(24f,24f));is Stroke->item.copy(pts=item.pts.map{it+Offset(24f,24f)},mask=item.mask?.copy(Bitmap.Config.ARGB_8888,true),locked=false);is BitmapLayer->BitmapLayer(item.bitmap,item.layerName+" نسخة",item.visible,item.opacity,item.offsetX,item.offsetY,item.scale,item.rotation,item.blendMode,item.mask?.copy(Bitmap.Config.ARGB_8888,true),false,item.channelMask,item.smartFilters.toList());is AdjustmentLayer->item.copy(layerName=item.layerName+" نسخة",mask=item.mask?.copy(Bitmap.Config.ARGB_8888,true),locked=false);is PathLayer->item.copy(pts=item.pts.map{it+Offset(24f,24f)})});sel++;commit()} },
                onDelete = { if (sel in ovs.indices) { ovs.removeAt(sel); sel = -1; commit() } },
                onOpacity = { v -> ovs.getOrNull(sel)?.let { ovs[sel] = overlayMeta(it, opacity = v) } },
                onOpacityDone = { commit() },
                onSettings = { activeToolGroup = "التصميم والطبقات"; tool = Tool.LAYERS },
                modifier = m, compact = isLandscape
            )
        }

        val moreItems: @Composable ColumnScope.() -> Unit = {
            DropdownMenuItem(text = { Text("الإعدادات") }, onClick = { closeMenus(); showSettings = true })
            DropdownMenuItem(text = { Text("حفظ SVG") }, enabled = base != null, onClick = { closeMenus(); saveSvg() })
            DropdownMenuItem(text = { Text("أيقونة 1024") }, enabled = base != null, onClick = { closeMenus(); saveAppIcon() })
            DropdownMenuItem(text = { Text("مشاركة") }, enabled = base != null, onClick = {
                closeMenus()
                save()?.let { u ->
                    ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                        type = "image/jpeg"; putExtra(Intent.EXTRA_STREAM, u); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }, null))
                }
            })
            DropdownMenuItem(text = { Text("الصورة الأصلية") }, enabled = base != null, onClick = {
                closeMenus(); if (hist.isNotEmpty()) { restore(0); commit() }
            })
        }

        val zoomChip: @Composable () -> Unit = {
            Box {
                Row(
                    Modifier.clip(RoundedCornerShape(12.dp)).background(MoKnightColors.PanelHigh)
                        .clickable { zoomOpen = true }.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text("${(vs * 100).roundToInt()}%", fontSize = 13.sp, color = MoKnightColors.OnDark)
                    Text("▾", fontSize = 11.sp, color = MoKnightColors.Muted)
                }
                DropdownMenu(expanded = zoomOpen, onDismissRequest = { zoomOpen = false }) {
                    listOf(1f, 1.5f, 2f, 4f, 8f).forEach { z ->
                        DropdownMenuItem(text = { Text("${(z * 100).roundToInt()}%") }, onClick = { zoomOpen = false; vs = z; vo = clampVo(vo, vs) })
                    }
                }
            }
        }

        val comparePill: @Composable () -> Unit = {
            Box(Modifier.clip(RoundedCornerShape(12.dp))
                .background(if (showOrig) MoKnightColors.Primary else MoKnightColors.PanelHigh)
                .padding(horizontal = 14.dp, vertical = 9.dp)
                .pointerInput(Unit) { detectTapGestures(onPress = { showOrig = true; tryAwaitRelease(); showOrig = false }) }) {
                Text("قارن", fontSize = 13.sp, color = MoKnightColors.OnDark)
            }
        }


        if (!isLandscape) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                PsLogoTitle()
                Spacer(Modifier.weight(1f))
                PsIconButton("sun", "ضوء الشمس") { activeToolGroup = "الألوان"; tool = Tool.SUN }
                Button({ save() }, enabled = base != null, shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp)) { Text("حفظ", fontSize = 13.sp) }
                Box {
                    PsIconButton("more", "المزيد") { menuOpen = true }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) { moreItems() }
                }
            }
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp).psPanel(16.dp).padding(horizontal = 4.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween
            ) {
                PsIconButton("home", "العودة للرئيسية") { appPage = AppPage.HOME }
                PsIconButton("open", "فتح صورة") { pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
                PsIconButton("undo", "تراجع", enabled = hi > 0) { if (hi > 0) restore(hi - 1) }
                PsIconButton("redo", "إعادة", enabled = hi < hist.lastIndex) { if (hi < hist.lastIndex) restore(hi + 1) }
                PsIconButton("zoom-in", "تكبير") { vs = (vs * 1.5f).coerceAtMost(8f); vo = clampVo(vo, vs) }
                zoomChip()
                PsIconButton("fit", "ملاءمة") { vs = 1f; vo = Offset.Zero }
                comparePill()
            }
            Spacer(Modifier.height(8.dp))
        } else {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                PsLogoTitle()
                Spacer(Modifier.width(8.dp))
                PsIconButton("home", "العودة للرئيسية") { appPage = AppPage.HOME }
                Spacer(Modifier.width(4.dp))
                PsIconButton("open", "فتح صورة") { pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
                PsIconButton("undo", "تراجع", enabled = hi > 0) { if (hi > 0) restore(hi - 1) }
                PsIconButton("redo", "إعادة", enabled = hi < hist.lastIndex) { if (hi < hist.lastIndex) restore(hi + 1) }
                PsIconButton("zoom-out", "تصغير") { vs = (vs / 1.5f).coerceAtLeast(1f); vo = clampVo(vo, vs) }
                PsIconButton("zoom-in", "تكبير") { vs = (vs * 1.5f).coerceAtMost(8f); vo = clampVo(vo, vs) }
                zoomChip()
                PsIconButton("fit", "ملاءمة") { vs = 1f; vo = Offset.Zero }
                Spacer(Modifier.weight(1f))
                comparePill()
                PsIconButton("sun", "ضوء الشمس") { activeToolGroup = "الألوان"; tool = Tool.SUN }
                Button({ save() }, enabled = base != null, shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp)) { Text("حفظ", fontSize = 13.sp) }
                Box {
                    PsIconButton("more", "المزيد") { menuOpen = true }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) { moreItems() }
                }
            }
        }

        EditorModeCapsule(
            selected = editorMode,
            onSelect = { mode ->
                editorMode = mode
                when (mode) {
                    "تحرير" -> { activeToolGroup = "أساسي"; tool = Tool.ADJUST }
                    "AI Studio" -> { activeToolGroup = "AI والتحديد"; tool = Tool.AI }
                    "الأدوات" -> { activeToolGroup = "التصميم والطبقات"; tool = Tool.LAYERS }
                }
            }
        )
        Spacer(Modifier.height(6.dp))

        Row(
            Modifier.weight(1f).fillMaxWidth().padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (isLandscape && editorMode != "AI Studio") {
                PsToolRail(toolGroups.flatMap { it.second }, tool) { t ->
                    tool = t; activeToolGroup = toolGroups.first { g -> t in g.second }.first
                }
            }
        Canvas(
            Modifier.weight(1.75f).fillMaxHeight().clip(RoundedCornerShape(16.dp)).background(MoKnightColors.CanvasBg).border(1.dp, MoKnightColors.BorderBrush, RoundedCornerShape(16.dp)).onSizeChanged { box = it }
                .pointerInput(tool, base != null, penSize, color, healRadius, smartRepair, maskBrushRadius, maskErase, maskHardness, aiPickMode, sel, editLayerMask) {
                    if (base == null) return@pointerInput
                    when (tool) {
                        Tool.CROP -> detectDragGestures(
                            onDragStart = { p ->
                                val q = toBmp(p)
                                val nearest = perspectiveCorners.indices.minByOrNull { i ->
                                    val c = perspectiveCorners[i]; (c.x-q.x)*(c.x-q.x) + (c.y-q.y)*(c.y-q.y)
                                } ?: -1
                                val hitRadius = 44f / (minOf(box.width.toFloat() / base!!.width, box.height.toFloat() / base!!.height) * vs)
                                selectedPerspectiveCorner = if (nearest >= 0) {
                                    val c = perspectiveCorners[nearest]
                                    if ((c.x-q.x)*(c.x-q.x) + (c.y-q.y)*(c.y-q.y) <= hitRadius*hitRadius) nearest else -1
                                } else -1
                            },
                            onDrag = { change, _ ->
                                val i = selectedPerspectiveCorner
                                val b = base
                                if (i in 0..3 && b != null) {
                                    val q = toBmp(change.position)
                                    perspectiveCorners[i] = Offset(q.x.coerceIn(0f,b.width.toFloat()), q.y.coerceIn(0f,b.height.toFloat()))
                                }
                            },
                            onDragEnd = { selectedPerspectiveCorner = -1 }
                        )
                        Tool.DRAW -> detectDragGestures(
                            onDragStart = { cur = listOf(toBmp(it)) },
                            onDrag = { ch, _ -> cur = cur + toBmp(ch.position) },
                            onDragEnd = {
                                if (cur.isNotEmpty()) { ovs.add(Stroke(cur, color.toInt(), penSize * maxDim())); commit() }
                                cur = emptyList()
                            },
                            onDragCancel = { cur = emptyList() })
                        Tool.FREE -> detectDragGestures(
                            onDragStart = { p ->
                                val q = toBmp(p); val r = crop ?: return@detectDragGestures
                                val cs = listOf(r[0] to r[1], r[2] to r[1], r[0] to r[3], r[2] to r[3])
                                val d = cs.map { (x, y) -> (x - q.x) * (x - q.x) + (y - q.y) * (y - q.y) }
                                corner = d.indices.minByOrNull { d[it] } ?: -1
                            },
                            onDrag = { ch, _ ->
                                val r = crop; val b = base
                                if (r != null && b != null) {
                                    val q = toBmp(ch.position)
                                    val x = q.x.coerceIn(0f, b.width.toFloat()); val y = q.y.coerceIn(0f, b.height.toFloat())
                                    val n = r.copyOf()
                                    if (corner == 0 || corner == 2) n[0] = minOf(x, r[2] - 50f) else n[2] = maxOf(x, r[0] + 50f)
                                    if (corner == 0 || corner == 1) n[1] = minOf(y, r[3] - 50f) else n[3] = maxOf(y, r[1] + 50f)
                                    crop = n
                                }
                            })
                        Tool.MOVE -> detectDragGestures(
                            onDragStart = { p ->
                                val q = toBmp(p); val b = base!!; val hitR=maxDim()*.05f
                                val selected=ovs.getOrNull(sel)
                                if(selected is Label && !selected.locked){
                                    val lines=selected.text.split('\n'); val width=(lines.maxOfOrNull{it.length}?:1)*selected.size*.62f
                                    val height=lines.size*selected.size*selected.lineSpacing
                                    val center=Offset(selected.at.x,selected.at.y+height*.35f); overlayTransformCenter=center
                                    val br=Offset(selected.at.x+width*.5f,selected.at.y+height*.75f)
                                    val rot=Offset(center.x,selected.at.y-height*.25f)
                                    when { (q-br).getDistance()<hitR -> {overlayTransformMode=1;overlayTransformStartDistance=(q-center).getDistance().coerceAtLeast(1f);overlayTransformStartSize=selected.size}
                                        (q-rot).getDistance()<hitR -> {overlayTransformMode=2;overlayTransformStartAngle=Math.toDegrees(kotlin.math.atan2((q-center).y.toDouble(),(q-center).x.toDouble())).toFloat();overlayTransformStartRotation=selected.rotation}
                                        else -> overlayTransformMode=0 }
                                } else if(selected is PathLayer && !selected.locked && (selected.pts.isNotEmpty() || selected.booleanPath!=null)){
                                    val bounds=pathLayerBounds(selected);val minX=bounds.left;val maxX=bounds.right;val minY=bounds.top;val maxY=bounds.bottom
                                    val center=Offset((minX+maxX)/2f,(minY+maxY)/2f);overlayTransformCenter=center
                                    val br=Offset(maxX,maxY);val rot=Offset(center.x,minY-maxDim()*.08f)
                                    when{(q-br).getDistance()<hitR->{overlayTransformMode=1;overlayTransformStartDistance=(q-center).getDistance().coerceAtLeast(1f)}
                                        (q-rot).getDistance()<hitR->{overlayTransformMode=2;overlayTransformStartAngle=Math.toDegrees(kotlin.math.atan2((q-center).y.toDouble(),(q-center).x.toDouble())).toFloat()}
                                        else->overlayTransformMode=0}
                                    overlayTransformStartSize=1f;overlayTransformStartRotation=0f
                                } else {
                                    overlayTransformMode=0
                                    sel = ovs.indices.filter { ovs[it] is Label || ovs[it] is PathLayer || ovs[it] is BitmapLayer }.minByOrNull { i ->
                                        when(val item=ovs[i]) {
                                            is Label -> (item.at.x-q.x).let{it*it}+(item.at.y-item.size/3-q.y).let{it*it}
                                            is PathLayer -> if(item.pts.isNotEmpty()) item.pts.minOf{pt->(pt.x-q.x).let{it*it}+(pt.y-q.y).let{it*it}} else {val r=pathLayerBounds(item);val c=Offset(r.centerX(),r.centerY());(c-q).let{it.x*it.x+it.y*it.y}}
                                            is BitmapLayer -> { val cx=b.width/2f+item.offsetX; val cy=b.height/2f+item.offsetY; (cx-q.x).let{it*it}+(cy-q.y).let{it*it} }
                                            else -> Float.MAX_VALUE
                                        }
                                    } ?: -1
                                }
                                val picked=ovs.getOrNull(sel) as? BitmapLayer
                                if(picked!=null){bitmapTransformStartDistance=(q-Offset(b.width/2f+picked.offsetX,b.height/2f+picked.offsetY)).getDistance().coerceAtLeast(1f);bitmapTransformStartScale=picked.scale}
                            },
                            onDrag = { change, d ->
                                when(val item=ovs.getOrNull(sel)) {
                                    is Label -> if(!item.locked) when(overlayTransformMode){
                                        1 -> {val factor=((toBmp(change.position)-overlayTransformCenter).getDistance()/overlayTransformStartDistance).coerceIn(.05f,8f);val m=Matrix().apply{setScale(factor,factor,overlayTransformCenter.x,overlayTransformCenter.y)};ovs[sel]=item.copy(size=(overlayTransformStartSize*factor).coerceIn(maxDim()*.015f,maxDim()*.8f),mask=transformOverlayMask(item.mask,m))}
                                        2 -> {val q=toBmp(change.position);val a=Math.toDegrees(kotlin.math.atan2((q-overlayTransformCenter).y.toDouble(),(q-overlayTransformCenter).x.toDouble())).toFloat();val delta=a-overlayTransformStartAngle;val m=Matrix().apply{setRotate(delta,overlayTransformCenter.x,overlayTransformCenter.y)};ovs[sel]=item.copy(rotation=overlayTransformStartRotation+delta,mask=transformOverlayMask(item.mask,m))}
                                        else -> {val delta=d/sc();val m=Matrix().apply{setTranslate(delta.x,delta.y)};ovs[sel]=item.copy(at=item.at+delta,mask=transformOverlayMask(item.mask,m))}
                                    }
                                    is BitmapLayer -> if(!item.locked) {
                                        val q=toBmp(change.position); val center=Offset(base!!.width/2f+item.offsetX,base!!.height/2f+item.offsetY)
                                        when(bitmapTransformMode){1->ovs[sel]=item.copy(scale=(bitmapTransformStartScale*(q-center).getDistance()/bitmapTransformStartDistance).coerceIn(.05f,8f));2->{val a=Math.toDegrees(kotlin.math.atan2((q-center).y.toDouble(),(q-center).x.toDouble())).toFloat();ovs[sel]=item.copy(rotation=bitmapTransformStartRotation+a-bitmapTransformStartAngle)};else->ovs[sel]=item.copy(offsetX=item.offsetX+d.x/sc(),offsetY=item.offsetY+d.y/sc())}
                                    }
                                    is PathLayer -> if(!item.locked) {
                                        val center=overlayTransformCenter; val q=toBmp(change.position)
                                        when(overlayTransformMode){
                                            1->{val factor=((q-center).getDistance()/overlayTransformStartDistance).coerceIn(.05f,20f);val m=Matrix().apply{setScale(factor,factor,center.x,center.y)};val bp=item.booleanPath?.let{Path(it).apply{transform(m)}};ovs[sel]=item.copy(pts=item.pts.map{center+(it-center)*factor},incoming=item.incoming.map{it*factor},outgoing=item.outgoing.map{it*factor},booleanPath=bp,mask=transformOverlayMask(item.mask,m))}
                                            2->{val a=Math.toDegrees(kotlin.math.atan2((q-center).y.toDouble(),(q-center).x.toDouble())).toFloat();val delta=a-overlayTransformStartAngle;val m=Matrix().apply{setRotate(delta,center.x,center.y)};val bp=item.booleanPath?.let{Path(it).apply{transform(m)}};ovs[sel]=item.copy(pts=item.pts.map{rotatePointAround(it,center,delta)},incoming=item.incoming.map{rotatePointAround(it,Offset.Zero,delta)},outgoing=item.outgoing.map{rotatePointAround(it,Offset.Zero,delta)},booleanPath=bp,mask=transformOverlayMask(item.mask,m))}
                                            else->{val delta=d/sc();val m=Matrix().apply{setTranslate(delta.x,delta.y)};val bp=item.booleanPath?.let{Path(it).apply{transform(m)}};ovs[sel]=item.copy(pts=item.pts.map{it+delta},booleanPath=bp,mask=transformOverlayMask(item.mask,m))}
                                        }
                                    }
                                }
                            },
                            onDragEnd = { if (sel >= 0) commit(); bitmapTransformMode=0;overlayTransformMode=0 })
                        Tool.ZOOM -> detectDragGestures(onDrag = { _, d ->
                            val b = base
                            if (b != null && zf > 1f) {
                                val hw = b.width / zf / 2; val hh = b.height / zf / 2
                                zc = Offset((zc.x + d.x / sc()).coerceIn(hw, b.width - hw), (zc.y + d.y / sc()).coerceIn(hh, b.height - hh))
                            }
                        })
                        Tool.TEXT -> detectTapGestures { askAt = toBmp(it) }
                        Tool.AI -> detectTapGestures {
                            if(aiPickMode && !aiBusy){
                                val image=base; val pt=toBmp(it)
                                if(image!=null){aiBusy=true;aiStatus="جاري تحديد العنصر الذي ضغطت عليه…";MediaPipeOfflineModels.selectObjectAt(ctx,image,pt.x,pt.y){result->aiBusy=false;result.onSuccess{subjectMask=it;aiPickMode=false;aiStatus="تم تحديد العنصر. يمكنك إزالة الخلفية أو إزالة العنصر المحدد."}.onFailure{aiStatus="فشل تحديد العنصر: ${it.localizedMessage ?: "خطأ"}"}}}
                            }
                        }
                        Tool.PATH -> awaitEachGesture {
                            val down=awaitFirstDown(requireUnconsumed=false)
                            val q=toBmp(down.position)
                            val selected=ovs.getOrNull(sel) as? PathLayer
                            if(selected!=null && !selected.locked && selected.booleanPath==null){
                                val threshold=maxDim()*.035f
                                val handleHits = selected.pts.indices.flatMap { i ->
                                    buildList {
                                        val incoming=selected.incoming.getOrElse(i){Offset.Zero}; val outgoing=selected.outgoing.getOrElse(i){Offset.Zero}
                                        if(incoming!=Offset.Zero) add((i to 1) to (selected.pts[i]+incoming))
                                        if(outgoing!=Offset.Zero) add((i to 2) to (selected.pts[i]+outgoing))
                                    }
                                }
                                val nearestHandle=handleHits.minByOrNull { (it.second-q).let{v->v.x*v.x+v.y*v.y} }
                                val nearest=selected.pts.indices.minByOrNull { i -> val dx=selected.pts[i].x-q.x; val dy=selected.pts[i].y-q.y; dx*dx+dy*dy } ?: -1
                                val pt=selected.pts.getOrNull(nearest)
                                val handleRadius=threshold*.75f
                                val editingHandle=nearestHandle!=null && (nearestHandle.second-q).getDistance()<handleRadius
                                if(editingHandle || (pt!=null && (pt-q).getDistance()<=threshold)){
                                    pathEditIndex=if(editingHandle) nearestHandle!!.first.first else nearest
                                    pathSelectedPoint=pathEditIndex; val handleSide=if(editingHandle) nearestHandle!!.first.second else 0; down.consume()
                                    var stillPressed=true
                                    while(stillPressed){
                                        val ev=awaitPointerEvent(); val ch=ev.changes.firstOrNull()
                                        if(ch==null){stillPressed=false;continue}
                                        val moved=toBmp(ch.position); val current=ovs.getOrNull(sel) as? PathLayer
                                        if(current!=null && pathEditIndex in current.pts.indices){
                                            val safe=Offset(moved.x.coerceIn(0f,base!!.width.toFloat()),moved.y.coerceIn(0f,base!!.height.toFloat()))
                                            if(handleSide==1 || handleSide==2){ val delta=safe-current.pts[pathEditIndex]; val incoming=current.incoming.toMutableList(); val outgoing=current.outgoing.toMutableList(); if(handleSide==1){incoming[pathEditIndex]=delta;if(pathEditIndex in current.smoothNodes) outgoing[pathEditIndex]=Offset(-delta.x,-delta.y)}else{outgoing[pathEditIndex]=delta;if(pathEditIndex in current.smoothNodes) incoming[pathEditIndex]=Offset(-delta.x,-delta.y)}; ovs[sel]=current.copy(incoming=incoming,outgoing=outgoing) }
                                            else { val delta=safe-current.pts[pathEditIndex]; val updated=current.pts.toMutableList(); updated[pathEditIndex]=safe; val inc=current.incoming.toMutableList();val out=current.outgoing.toMutableList(); if(pathEditIndex in current.smoothNodes){inc[pathEditIndex]=inc[pathEditIndex]+delta;out[pathEditIndex]=out[pathEditIndex]+delta};ovs[sel]=current.copy(pts=updated,incoming=inc,outgoing=out) }
                                        }
                                        stillPressed=ev.changes.any{it.pressed}; ch.consume()
                                    }
                                    commit(); pathEditIndex=-1
                                } else {
                                    ovs[sel]=selected.copy(pts=selected.pts+q,incoming=selected.incoming+Offset.Zero,outgoing=selected.outgoing+Offset.Zero)
                                    down.consume(); commit()
                                }
                            } else { pathPoints=pathPoints+q; down.consume() }
                        }
                        Tool.MASKS -> detectDragGestures(onDragStart={ p ->
                            val b=base!!; val pt=toBmp(p)
                            if(editLayerMask && sel in ovs.indices && !ovs[sel].locked){
                                val layer=ovs[sel]; val current=overlayGetMask(layer)
                                val m=current ?: Bitmap.createBitmap(b.width,b.height,Bitmap.Config.ARGB_8888).apply{eraseColor(android.graphics.Color.WHITE)}
                                ovs[sel]=overlayMask(layer,EditorFeatures.paintMask(m,pt.x,pt.y,maskBrushRadius,!maskErase,maskHardness))
                            } else {
                                if(subjectMask==null) subjectMask=Bitmap.createBitmap(b.width,b.height,Bitmap.Config.ARGB_8888)
                                subjectMask=subjectMask?.let{EditorFeatures.paintMask(it,pt.x,pt.y,maskBrushRadius,!maskErase,maskHardness)}
                            }
                        },onDrag={change,_-> val b=base!!;val pt=toBmp(change.position)
                            if(editLayerMask && sel in ovs.indices && !ovs[sel].locked){val layer=ovs[sel];val current=overlayGetMask(layer);val m=current ?: Bitmap.createBitmap(b.width,b.height,Bitmap.Config.ARGB_8888).apply{eraseColor(android.graphics.Color.WHITE)};ovs[sel]=overlayMask(layer,EditorFeatures.paintMask(m,pt.x,pt.y,maskBrushRadius,!maskErase,maskHardness))}
                            else subjectMask=subjectMask?.let{EditorFeatures.paintMask(it,pt.x,pt.y,maskBrushRadius,!maskErase,maskHardness)}
                        },onDragEnd={if(editLayerMask)commit()})
                        Tool.HEAL -> {
                            var repairPoints = mutableListOf<Offset>()
                            detectDragGestures(onDragStart={ p ->
                                val point=toBmp(p)
                                if(!smartRepair && healSource==null) { healSource=point; repairPoints.clear() }
                                else repairPoints= mutableListOf(point)
                            },onDrag={change,_-> repairPoints.add(toBmp(change.position)); change.consume() },onDragEnd={
                                val points=repairPoints.toList(); val radius=healRadius; val sourcePoint=healSource
                                if(points.isNotEmpty()) {
                                    if(smartRepair) geo { original -> points.fold(original){ image,pt -> AdvancedImageOps.inpaintCircular(image,pt.x,pt.y,radius*.62f) } }
                                    else if(sourcePoint!=null) { geo { original -> points.fold(original){ image,pt -> AdvancedImageOps.cloneStamp(image,sourcePoint.x,sourcePoint.y,pt.x,pt.y,radius) } }; healSource=null }
                                }
                                repairPoints.clear()
                            })
                        }
                        Tool.STICKER -> detectTapGestures { ovs.add(Label(emoji, toBmp(it), -1, 0.12f * maxDim())); commit() }
                        else -> {}
                    }
                }
                .pointerInput(Unit) {
                    awaitEachGesture {
                        awaitFirstDown(requireUnconsumed = false)
                        do {
                            val ev = awaitPointerEvent()
                            if (ev.changes.size >= 2 && ev.changes.none { it.isConsumed }) {
                                val z = ev.calculateZoom(); val pan = ev.calculatePan(); val k = ev.calculateCentroid()
                                val ns = (vs * z).coerceIn(1f, 8f); val ez = ns / vs
                                val c = Offset(box.width / 2f, box.height / 2f)
                                vo = clampVo(k - c - (k - c - vo) * ez + pan, ns); vs = ns
                                ev.changes.forEach { it.consume() }
                            }
                        } while (ev.changes.any { it.pressed })
                    }
                }
        ) {
            val b = base ?: return@Canvas
            val sc = minOf(size.width / b.width, size.height / b.height)
            val tot = sc * vs
            val live = when { cur.isNotEmpty() -> ovs.toList() + Stroke(cur,color.toInt(),penSize*maxDim()); tool==Tool.PATH && pathPoints.isNotEmpty() -> ovs.toList()+Stroke(pathPoints,color.toInt(),penSize*maxDim()); else -> ovs.toList() }
            drawIntoCanvas { cv ->
                val n = cv.nativeCanvas
                n.save()
                n.clipRect(0f, 0f, size.width, size.height)
                n.translate(vo.x, vo.y)
                n.translate(size.width / 2, size.height / 2); n.scale(vs, vs); n.translate(-size.width / 2, -size.height / 2)
                n.translate((size.width - b.width * sc) / 2, (size.height - b.height * sc) / 2)
                n.scale(sc, sc)
                n.clipRect(0f, 0f, b.width.toFloat(), b.height.toFloat())
                val rotating = tool == Tool.ROTATE && angle != 0f && !showOrig
                if (rotating) { n.save(); n.rotate(angle, b.width / 2f, b.height / 2f) }
                if (showOrig) paintAll(n, b, null, emptyList()) else paintAll(n, b, buildMatrix(bright, contrast, sat, filter, warmth), live, fx())
                if (!showOrig && tool == Tool.DOUBLE) overlayBitmap?.let { second ->
                    val previewMatrix = Matrix().apply {
                        val cx=b.width/2f; val cy=b.height/2f
                        postTranslate(-second.width/2f,-second.height/2f); postScale(blendScale,blendScale); postRotate(blendRotation)
                        postTranslate(cx+blendOffsetX*b.width,cy+blendOffsetY*b.height)
                    }
                    val previewPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                        alpha=(blendOpacity.coerceIn(0f,1f)*255).toInt()
                        xfermode=PorterDuffXfermode(when(blendMode){
                            AdvancedImageOps.BlendMode.MULTIPLY->PorterDuff.Mode.MULTIPLY
                            AdvancedImageOps.BlendMode.SCREEN->PorterDuff.Mode.SCREEN
                            AdvancedImageOps.BlendMode.OVERLAY->PorterDuff.Mode.OVERLAY
                            AdvancedImageOps.BlendMode.LIGHTEN->PorterDuff.Mode.LIGHTEN
                            AdvancedImageOps.BlendMode.DARKEN->PorterDuff.Mode.DARKEN
                            AdvancedImageOps.BlendMode.ADD->PorterDuff.Mode.ADD
                            AdvancedImageOps.BlendMode.DIFFERENCE->PorterDuff.Mode.DIFFERENCE
                            AdvancedImageOps.BlendMode.SRC_ATOP->PorterDuff.Mode.SRC_ATOP
                            AdvancedImageOps.BlendMode.XOR->PorterDuff.Mode.XOR
                            else->PorterDuff.Mode.SRC_OVER
                        })
                        colorFilter=ColorMatrixColorFilter(ColorMatrix(floatArrayOf(
                            if(blendChannels and 1!=0) 1f else 0f,0f,0f,0f,0f,
                            0f,if(blendChannels and 2!=0) 1f else 0f,0f,0f,0f,
                            0f,0f,if(blendChannels and 4!=0) 1f else 0f,0f,0f,
                            0f,0f,0f,1f,0f)))
                    }
                    val maskedPreview = if (blendIfEnabled) AdvancedImageOps.blendIfByLuminance(b,second,blendIfShadow,blendIfHighlight,blendIfSoftness) else second
                    val selectionPreview = if(blendUseSelectionMask) subjectMask?.let { ProfessionalEditing.applyMask(maskedPreview,it) } ?: maskedPreview else maskedPreview
                    n.drawBitmap(selectionPreview,previewMatrix,previewPaint)
                    if(selectionPreview!==maskedPreview) selectionPreview.recycle()
                    if(maskedPreview!==second) maskedPreview.recycle()
                }
                if (rotating) n.restore()
                if (!showOrig && tool == Tool.CROP && perspectiveCorners.size == 4) {
                    val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xDFFFFFFF.toInt(); style = Paint.Style.STROKE; strokeWidth = 2.2f / tot }
                    val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xAA000000.toInt(); style = Paint.Style.STROKE; strokeWidth = 6f / tot }
                    val pts = perspectiveCorners.toList()
                    fun mix(a: Offset, z: Offset, t: Float) = Offset(a.x + (z.x-a.x)*t, a.y + (z.y-a.y)*t)
                    val outline = android.graphics.Path().apply { moveTo(pts[0].x,pts[0].y); for(i in 1..3) lineTo(pts[i].x,pts[i].y); close() }
                    n.drawPath(outline, shadowPaint); n.drawPath(outline, gridPaint)
                    for (i in 1..2) {
                        val t=i/3f
                        val top=mix(pts[0],pts[1],t); val bottom=mix(pts[3],pts[2],t)
                        val left=mix(pts[0],pts[3],t); val right=mix(pts[1],pts[2],t)
                        n.drawLine(top.x,top.y,bottom.x,bottom.y,gridPaint); n.drawLine(left.x,left.y,right.x,right.y,gridPaint)
                    }
                    pts.forEachIndexed { index, point ->
                        val handle = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = if (index == selectedPerspectiveCorner) 0xFFFF8A00.toInt() else 0xFF00C8FF.toInt(); style = Paint.Style.FILL }
                        n.drawCircle(point.x, point.y, 13f / tot, handle)
                        val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 3f / tot }
                        n.drawCircle(point.x, point.y, 13f / tot, ring)
                    }
                }
                if (!showOrig && tool==Tool.MOVE) (ovs.getOrNull(sel) as? BitmapLayer)?.let { layer ->
                    if(!layer.locked){ val cx=b.width/2f+layer.offsetX; val cy=b.height/2f+layer.offsetY; val hw=b.width*layer.scale/2f; val hh=b.height*layer.scale/2f
                        val frame=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE;color=0xFF00D7FF.toInt();strokeWidth=3f/tot}
                        n.drawRect(cx-hw,cy-hh,cx+hw,cy+hh,frame)
                        val center=Offset(cx,cy); val corners=listOf(Offset(cx-hw,cy-hh),Offset(cx+hw,cy-hh),Offset(cx+hw,cy+hh),Offset(cx-hw,cy+hh)).map{rotatePointAround(it,center,layer.rotation)}
                        corners.forEach{pt->val hp=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=android.graphics.Color.WHITE;style=Paint.Style.FILL};n.drawCircle(pt.x,pt.y,12f/tot,hp);hp.color=0xFF008FA8.toInt();n.drawCircle(pt.x,pt.y,7f/tot,hp)}
                        val rotateHandle=rotatePointAround(center+Offset(0f,-hh-maxDim()*.08f),center,layer.rotation); val top=rotatePointAround(center+Offset(0f,-hh),center,layer.rotation);n.drawLine(top.x,top.y,rotateHandle.x,rotateHandle.y,frame);n.drawCircle(rotateHandle.x,rotateHandle.y,10f/tot,Paint(Paint.ANTI_ALIAS_FLAG).apply{color=0xFFFFB300.toInt()})
                    }
                }
                if (!showOrig && tool==Tool.MOVE) {
                    val frame=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE;color=0xFF00D7FF.toInt();strokeWidth=3f/tot}
                    val handle=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.FILL;color=android.graphics.Color.WHITE}
                    when(val selected=ovs.getOrNull(sel)){
                        is Label->{val lines=selected.text.split('\n');val width=(lines.maxOfOrNull{it.length}?:1)*selected.size*.62f;val height=lines.size*selected.size*selected.lineSpacing;val left=selected.at.x-width/2f;val top=selected.at.y-selected.size;val rect=RectF(left,top,left+width,top+height);n.save();n.rotate(selected.rotation,selected.at.x,selected.at.y);n.drawRect(rect,frame);val br=Offset(rect.right,rect.bottom);n.drawCircle(br.x,br.y,12f/tot,handle);handle.color=0xFF008FA8.toInt();n.drawCircle(br.x,br.y,7f/tot,handle);val rh=Offset(selected.at.x,top-maxDim()*.08f);n.drawLine(selected.at.x,top,rh.x,rh.y,frame);handle.color=0xFFFFB300.toInt();n.drawCircle(rh.x,rh.y,10f/tot,handle);n.restore()}
                        is PathLayer->{if(selected.pts.isNotEmpty() || selected.booleanPath!=null){val bounds=pathLayerBounds(selected);val minX=bounds.left;val maxX=bounds.right;val minY=bounds.top;val maxY=bounds.bottom;n.drawRect(bounds,frame);n.drawCircle(maxX,maxY,12f/tot,handle);handle.color=0xFF008FA8.toInt();n.drawCircle(maxX,maxY,7f/tot,handle);val cx=(minX+maxX)/2f;val rh=Offset(cx,minY-maxDim()*.08f);n.drawLine(cx,minY,rh.x,rh.y,frame);handle.color=0xFFFFB300.toInt();n.drawCircle(rh.x,rh.y,10f/tot,handle)}}
                        else -> Unit
                    }
                }
                if (!showOrig && tool==Tool.PATH) (ovs.getOrNull(sel) as? PathLayer)?.let { path ->
                    val hp=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE;color=0xFF00C8FF.toInt();strokeWidth=2f/tot}
                    val node=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.FILL;color=android.graphics.Color.WHITE}
                    path.pts.indices.forEach{i-> val pt=path.pts[i]; val inc=pt+path.incoming.getOrElse(i){Offset.Zero};val out=pt+path.outgoing.getOrElse(i){Offset.Zero}; if(inc!=pt){n.drawLine(pt.x,pt.y,inc.x,inc.y,hp);n.drawCircle(inc.x,inc.y,7f/tot,node)};if(out!=pt){n.drawLine(pt.x,pt.y,out.x,out.y,hp);n.drawCircle(out.x,out.y,7f/tot,node)};n.drawCircle(pt.x,pt.y,9f/tot,node);node.color=if(i==pathSelectedPoint) 0xFFFF9800.toInt() else 0xFF00A8CC.toInt();n.drawCircle(pt.x,pt.y,5f/tot,node);node.color=android.graphics.Color.WHITE }
                }
                val activeMaskForDisplay = if(editLayerMask) ovs.getOrNull(sel)?.let(::overlayGetMask) else subjectMask
                if(!showOrig && (tool==Tool.AI || tool==Tool.MASKS)) activeMaskForDisplay?.let { mask ->
                    val tint=Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                        alpha=115
                        colorFilter=android.graphics.PorterDuffColorFilter(android.graphics.Color.CYAN,PorterDuff.Mode.SRC_IN)
                    }
                    n.drawBitmap(mask,null,RectF(0f,0f,b.width.toFloat(),b.height.toFloat()),tint)
                }
                val activeOutline = if(editLayerMask) activeMaskForDisplay?.let(::buildSelectionOutline) else selectionOutline
                if (!showOrig && (tool == Tool.AI || tool == Tool.MASKS)) activeOutline?.let { outline ->
                    val darkEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        style = Paint.Style.STROKE; color = android.graphics.Color.BLACK
                        strokeWidth = 5f / tot; pathEffect = DashPathEffect(floatArrayOf(12f / tot, 8f / tot), 0f)
                    }
                    n.drawPath(outline, darkEdge)
                    val lightEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        style = Paint.Style.STROKE; color = android.graphics.Color.WHITE
                        strokeWidth = 2.4f / tot; pathEffect = DashPathEffect(floatArrayOf(12f / tot, 8f / tot), 10f / tot)
                    }
                    n.drawPath(outline, lightEdge)
                }
                val pp = Paint()
                if (tool == Tool.ROTATE && angle != 0f) {
                    val (iw, ih) = inscribedSize(b.width.toFloat(), b.height.toFloat(), angle)
                    val l = (b.width - iw) / 2f; val t = (b.height - ih) / 2f
                    pp.style = Paint.Style.STROKE; pp.color = 0xFF00E5FF.toInt(); pp.strokeWidth = 3f / tot
                    n.drawRect(l, t, l + iw, t + ih, pp)
                    pp.style = Paint.Style.FILL
                }
                (crop ?: if (tool == Tool.ZOOM && zf > 1f) zoomRect(b, zf, zc) else null)?.let { r ->
                    val w = b.width.toFloat(); val h = b.height.toFloat()
                    pp.color = 0x99000000.toInt()
                    n.drawRect(0f, 0f, w, r[1], pp); n.drawRect(0f, r[3], w, h, pp)
                    n.drawRect(0f, r[1], r[0], r[3], pp); n.drawRect(r[2], r[1], w, r[3], pp)
                    pp.style = Paint.Style.STROKE; pp.color = -1; pp.strokeWidth = 3f / tot
                    n.drawRect(r[0], r[1], r[2], r[3], pp)
                }
                (ovs.getOrNull(sel) as? Label)?.let { l ->
                    pp.style = Paint.Style.STROKE; pp.color = 0xFF00E5FF.toInt(); pp.strokeWidth = 3f / tot
                    n.drawCircle(l.at.x, l.at.y - l.size / 3, l.size * 0.7f, pp)
                }
                (ovs.getOrNull(sel) as? PathLayer)?.let { path ->
                    path.pts.forEachIndexed { index, point ->
                        pp.style=Paint.Style.FILL; pp.color=if(index==pathSelectedPoint) 0xFFFF7043.toInt() else 0xFFFFD740.toInt()
                        n.drawCircle(point.x,point.y, maxOf(8f, maxDim()*.007f),pp)
                    }
                }
                n.restore()
            }
        }
            if (isLandscape) {
                Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    layersPanel(Modifier.weight(1.05f).fillMaxWidth())
                    toolPanel(Modifier.weight(1f).fillMaxWidth().psPanel(16.dp))
                }
            } else {
                layersPanel(Modifier.weight(0.62f).fillMaxHeight())
            }
        }
        if (!isLandscape) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp).psPanel(18.dp).padding(top = 6.dp)) {
                Box(Modifier.align(Alignment.CenterHorizontally).size(width = 36.dp, height = 4.dp)
                    .clip(RoundedCornerShape(2.dp)).background(MoKnightColors.Outline))
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp)) {
                    toolGroups.forEach { (group, items) ->
                        PsGroupTab(group, activeToolGroup == group) { activeToolGroup = group; if (tool !in items) tool = items.first() }
                    }
                }
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    toolGroups.first { it.first == activeToolGroup }.second.forEach { t ->
                        PsToolButton(t.name, t.label, tool == t) { tool = t }
                    }
                }
                HorizontalDivider(color = MoKnightColors.Divider)
                toolPanel(Modifier.fillMaxWidth())
            }
            Box(Modifier.fillMaxWidth().padding(horizontal = 8.dp).padding(bottom = 6.dp)) {
                PsBottomNav(selected = when {
                    editorMode == "تحرير" -> 2
                    editorMode == "AI Studio" -> 2
                    else -> 1
                }) { i ->
                    when (i) {
                        0 -> appPage = AppPage.HOME
                        1 -> { editorMode = "الأدوات"; activeToolGroup = "التصميم والطبقات"; tool = Tool.LAYERS }
                        2 -> { editorMode = "تحرير"; activeToolGroup = "أساسي"; tool = Tool.ADJUST }
                        3 -> { moreOpen = true }
                        else -> showSettings = true
                    }
                }
                DropdownMenu(expanded = moreOpen, onDismissRequest = { moreOpen = false }) { moreItems() }
            }
        }
    }

    if (showSettings) {
        SettingsDialog(prefs = prefs, themePreset = themePreset, onTheme = { id -> themePreset=id; MoKnightColors.applyPreset(id); prefs.edit().putInt("theme_preset",id).apply() }, onModels = { showModelManager = true }, onClose = { showSettings=false })
    }
    if (showModelManager) ModelDownloadDialog(ctx) { showModelManager = false }

    askAt?.let { at ->
        AlertDialog(
            onDismissRequest = { askAt = null },
            confirmButton = {
                TextButton({
                    if (txt.isNotBlank()) {
                        val label = Label(txt, at, color.toInt(), penSize * maxDim() * 3, textOutlineColor, textStrokeWidth * maxDim(), 0xCC000000.toInt(), textShadow * maxDim(), textSpacing, textBold, textFamily, rotation=textRotation, align=textAlign, backgroundColor=((textBgColor and 0x00FFFFFF) or (((textBgOpacity*255).toInt()) shl 24)), backgroundPadding=textBgPadding*maxDim(), typefaceName=textTypefaceName, italic=textItalic, lineSpacing=textLineSpacing, backgroundRadius=textBgRadius*maxDim())
                        val foregroundIndex = ovs.indexOfLast { it is BitmapLayer && it.layerName.contains("العنصر المعزول") }
                        if (textBehindSubject && foregroundIndex >= 0) { ovs.add(foregroundIndex, label); sel = foregroundIndex } else { ovs.add(label); sel = ovs.lastIndex }
                        commit()
                    }
                    txt = ""; askAt = null
                }) { Text("إضافة") }
            },
            text = { Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
                TextField(txt, { txt = it }, placeholder = { Text("اكتب النص") }, minLines=2)
                Text("خصائص النص قبل الإضافة")
                val hasForegroundSubject = ovs.any { it is BitmapLayer && it.layerName.contains("العنصر المعزول") }
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Checkbox(checked=textBehindSubject, onCheckedChange={textBehindSubject=it}, enabled=hasForegroundSubject)
                    Text("ضع النص خلف الشخص/العنصر المعزول")
                }
                Sl("الدوران",textRotation,-180f..180f){textRotation=it}
                Row(horizontalArrangement=Arrangement.spacedBy(5.dp)){listOf("يسار" to 0,"وسط" to 1,"يمين" to 2).forEach{(n,v)->FilterChip(textAlign==v,{textAlign=v},{Text(n)})}}
                Text("لون خلفية النص")
                Swatches(textBgColor.toLong() and 0xffffffffL){textBgColor=it.toInt()}
                Sl("شفافية الخلفية",textBgOpacity,0f..1f){textBgOpacity=it}
                Sl("حشو الخلفية",textBgPadding,0f..0.06f){textBgPadding=it}
                Sl("استدارة الخلفية",textBgRadius,0f..0.08f){textBgRadius=it}
                Sl("المسافة بين السطور",textLineSpacing,0.8f..2.5f){textLineSpacing=it}
                Sl("سمك الحد",textStrokeWidth,0f..0.025f){textStrokeWidth=it}
                Sl("الظل",textShadow,0f..0.04f){textShadow=it}
                Sl("تباعد الحروف",textSpacing,-.1f..0.5f){textSpacing=it}
                Row(verticalAlignment=Alignment.CenterVertically){ Checkbox(textBold,{textBold=it}); Text("خط عريض") }
            } }
        )
    }
}


@Composable
fun EditorModeCapsule(selected: String, onSelect: (String) -> Unit) {
    val items = listOf("تحرير" to "edit", "AI Studio" to "ai", "الأدوات" to "effects")
    val selectedIndex = items.indexOfFirst { it.first == selected }.coerceAtLeast(0)
    val indicator by animateFloatAsState(
        targetValue = selectedIndex.toFloat(),
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "editorModeIndicator"
    )
    Box(
        Modifier.fillMaxWidth().padding(horizontal = 10.dp).clip(RoundedCornerShape(28.dp))
            .background(CColor(0x66151C35)).border(1.dp, CColor(0x554A7DFF), RoundedCornerShape(28.dp))
            .padding(5.dp)
    ) {
        Row(Modifier.fillMaxWidth()) {
            items.forEachIndexed { index, (label, icon) ->
                Box(Modifier.weight(1f).height(48.dp).clip(RoundedCornerShape(22.dp)).clickable { onSelect(label) }, contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        MoIcon(icon, tint = if (selectedIndex == index) Color.White else MoKnightColors.Muted)
                        Text(label, fontSize = 11.sp, color = if (selectedIndex == index) Color.White else MoKnightColors.Muted)
                    }
                }
            }
        }
        // The selected capsule underline travels between items with a soft spring/bounce.
        Box(
            Modifier.fillMaxWidth(0.31f).align(Alignment.BottomStart)
                .graphicsLayer { translationX = size.width * indicator * 3.2f }
                .padding(horizontal = 12.dp).height(3.dp)
                .clip(RoundedCornerShape(4.dp)).background(CColor(0xFF2F8BFF))
        )
    }
}

@Composable
fun HomeScreen(lastProjectName: String?, onAddImage: () -> Unit, onOpenProject: () -> Unit, onSettings: () -> Unit) {
    val items = listOf("الرئيسية" to "home", "وصف البرنامج" to "info", "المشاريع" to "folder")
    var selected by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().background(MoKnightColors.BackgroundBrush).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            PsLogoTitle()
            Spacer(Modifier.weight(1f))
            PsIconButton("settings", "الإعدادات", onClick = onSettings)
        }
        Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 18.dp), contentAlignment = Alignment.Center) {
            when (selected) {
                0 -> Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(18.dp)) {
                    Text("مرحبًا بك في MoKnight", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = MoKnightColors.OnDark)
                    Text("حرّر صورك يدويًا أو استخدم أدوات الذكاء الاصطناعي من مساحة التحرير.", fontSize = 14.sp, color = MoKnightColors.Muted, textAlign = TextAlign.Center)
                    Box(Modifier.size(width = 250.dp, height = 58.dp).clip(RoundedCornerShape(20.dp)).background(Brush.horizontalGradient(listOf(CColor(0xFF1677FF), CColor(0xFF7B2CFF)))).clickable(onClick = onAddImage), contentAlignment = Alignment.Center) {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) { MoIcon("plus", tint = Color.White); Text("إضافة صورة للتعديل", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White) }
                    }
                    Text("ابدأ بصورة جديدة أو افتح مشروعًا لاحقًا.", fontSize = 12.sp, color = MoKnightColors.Muted)
                }
                1 -> Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("وصف البرنامج", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = MoKnightColors.OnDark)
                    Text("MoKnight Photo Editor هو محرر صور يجمع التحرير اليدوي، الطبقات والأقنعة، الأدوات الإبداعية وAI Studio في مساحة واحدة.", fontSize = 14.sp, color = MoKnightColors.Muted, textAlign = TextAlign.Center)
                }
                else -> Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("المشاريع", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = MoKnightColors.OnDark)
                    if (lastProjectName != null) {
                        Text(lastProjectName, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = MoKnightColors.OnDark)
                        Text("آخر مشروع محفوظ — اضغط لفتحه داخل مساحة التحرير", fontSize = 12.sp, color = MoKnightColors.Muted, textAlign = TextAlign.Center)
                        Button(onClick = onOpenProject, shape = RoundedCornerShape(16.dp)) { Text("فتح المشروع") }
                    } else {
                        Text("لا توجد مشاريع محفوظة بعد.", fontSize = 14.sp, color = MoKnightColors.Muted)
                        Text("بعد حفظ صورة من مساحة التحرير ستظهر هنا لتكملها بسرعة.", fontSize = 12.sp, color = MoKnightColors.Muted, textAlign = TextAlign.Center)
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp).clip(RoundedCornerShape(28.dp)).background(CColor(0x55131A2F)).border(1.dp, CColor(0x444D6CFF), RoundedCornerShape(28.dp)).padding(5.dp)) {
            items.forEachIndexed { i, (label, icon) ->
                Box(Modifier.weight(1f).clip(RoundedCornerShape(22.dp)).clickable { selected = i }.padding(vertical = 11.dp), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        MoIcon(icon, tint = if (selected == i) CColor(0xFF58A6FF) else MoKnightColors.Muted)
                        Text(label, fontSize = 11.sp, color = if (selected == i) Color.White else MoKnightColors.Muted)
                        Box(Modifier.width(if (selected == i) 22.dp else 5.dp).height(3.dp).clip(RoundedCornerShape(3.dp)).background(if (selected == i) CColor(0xFF2F8BFF) else Color.Transparent))
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsDialog(prefs: android.content.SharedPreferences, themePreset: Int, onTheme: (Int) -> Unit, onModels: () -> Unit, onClose: () -> Unit) {
    AlertDialog(onDismissRequest = onClose, title = { Text("إعدادات MoKnight") }, text = {
        Column(Modifier.fillMaxWidth().heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("المظهر والثيمات", style = MaterialTheme.typography.titleMedium)
            val themes = listOf(
                "بنفسجي نيوني" to CColor(0xFF7C4DFF), "تركواز" to CColor(0xFF00BFA5), "أزرق سينمائي" to CColor(0xFF2F8BFF),
                "وردي" to CColor(0xFFE0529C), "برتقالي" to CColor(0xFFFF7A45), "أخضر" to CColor(0xFF2EC27E),
                "أزرق جليدي" to CColor(0xFF6CCBFF), "ذهبي" to CColor(0xFFFFC857), "أحمر" to CColor(0xFFFF4D6D)
            )
            themes.forEachIndexed { id, (label, color) ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { onTheme(id) }.padding(9.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(24.dp).clip(CircleShape).background(color))
                    Text(label, Modifier.weight(1f).padding(horizontal = 10.dp), color = MoKnightColors.OnDark)
                    RadioButton(selected = themePreset == id, onClick = { onTheme(id) })
                }
            }
            HorizontalDivider()
            Text("نماذج الذكاء الاصطناعي", style = MaterialTheme.typography.titleMedium)
            Text("تنزيل النماذج اختياري بالكامل. لن يتم تنزيل أي موديل عند تثبيت التطبيق أو فتحه لأول مرة.", style = MaterialTheme.typography.bodySmall, color = MoKnightColors.Muted)
            Button(onClick = onModels, modifier = Modifier.fillMaxWidth()) { Text("تنزيل وإدارة الموديلات") }
            Text("بعد تنزيل الموديل مرة واحدة، يبقى داخل مساحة التطبيق ويعمل أوفلاين. يمكنك حذفه من نفس الشاشة لتوفير المساحة.", style = MaterialTheme.typography.bodySmall, color = MoKnightColors.Muted)
            HorizontalDivider()
            Text("إعدادات عامة", style = MaterialTheme.typography.titleMedium)
            Text("الواجهة الرئيسية منفصلة عن مساحة تعديل الصور. عند اختيار صورة تنتقل مباشرة إلى مساحة التحرير.", style = MaterialTheme.typography.bodySmall, color = MoKnightColors.Muted)
            Text("وضع العرض الأفقي مصمم ليكون قريبًا من تخطيط Photoshop: أدوات جانبية، لوحة عمل كبيرة، ولوحات تحكم واضحة.", style = MaterialTheme.typography.bodySmall, color = MoKnightColors.Muted)
            var haptics by remember { mutableStateOf(prefs.getBoolean("haptics", true)) }
            var autoSave by remember { mutableStateOf(prefs.getBoolean("autosave", false)) }
            var highQuality by remember { mutableStateOf(prefs.getBoolean("high_quality", true)) }
            Text("تفضيلات التحرير", style = MaterialTheme.typography.titleMedium)
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Switch(haptics, { haptics=it; prefs.edit().putBoolean("haptics",it).apply() }); Text("اهتزازات الواجهة", Modifier.padding(horizontal=8.dp)) }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Switch(autoSave, { autoSave=it; prefs.edit().putBoolean("autosave",it).apply() }); Text("حفظ تلقائي عند الخروج", Modifier.padding(horizontal=8.dp)) }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Switch(highQuality, { highQuality=it; prefs.edit().putBoolean("high_quality",it).apply() }); Text("جودة معالجة عالية", Modifier.padding(horizontal=8.dp)) }
        }
    }, confirmButton = { TextButton(onClick = onClose) { Text("تم") } }, dismissButton = { TextButton(onClick = { onTheme(0) }) { Text("افتراضي") } })
}

@Composable
fun HueWheelPicker(selectedHue: Float, onHueChange: (Float) -> Unit) {
    val wheelColors = listOf(
        CColor(0xFFFF3030), CColor(0xFFFFFF00), CColor(0xFF35D04A),
        CColor(0xFF00D5D5), CColor(0xFF286BFF), CColor(0xFFD52BFF), CColor(0xFFFF3030)
    )
    fun update(point: Offset, width: Float, height: Float) {
        val dx = point.x - width / 2f
        val dy = point.y - height / 2f
        val deg = (Math.toDegrees(kotlin.math.atan2(dy.toDouble(), dx.toDouble())).toFloat() + 360f) % 360f
        onHueChange(deg)
    }
    Canvas(Modifier.size(176.dp).pointerInput(Unit) {
        detectTapGestures { update(it, size.width.toFloat(), size.height.toFloat()) }
    }.pointerInput(Unit) {
        detectDragGestures { change, _ -> update(change.position, size.width.toFloat(), size.height.toFloat()); change.consume() }
    }) {
        val stroke = size.minDimension * .16f
        val radius = (size.minDimension - stroke) / 2f
        drawCircle(
            brush = androidx.compose.ui.graphics.Brush.sweepGradient(wheelColors),
            radius = radius,
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = stroke)
        )
        val angle = Math.toRadians(selectedHue.toDouble())
        val markerRadius = radius
        val center = Offset(size.width / 2f, size.height / 2f)
        val marker = Offset(center.x + kotlin.math.cos(angle).toFloat() * markerRadius, center.y + kotlin.math.sin(angle).toFloat() * markerRadius)
        drawCircle(CColor.White, radius = stroke * .32f, center = marker)
        drawCircle(CColor.Black, radius = stroke * .18f, center = marker)
    }
}

@Composable
fun Sl(label: String, v: Float, r: ClosedFloatingPointRange<Float>, done: () -> Unit = {}, enabled: Boolean = true, on: (Float) -> Unit) {
    val shown = if (r.endInclusive - r.start >= 20f) String.format(java.util.Locale.US, "%.0f", v)
                else String.format(java.util.Locale.US, "%.2f", v)
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.width(92.dp), fontSize = 12.sp, maxLines = 2,
            color = if (enabled) MoKnightColors.OnDark else MoKnightColors.Muted)
        Slider(v, on, valueRange = r, onValueChangeFinished = done, enabled = enabled, modifier = Modifier.weight(1f),
            colors = SliderDefaults.colors(thumbColor = CColor.White, activeTrackColor = MoKnightColors.Accent, inactiveTrackColor = MoKnightColors.Outline))
        Text(shown, Modifier.width(44.dp), fontSize = 12.sp, textAlign = TextAlign.End, color = MoKnightColors.Muted)
    }
}

@Composable
fun Swatches(sel: Long, on: (Long) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        palette.forEach { c ->
            Box(Modifier.size(32.dp).clip(CircleShape).background(CColor(c))
                .border(if (c == sel) 3.dp else 1.dp, CColor.Gray, CircleShape).clickable { on(c) })
        }
    }
}
