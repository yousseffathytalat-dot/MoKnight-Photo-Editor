package com.moknight.photoeditor

import android.graphics.Bitmap
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

/** Rounded violet card with a glowing gradient border, used for every panel. */
fun Modifier.psPanel(radius: Dp = 16.dp): Modifier {
    val shape = RoundedCornerShape(radius)
    return this.clip(shape)
        .background(MoKnightColors.PanelBrush)
        .border(1.dp, MoKnightColors.BorderBrush, shape)
}

/** Semantic vector icon mapping for editor tools. */
fun toolIconName(toolName: String): String = when (toolName) {
    "ADJUST" -> "adjust"; "FILTER" -> "filter"; "SMART_FILTERS" -> "filter"; "CINEMA" -> "effects"; "SUN" -> "sun"; "EFFECTS" -> "effects"
    "CROP" -> "crop"; "ROTATE" -> "rotate"; "ZOOM" -> "zoom-in"; "FREE" -> "selection"; "MOVE" -> "move"
    "HSL" -> "adjust"; "CURVES" -> "curves"; "GRADIENT" -> "gradient"; "DOUBLE" -> "compare"
    "AI" -> "ai"; "MASKS" -> "mask"; "HEAL" -> "heal"
    "LAYERS" -> "layers"; "DRAW" -> "draw"; "TEXT" -> "text"; "STICKER" -> "effects"; "SHAPES" -> "shapes"; "PATH" -> "draw"
    else -> "effects"
}

@Composable
fun PsLogoTitle() {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            "M",
            style = TextStyle(
                brush = Brush.linearGradient(listOf(Color(0xFF38BDF8), Color(0xFF7C4DFF), Color(0xFFD946EF))),
                fontSize = 34.sp, fontWeight = FontWeight.Black
            )
        )
        Column {
            Text("MoKnight", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = MoKnightColors.OnDark)
            Text("Photo Editor", fontSize = 12.sp, color = MoKnightColors.OnDark.copy(alpha = .85f))
        }
    }
}

/** Compact square button with a soft press animation. */
@Composable
fun PsIconButton(iconName: String, desc: String, enabled: Boolean = true, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.86f else 1f, tween(90), label = "psIconScale")
    Box(
        Modifier.size(42.dp)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(RoundedCornerShape(12.dp))
            .background(if (pressed) MoKnightColors.PanelHigh else Color.Transparent)
            .clickable(interactionSource = src, indication = null, enabled = enabled, onClick = onClick)
            .semantics { contentDescription = desc },
        contentAlignment = Alignment.Center
    ) {
        MoIcon(iconName, tint = if (enabled) MoKnightColors.OnDark else MoKnightColors.Muted.copy(alpha = .4f))
    }
}

/** Tab for a tool group, with an animated accent underline. */
@Composable
fun PsGroupTab(label: String, selected: Boolean, onClick: () -> Unit) {
    val textColor by animateColorAsState(
        if (selected) MoKnightColors.OnDark else MoKnightColors.Muted, tween(180), label = "psTabText"
    )
    val barColor by animateColorAsState(
        if (selected) MoKnightColors.Accent else Color.Transparent, tween(180), label = "psTabBar"
    )
    Column(
        Modifier.clickable(onClick = onClick).padding(horizontal = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            label, Modifier.padding(top = 10.dp, bottom = 8.dp), fontSize = 13.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            color = textColor, maxLines = 1
        )
        Box(Modifier.height(2.dp).fillMaxWidth().clip(RoundedCornerShape(1.dp)).background(barColor))
    }
}

/** One tool: glyph + label, solid violet when selected. */
@Composable
fun PsToolButton(toolName: String, label: String, selected: Boolean, width: Dp = 68.dp, onClick: () -> Unit) {
    val bg by animateColorAsState(
        if (selected) MoKnightColors.Primary.copy(alpha = .34f) else Color.Transparent,
        tween(180), label = "psToolBg"
    )
    val fg by animateColorAsState(
        if (selected) Color.White else MoKnightColors.Muted, tween(180), label = "psToolFg"
    )
    val accent by animateColorAsState(
        if (selected) MoKnightColors.Accent else Color.Transparent,
        tween(180), label = "psToolAccent"
    )
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.92f else 1f, tween(90), label = "psToolScale")
    Column(
        Modifier.width(width)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(RoundedCornerShape(12.dp))
            .background(
                if (selected) Brush.verticalGradient(
                    listOf(MoKnightColors.Primary.copy(alpha = .42f), bg, MoKnightColors.Panel.copy(alpha = .72f))
                ) else Brush.verticalGradient(listOf(bg, bg))
            )
            .border(
                if (selected) 1.dp else 0.dp,
                if (selected) Brush.linearGradient(listOf(MoKnightColors.Accent.copy(alpha = .9f), MoKnightColors.PrimaryBright.copy(alpha = .55f)))
                else Brush.linearGradient(listOf(Color.Transparent, Color.Transparent)),
                RoundedCornerShape(12.dp)
            )
            .clickable(interactionSource = src, indication = null, onClick = onClick)
            .padding(vertical = 8.dp, horizontal = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        MoIcon(toolIconName(toolName), tint = fg)
        Text(
            label, fontSize = 10.sp, lineHeight = 12.sp, color = fg, textAlign = TextAlign.Center,
            minLines = 2, maxLines = 2, overflow = TextOverflow.Ellipsis
        )
        Box(Modifier.padding(top = 1.dp).width(if (selected) 18.dp else 5.dp).height(2.dp)
            .clip(RoundedCornerShape(2.dp)).background(accent))
    }
}

/** Landscape: vertical tool rail on the side of the canvas. */
@Composable
fun PsToolRail(tools: List<Tool>, selected: Tool, onSelect: (Tool) -> Unit) {
    Column(
        Modifier.width(64.dp).fillMaxHeight().psPanel(16.dp)
            .verticalScroll(rememberScrollState()).padding(4.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        tools.forEach { t -> PsToolButton(t.name, t.label, t == selected, width = 56.dp) { onSelect(t) } }
    }
}

private fun layerTitle(o: Ov, i: Int): String = when (o) {
    is Label -> "نص ${i + 1}"
    is BitmapLayer -> o.layerName
    is AdjustmentLayer -> o.layerName
    is Stroke -> "رسم ${i + 1}"
    is PathLayer -> "مسار ${i + 1}"
}

private fun layerGlyph(o: Ov): String = when (o) {
    is Label -> "text"
    is BitmapLayer -> "background"
    is AdjustmentLayer -> "adjust"
    is Stroke -> "draw"
    is PathLayer -> "shapes"
}

@Composable
private fun PsLayerRow(
    title: String, glyph: String, thumb: Bitmap?, selected: Boolean,
    visible: Boolean, locked: Boolean, onClick: () -> Unit, onToggle: () -> Unit
) {
    val rowTint by animateColorAsState(
        if (selected) MoKnightColors.Primary.copy(alpha = .28f) else Color.Transparent,
        tween(180), label = "layerSelectionTint"
    )
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
            .background(rowTint)
            .then(if (selected) Modifier.border(1.dp, MoKnightColors.Accent.copy(alpha = .62f), RoundedCornerShape(12.dp)) else Modifier)
            .clickable(onClick = onClick).padding(horizontal = 6.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(Modifier.clickable(onClick = onToggle).padding(2.dp)) {
            MoIcon(if (visible) "eye" else "eye-off", tint = MoKnightColors.OnDark)
        }
        Box(
            Modifier.size(34.dp).clip(RoundedCornerShape(8.dp)).background(MoKnightColors.PanelHigh),
            contentAlignment = Alignment.Center
        ) {
            if (thumb != null && !thumb.isRecycled) {
                Image(thumb.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            } else {
                MoIcon(glyph, tint = MoKnightColors.Accent)
            }
        }
        Text(
            title, Modifier.weight(1f), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            color = if (visible) MoKnightColors.OnDark else MoKnightColors.Muted
        )
        if (locked) MoIcon("lock", tint = MoKnightColors.Muted)
    }
}

@Composable
private fun PsMiniAction(glyph: String, label: String, enabled: Boolean, showLabel: Boolean, onClick: () -> Unit) {
    val c = if (enabled) MoKnightColors.OnDark else MoKnightColors.Muted.copy(alpha = .4f)
    Column(
        Modifier.clip(RoundedCornerShape(10.dp)).clickable(enabled = enabled, onClick = onClick).padding(horizontal = 6.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        MoIcon(glyph, tint = c)
        if (showLabel) Text(label, fontSize = 10.sp, color = c)
    }
}

/** Layers side panel: thumbnails, visibility, reorder, duplicate, delete, opacity. */
@Composable
fun PsLayersPanel(
    ovs: List<Ov>, sel: Int, base: Bitmap?, selOpacity: Float,
    onSelect: (Int) -> Unit, onToggle: (Int) -> Unit, onAdd: () -> Unit,
    onUp: () -> Unit, onDown: () -> Unit, onDuplicate: () -> Unit, onDelete: () -> Unit,
    onOpacity: (Float) -> Unit, onOpacityDone: () -> Unit, onSettings: () -> Unit,
    modifier: Modifier = Modifier, compact: Boolean = false
) {
    val hasSel = sel in ovs.indices
    Column(modifier.psPanel(16.dp).padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("الطبقات", Modifier.weight(1f), fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MoKnightColors.OnDark)
            Box(
                Modifier.size(30.dp).clip(RoundedCornerShape(9.dp)).background(MoKnightColors.Primary).clickable(onClick = onAdd),
                contentAlignment = Alignment.Center
            ) { Text("+", fontSize = 20.sp, color = Color.White) }
        }
        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            ovs.indices.reversed().forEach { i ->
                val o = ovs[i]
                PsLayerRow(
                    layerTitle(o, i), layerGlyph(o), (o as? BitmapLayer)?.bitmap,
                    i == sel, o.visible, o.locked, { onSelect(i) }, { onToggle(i) }
                )
            }
            PsLayerRow("الخلفية", "background", base, false, true, true, {}, {})
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            PsMiniAction("arrow-up", "أعلى", hasSel, !compact, onUp)
            PsMiniAction("arrow-down", "أسفل", hasSel, !compact, onDown)
            PsMiniAction("duplicate", "نسخ", hasSel, !compact, onDuplicate)
            PsMiniAction("close", "حذف", hasSel, !compact, onDelete)
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("الشفافية", Modifier.weight(1f), fontSize = 12.sp, color = MoKnightColors.OnDark)
            Text("${(selOpacity * 100).roundToInt()}%", fontSize = 12.sp, color = MoKnightColors.Muted)
        }
        Slider(
            selOpacity, onOpacity, valueRange = 0f..1f, onValueChangeFinished = onOpacityDone, enabled = hasSel,
            modifier = Modifier.height(24.dp),
            colors = SliderDefaults.colors(
                thumbColor = Color.White,
                activeTrackColor = MoKnightColors.Accent,
                inactiveTrackColor = MoKnightColors.Outline
            )
        )
        if (!compact) {
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(MoKnightColors.PanelHigh)
                    .clickable(onClick = onSettings).padding(vertical = 9.dp),
                contentAlignment = Alignment.Center
            ) { Text("⚙  إعدادات الطبقة", fontSize = 12.sp, color = MoKnightColors.OnDark) }
        }
    }
}

@Composable
private fun PsNavItem(label: String, glyph: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val bg by animateColorAsState(
        if (selected) MoKnightColors.Primary else Color.Transparent, tween(200), label = "psNavBg"
    )
    Column(
        modifier.clip(RoundedCornerShape(22.dp)).background(bg).clickable(onClick = onClick).padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        MoIcon(glyph, tint = if (selected) Color.White else MoKnightColors.OnDark)
        Text(label, fontSize = 11.sp, color = if (selected) Color.White else MoKnightColors.Muted, maxLines = 1)
    }
}

/** Portrait bottom navigation: home, layers, tools, more, settings (first = right in RTL). */
@Composable
fun PsBottomNav(selected: Int, onSelect: (Int) -> Unit) {
    val items = listOf("الرئيسية" to "home", "الطبقات" to "layers", "الأدوات" to "effects", "المزيد" to "more", "الإعدادات" to "settings")
    Row(
        Modifier.fillMaxWidth().psPanel(28.dp).padding(6.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        items.forEachIndexed { i, (label, glyph) ->
            PsNavItem(label, glyph, i == selected, Modifier.weight(1f)) { onSelect(i) }
        }
    }
}
