package com.moknight.photoeditor

import android.graphics.Bitmap
import org.wysaid.nativePort.CGENativeLibrary

/** GPUImage-Plus filter-rule bridge. Rules can be stacked and re-rendered non-destructively. */
object GpuImageEffects {
    fun apply(source: Bitmap, ruleStack: String, intensity: Float = 1f): Bitmap {
        require(ruleStack.isNotBlank()) { "At least one effect rule is required." }
        require(intensity.isFinite())
        val safeIntensity = intensity.coerceIn(0f, 1f)
        return requireNotNull(CGENativeLibrary.filterImage_MultipleEffects(source, ruleStack, safeIntensity)) {
            "GPUImage-Plus could not render the requested effect stack."
        }
    }

    /** RGB curve rule. Each point is x,y in the 0..255 range. */
    fun rgbCurve(points: List<Pair<Int, Int>>): String {
        require(points.size >= 2)
        val sorted = points.map { (x, y) -> x.coerceIn(0, 255) to y.coerceIn(0, 255) }.sortedBy { it.first }
        return "@curve RGB " + sorted.joinToString(" ") { "(${it.first},${it.second})" }
    }

    fun hsl(hue: Float, saturation: Float, luminance: Float): String =
        "@adjust hsl ${hue.coerceIn(-1f, 1f)} ${saturation.coerceIn(-1f, 1f)} ${luminance.coerceIn(-1f, 1f)}"

    fun contrast(value: Float): String = "@adjust contrast ${value.coerceIn(0f, 4f)}"
    fun brightness(value: Float): String = "@adjust brightness ${value.coerceIn(-1f, 1f)}"
    fun saturation(value: Float): String = "@adjust saturation ${value.coerceIn(0f, 2f)}"
    fun vignette(start: Float, end: Float): String =
        "@vignette ${start.coerceIn(0f, 1f)} ${end.coerceIn(0f, 1f)}"
}
