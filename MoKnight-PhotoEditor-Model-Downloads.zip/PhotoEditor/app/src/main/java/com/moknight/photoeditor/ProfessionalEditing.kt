package com.moknight.photoeditor

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.os.Build
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.UUID
import java.util.Locale
import kotlin.math.max

/** Non-destructive document primitives shared by the professional editor tools. */
object ProfessionalEditing {
    enum class NodeType { CORNER, SMOOTH }
    data class VectorNode(
        val x: Float, val y: Float,
        val incomingX: Float = 0f, val incomingY: Float = 0f,
        val outgoingX: Float = 0f, val outgoingY: Float = 0f,
        val type: NodeType = NodeType.CORNER
    )
    data class VectorShape(
        val id: String = UUID.randomUUID().toString(),
        val name: String = "Vector Shape",
        val nodes: List<VectorNode>,
        val closed: Boolean = true,
        val fillColor: Int = Color.TRANSPARENT,
        val strokeColor: Int = Color.BLACK,
        val strokeWidth: Float = 2f
    )

    /** Converts a polyline to a cubic vector path while preserving straight segments. */
    fun fromPolyline(name: String, points: List<android.graphics.PointF>, closed: Boolean, fillColor: Int, strokeColor: Int, strokeWidth: Float): VectorShape {
        val nodes = points.mapIndexed { index, point ->
            val previous = points.getOrNull(index - 1)
            val next = points.getOrNull(index + 1)
            val incomingX = previous?.let { (it.x - point.x) / 3f } ?: 0f
            val incomingY = previous?.let { (it.y - point.y) / 3f } ?: 0f
            val outgoingX = next?.let { (it.x - point.x) / 3f } ?: 0f
            val outgoingY = next?.let { (it.y - point.y) / 3f } ?: 0f
            VectorNode(point.x, point.y, incomingX, incomingY, outgoingX, outgoingY)
        }
        return VectorShape(name = name, nodes = nodes, closed = closed, fillColor = fillColor, strokeColor = strokeColor, strokeWidth = strokeWidth)
    }

    /** Builds a true cubic-Bezier path. Tangents are relative to their anchor points. */
    fun vectorPath(shape: VectorShape): Path {
        val p = Path()
        if (shape.nodes.isEmpty()) return p
        val first = shape.nodes.first()
        p.moveTo(first.x, first.y)
        for (i in 1 until shape.nodes.size) {
            val a = shape.nodes[i - 1]; val b = shape.nodes[i]
            p.cubicTo(a.x + a.outgoingX, a.y + a.outgoingY,
                b.x + b.incomingX, b.y + b.incomingY, b.x, b.y)
        }
        if (shape.closed && shape.nodes.size > 1) {
            val a = shape.nodes.last(); val b = shape.nodes.first()
            p.cubicTo(a.x + a.outgoingX, a.y + a.outgoingY,
                b.x + b.incomingX, b.y + b.incomingY, b.x, b.y)
            p.close()
        }
        return p
    }

    /** Smooth a node by making its incoming/outgoing handles collinear and equal length. */
    fun smoothNode(nodes: List<VectorNode>, index: Int): List<VectorNode> {
        if (index !in nodes.indices) return nodes
        val out = nodes.toMutableList(); val n = out[index]
        val vx = n.outgoingX - n.incomingX; val vy = n.outgoingY - n.incomingY
        val length = kotlin.math.hypot(vx.toDouble(), vy.toDouble()).toFloat() / 2f
        val angle = kotlin.math.atan2(vy.toDouble(), vx.toDouble())
        val dx = (kotlin.math.cos(angle) * length).toFloat(); val dy = (kotlin.math.sin(angle) * length).toFloat()
        out[index] = n.copy(incomingX = -dx, incomingY = -dy, outgoingX = dx, outgoingY = dy, type = NodeType.SMOOTH)
        return out
    }

    data class Adjustment(
        val exposure: Float = 0f, val contrast: Float = 1f, val saturation: Float = 1f,
        val temperature: Float = 0f, val tint: Float = 0f, val clarity: Float = 0f,
        val sharpen: Float = 0f
    )
    data class Layer(
        val id: String = UUID.randomUUID().toString(),
        val name: String,
        val bitmap: Bitmap? = null,
        val mask: Bitmap? = null,
        val visible: Boolean = true,
        val locked: Boolean = false,
        val opacity: Float = 1f,
        val x: Float = 0f, val y: Float = 0f,
        val scaleX: Float = 1f, val scaleY: Float = 1f,
        val rotation: Float = 0f,
        val adjustment: Adjustment? = null,
        val vector: VectorShape? = null
    )

    /** Applies a layer mask as alpha without changing the original source bitmap. */
    fun applyMask(source: Bitmap, mask: Bitmap?): Bitmap {
        if (mask == null) return source.copy(Bitmap.Config.ARGB_8888, true)
        val out = source.copy(Bitmap.Config.ARGB_8888, true)
        val w = out.width; val h = out.height
        val src = IntArray(w * h); val mp = IntArray(w * h)
        out.getPixels(src, 0, w, 0, 0, w, h)
        val scaled = if (mask.width == w && mask.height == h) mask else Bitmap.createScaledBitmap(mask, w, h, true)
        scaled.getPixels(mp, 0, w, 0, 0, w, h)
        for (i in src.indices) {
            val m = max(mp[i] ushr 24, (((mp[i] shr 16) and 255) + ((mp[i] shr 8) and 255) + (mp[i] and 255)) / 3)
            val a = (src[i] ushr 24) * m / 255
            src[i] = (src[i] and 0x00FFFFFF) or (a shl 24)
        }
        out.setPixels(src, 0, w, 0, 0, w, h)
        if (scaled !== mask) scaled.recycle()
        return out
    }

    /** Renders a stack with independent masks, transforms and non-destructive adjustment layers. */
    fun renderStack(width: Int, height: Int, layers: List<Layer>): Bitmap {
        val result = Bitmap.createBitmap(width.coerceAtLeast(1), height.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        layers.filter { it.visible }.forEach { layer ->
            val source = layer.bitmap
            if (layer.adjustment != null) {
                // Adjustment layers affect the composite below them, preserving the source layers.
                val adjusted = applyAdjustment(result, layer.adjustment)
                canvas.drawBitmap(adjusted, 0f, 0f, null)
                adjusted.recycle()
            } else if (source != null) {
                val masked = applyMask(source, layer.mask)
                val save = canvas.save()
                canvas.translate(layer.x, layer.y)
                canvas.rotate(layer.rotation, source.width / 2f, source.height / 2f)
                canvas.scale(layer.scaleX, layer.scaleY, source.width / 2f, source.height / 2f)
                val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                    alpha = (layer.opacity.coerceIn(0f, 1f) * 255).toInt()
                }
                canvas.drawBitmap(masked, 0f, 0f, paint)
                canvas.restoreToCount(save)
                masked.recycle()
            } else if (layer.vector != null) {
                val shape = layer.vector
                val path = vectorPath(shape)
                val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = shape.fillColor; style = Paint.Style.FILL; alpha = (layer.opacity.coerceIn(0f,1f)*255).toInt() }
                val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = shape.strokeColor; style = Paint.Style.STROKE; strokeWidth = shape.strokeWidth; alpha = (layer.opacity.coerceIn(0f,1f)*255).toInt() }
                if (Color.alpha(shape.fillColor) > 0) canvas.drawPath(path, fill)
                if (shape.strokeWidth > 0f) canvas.drawPath(path, stroke)
            }
        }
        return result
    }

    fun applyAdjustment(source: Bitmap, a: Adjustment): Bitmap {
        var out = AdvancedImageOps.adjustExposure(source, a.exposure, temperature = a.temperature, tint = a.tint)
        val adjusted = Bitmap.createBitmap(out.width, out.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(adjusted)
        val contrast = a.contrast.coerceIn(0f, 3f)
        val offset = 128f * (1f - contrast)
        val matrix = android.graphics.ColorMatrix().apply {
            setSaturation(a.saturation.coerceIn(0f, 3f))
            postConcat(android.graphics.ColorMatrix(floatArrayOf(
                contrast,0f,0f,0f,offset, 0f,contrast,0f,0f,offset,
                0f,0f,contrast,0f,offset, 0f,0f,0f,1f,0f
            )))
        }
        canvas.drawBitmap(out, 0f, 0f, Paint(Paint.ANTI_ALIAS_FLAG).apply { colorFilter = android.graphics.ColorMatrixColorFilter(matrix) })
        out = adjusted
        if (a.clarity != 0f) out = EditorFeatures.clarity(out, a.clarity)
        if (a.sharpen != 0f) out = AdvancedImageOps.sharpen(out, a.sharpen)
        return out
    }

    /** Save named selections as PNG files in app-private storage. */
    fun saveNamedMask(directory: File, name: String, mask: Bitmap): File {
        val safe = name.trim().replace(Regex("[^A-Za-z0-9_\\-\\u0600-\\u06FF ]"), "_").take(48).ifBlank { "Selection" }
        val dir = File(directory, "selections").apply { mkdirs() }
        val file = File(dir, "$safe.png")
        file.outputStream().use { mask.compress(Bitmap.CompressFormat.PNG, 100, it) }
        return file
    }

    fun loadNamedMask(directory: File, name: String): Bitmap? {
        val safe = name.trim().replace(Regex("[^A-Za-z0-9_\\-\\u0600-\\u06FF ]"), "_").take(48).ifBlank { "Selection" }
        val file = File(File(directory, "selections"), "$safe.png")
        return if (file.isFile) android.graphics.BitmapFactory.decodeFile(file.absolutePath) else null
    }

    fun listNamedMasks(directory: File): List<String> = File(directory, "selections").listFiles()
        ?.filter { it.isFile && it.extension.equals("png", true) }?.map { it.nameWithoutExtension }?.sorted() ?: emptyList()

    /** Export a vector document as SVG. Bitmap backgrounds are embedded as PNG data URIs. */
    fun exportSvg(background: Bitmap?, shapes: List<VectorShape>, width: Int, height: Int): String {
        val w=width.coerceAtLeast(1); val h=height.coerceAtLeast(1)
        val b64 = background?.let { bmp ->
            val bytes=ByteArrayOutputStream(); bmp.compress(Bitmap.CompressFormat.PNG,100,bytes)
            "data:image/png;base64,"+Base64.encodeToString(bytes.toByteArray(),Base64.NO_WRAP)
        }
        val body=buildString {
            if (b64 != null) append("<image x=\"0\" y=\"0\" width=\"$w\" height=\"$h\" href=\"$b64\" />")
            shapes.forEach { s ->
                if (s.nodes.isNotEmpty()) {
                    val first=s.nodes.first(); val d=StringBuilder("M ${first.x} ${first.y}")
                    for(i in 1 until s.nodes.size){val a=s.nodes[i-1];val n=s.nodes[i];d.append(" C ${a.x+a.outgoingX} ${a.y+a.outgoingY}, ${n.x+n.incomingX} ${n.y+n.incomingY}, ${n.x} ${n.y}")}
                    if(s.closed){val a=s.nodes.last();val n=s.nodes.first();d.append(" C ${a.x+a.outgoingX} ${a.y+a.outgoingY}, ${n.x+n.incomingX} ${n.y+n.incomingY}, ${n.x} ${n.y} Z")}
                    append(String.format(Locale.US, "<path d=\"%s\" fill=\"#%06X\" fill-opacity=\"%.4f\" stroke=\"#%06X\" stroke-width=\"%.3f\" />", d.toString(), s.fillColor and 0xFFFFFF, Color.alpha(s.fillColor)/255f, s.strokeColor and 0xFFFFFF, s.strokeWidth))
                }
            }
        }
        return "<svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" width=\"$w\" height=\"$h\" viewBox=\"0 0 $w $h\">$body</svg>"
    }

    /** Makes a centered square PNG suitable as an app-icon artwork source. */
    fun makeAppIconArtwork(source: Bitmap, size: Int = 1024, backgroundColor: Int = Color.BLACK, inset: Float = .12f): Bitmap {
        val s=size.coerceIn(128,2048); val out=Bitmap.createBitmap(s,s,Bitmap.Config.ARGB_8888); val c=Canvas(out)
        c.drawColor(backgroundColor)
        val pad=(s*inset.coerceIn(0f,.35f)); val target=RectF(pad,pad,s-pad,s-pad)
        val scale=minOf(target.width()/source.width,target.height()/source.height)
        val dw=source.width*scale; val dh=source.height*scale
        val dst=RectF((s-dw)/2f,(s-dh)/2f,(s+dw)/2f,(s+dh)/2f)
        c.drawBitmap(source,null,dst,Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
        return out
    }
}
