package com.moknight.photoeditor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import java.nio.ByteOrder

/**
 * On-device person segmentation. The bundled ML Kit model is packaged with the app,
 * so this feature does not need a network connection at inference time.
 */
object OfflineAiTools {
    fun segmentPerson(context: Context, source: Bitmap, onResult: (Result<Bitmap>) -> Unit) {
        val options = SelfieSegmenterOptions.Builder()
            .setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE)
            .enableRawSizeMask()
            .build()
        val segmenter = Segmentation.getClient(options)
        val input = InputImage.fromBitmap(source, 0)
        segmenter.process(input)
            .addOnSuccessListener { segmentationMask ->
                try {
                    val width = segmentationMask.width
                    val height = segmentationMask.height
                    val floats = segmentationMask.buffer.order(ByteOrder.nativeOrder()).asFloatBuffer()
                    val pixels = IntArray(width * height)
                    for (i in pixels.indices) {
                        val confidence = if (floats.hasRemaining()) floats.get().coerceIn(0f, 1f) else 0f
                        val alpha = (confidence * 255f).toInt()
                        // White RGB with confidence alpha: compatible with applyAlphaMask().
                        pixels[i] = (alpha shl 24) or 0x00FFFFFF
                    }
                    val mask = Bitmap.createBitmap(pixels, width, height, Bitmap.Config.ARGB_8888)
                    onResult(Result.success(Bitmap.createScaledBitmap(mask, source.width, source.height, true)))
                } catch (t: Throwable) {
                    onResult(Result.failure(t))
                } finally {
                    segmenter.close()
                }
            }
            .addOnFailureListener { error ->
                segmenter.close()
                onResult(Result.failure(error))
            }
    }

    /** Keeps the detected person sharp and applies a soft low-resolution blur to the background. */
    fun blurBackground(source: Bitmap, personMask: Bitmap): Bitmap {
        val backgroundMask = invertMask(personMask)
        return AdvancedImageOps.selectiveBlur(source, backgroundMask, 18)
    }

    /** Composites the extracted person over a solid-color replacement background. */
    fun replaceBackground(source: Bitmap, personMask: Bitmap, color: Int): Bitmap {
        val person = AdvancedImageOps.applyAlphaMask(source, personMask)
        val output = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        canvas.drawColor(color)
        canvas.drawBitmap(person, 0f, 0f, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
        return output
    }


    /** Smooths the segmentation edge to reduce harsh cutout borders. */
    fun refinePersonMask(mask: Bitmap, softness: Float = 0.18f): Bitmap =
        EditorFeatures.featherMask(mask, softness.coerceIn(0f, 0.45f))

    /** Manual edge matte refinement: increases mask edge contrast and feathers transitions. */
    fun refineHairMask(mask: Bitmap, edgeContrast: Float = 1.25f, feather: Float = 0.12f): Bitmap {
        val w = mask.width; val h = mask.height
        val pixels = IntArray(w * h)
        mask.getPixels(pixels, 0, w, 0, 0, w, h)
        val contrast = edgeContrast.coerceIn(0.5f, 2.5f)
        for (i in pixels.indices) {
            val a = (pixels[i] ushr 24) and 255
            val normalized = a / 255f
            val adjusted = (((normalized - .5f) * contrast + .5f).coerceIn(0f, 1f) * 255f).toInt()
            pixels[i] = (adjusted shl 24) or 0x00FFFFFF
        }
        val refined = Bitmap.createBitmap(pixels, w, h, Bitmap.Config.ARGB_8888)
        return if (feather > 0f) EditorFeatures.featherMask(refined, feather.coerceIn(0f, .45f)).also { refined.recycle() } else refined
    }

    /** Extracts the detected person as a transparent PNG-ready bitmap. */
    fun cutoutPerson(source: Bitmap, personMask: Bitmap, refineEdges: Boolean = true): Bitmap {
        val mask = if (refineEdges) refinePersonMask(personMask) else personMask
        return AdvancedImageOps.applyAlphaMask(source, mask)
    }

    /** Replaces the background with a user-selected image, fully on-device. */
    fun replaceBackgroundWithImage(source: Bitmap, personMask: Bitmap, background: Bitmap): Bitmap {
        val output = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        canvas.drawBitmap(background, null, android.graphics.Rect(0, 0, source.width, source.height), Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
        canvas.drawBitmap(cutoutPerson(source, personMask), 0f, 0f, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
        return output
    }

    fun invertMask(mask: Bitmap): Bitmap {
        val width = mask.width
        val height = mask.height
        val input = IntArray(width * height)
        mask.getPixels(input, 0, width, 0, 0, width, height)
        for (i in input.indices) {
            val alpha = 255 - (input[i] ushr 24)
            input[i] = (alpha shl 24) or Color.WHITE
        }
        return Bitmap.createBitmap(input, width, height, Bitmap.Config.ARGB_8888)
    }
}
