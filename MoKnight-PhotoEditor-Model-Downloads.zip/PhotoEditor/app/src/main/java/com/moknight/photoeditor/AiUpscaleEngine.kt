package com.moknight.photoeditor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest
import java.util.concurrent.Executors

/**
 * Real-ESRGAN x4plus super-resolution. The ONNX model is downloaded on the user's
 * first explicit upscale action and kept in app-private storage. The downloaded
 * file is verified against a publisher-listed SHA-256. Inference is local. Large inputs are processed in tiles.
 * Model contract: input [1,3,H,W] RGB float [0,1], output [1,3,4H,4W] RGB float.
 */
object AiUpscaleEngine {
    private const val MODEL_URL = "https://huggingface.co/SceneWorks/real-esrgan-onnx/resolve/main/real_esrgan_x4.onnx"
    // Publisher-listed SHA-256 (SceneWorks/real-esrgan-onnx model card, BSD-3-Clause export of RealESRGAN_x4plus).
    private const val MODEL_SHA256 = "5c586662929cbc686c1a5c38d9c060dbdb4ea5863a1f7672b8c0761e6b89c033"
    private const val TILE = 256
    private const val SCALE = 4
    private const val MAX_LONG_EDGE = 1024
    private val worker = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val env by lazy { OrtEnvironment.getEnvironment() }

    fun upscale4x(context: Context, source: Bitmap, onProgress: (String) -> Unit, onResult: (Result<Bitmap>) -> Unit) {
        val app = context.applicationContext
        worker.execute {
            val result = runCatching {
                val modelInfo = AiModelManager.upscale
                if (!AiModelManager.isInstalled(app, modelInfo)) {
                    main.post { onProgress("نموذج Real-ESRGAN غير مثبت. يمكنك تنزيله من الإعدادات > تنزيل وإدارة الموديلات.") }
                    error("نموذج Real-ESRGAN غير مثبت")
                }
                val model = modelFile(app)
                main.post { onProgress("النموذج جاهز. جاري تحسين التفاصيل محليًا…") }
                runModel(model, source)
            }
            main.post { onResult(result) }
        }
    }

    private fun modelFile(context: Context) = File(context.filesDir, "models/upscale/realesrgan_x4plus.onnx").also { it.parentFile?.mkdirs() }

    // Cryptographic check: the file must match the publisher-listed SHA-256.
    private fun validModel(file: File): Boolean {
        if (!file.exists() || file.length() < 10_000_000L) return false
        return runCatching { sha256(file).equals(MODEL_SHA256, ignoreCase = true) }.getOrDefault(false)
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered().use { input ->
            val buffer = ByteArray(256 * 1024)
            while (true) { val n = input.read(buffer); if (n < 0) break; digest.update(buffer, 0, n) }
        }
        return digest.digest().joinToString("") { "%02x".format(it.toInt() and 0xff) }
    }

    private fun downloadModel(target: File, progress: (Int) -> Unit) {
        val temp = File(target.parentFile, target.name + ".download")
        val connection = (URL(MODEL_URL).openConnection() as HttpURLConnection).apply {
            connectTimeout = 30_000; readTimeout = 180_000; instanceFollowRedirects = true
            setRequestProperty("User-Agent", "MoKnight-Photo-Editor/1.0")
        }
        try {
            connection.connect()
            if (connection.responseCode !in 200..299) error("تعذر تنزيل نموذج Real-ESRGAN: HTTP ${connection.responseCode}")
            val total = connection.contentLengthLong
            BufferedInputStream(connection.inputStream).use { input -> FileOutputStream(temp).use { output ->
                val buffer = ByteArray(512 * 1024); var copied = 0L; var last = -1
                while (true) { val n = input.read(buffer); if (n < 0) break; output.write(buffer, 0, n); copied += n
                    if (total > 0) { val p = (copied * 100 / total).toInt().coerceIn(0,100); if (p != last) { progress(p); last = p } }
                }
                output.fd.sync()
            } }
            if (!validModel(temp)) { temp.delete(); error("فشل التحقق من سلامة نموذج Real-ESRGAN (SHA-256)") }
            if (target.exists()) target.delete()
            if (!temp.renameTo(target)) error("تعذر حفظ نموذج تحسين الدقة")
        } finally { connection.disconnect(); if (temp.exists()) temp.delete() }
    }


    private fun runModel(model: File, source: Bitmap): Bitmap {
        val factor = minOf(1f, MAX_LONG_EDGE.toFloat() / maxOf(source.width, source.height))
        val input = if (factor < 1f) Bitmap.createScaledBitmap(source, (source.width*factor).toInt().coerceAtLeast(1), (source.height*factor).toInt().coerceAtLeast(1), true) else source
        val outW = input.width * SCALE; val outH = input.height * SCALE
        val output = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        val options = OrtSession.SessionOptions().apply { setIntraOpNumThreads(2); setInterOpNumThreads(1); setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT) }
        val session = try { env.createSession(model.absolutePath, options) } finally { options.close() }
        session.use { s ->
            val inputName = s.inputNames.firstOrNull() ?: error("نموذج Upscale لا يحتوي على مدخل")
            val outputName = s.outputNames.firstOrNull() ?: error("نموذج Upscale لا يحتوي على مخرج")
            var top = 0
            while (top < input.height) {
                var left = 0
                val tileH = minOf(TILE, input.height-top)
                while (left < input.width) {
                    val tileW = minOf(TILE, input.width-left)
                    val tile = Bitmap.createBitmap(input, left, top, tileW, tileH)
                    val pixels = IntArray(tileW*tileH); tile.getPixels(pixels,0,tileW,0,0,tileW,tileH)
                    val plane = tileW*tileH; val data = FloatArray(plane*3)
                    for (i in pixels.indices) { data[i]=Color.red(pixels[i])/255f; data[plane+i]=Color.green(pixels[i])/255f; data[2*plane+i]=Color.blue(pixels[i])/255f }
                    val fb = ByteBuffer.allocateDirect(data.size*4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply { put(data); rewind() }
                    val tensor = OnnxTensor.createTensor(env, fb, longArrayOf(1,3,tileH.toLong(),tileW.toLong()))
                    try {
                        s.run(mapOf(inputName to tensor)).use { result ->
                            val raw = result.get(0).value as? Array<Array<Array<FloatArray>>> ?: error("تنسيق ناتج نموذج Upscale غير مدعوم")
                            val channels=raw[0]; val expectedH=tileH*SCALE; val expectedW=tileW*SCALE
                            if(channels.size<3 || channels[0].size!=expectedH || channels[0][0].size!=expectedW) error("أبعاد نموذج Upscale لا تطابق x4")
                            val outPixels=IntArray(expectedW*expectedH)
                            for(y in 0 until expectedH) for(x in 0 until expectedW) {
                                fun channel(c:Int):Int { val v=channels[c][y][x]; val normalized=if(v<=1.5f) v*255f else v; return normalized.toInt().coerceIn(0,255) }
                                outPixels[y*expectedW+x]=Color.rgb(channel(0),channel(1),channel(2))
                            }
                            val tileOut=Bitmap.createBitmap(outPixels,expectedW,expectedH,Bitmap.Config.ARGB_8888)
                            AndroidBitmapCompat.drawTile(output,tileOut,left*SCALE,top*SCALE)
                            tileOut.recycle()
                        }
                    } finally { tensor.close(); if (tile !== input) tile.recycle() }
                    left += tileW
                }
                top += tileH
            }
        }
        if (input !== source) input.recycle()
        return output
    }

    private object AndroidBitmapCompat {
        fun drawTile(target: Bitmap, tile: Bitmap, x: Int, y: Int) {
            val canvas = android.graphics.Canvas(target)
            canvas.drawBitmap(tile, x.toFloat(), y.toFloat(), android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG))
        }
    }
}
