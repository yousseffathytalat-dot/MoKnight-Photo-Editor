package com.moknight.photoeditor

import android.content.Context
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.Executors

/**
 * Phase 3 model catalogue and on-demand downloader.
 * Models are deliberately kept outside the APK. Downloads are resumable at the file level,
 * written atomically, and checked for expected size. A SHA-256 is recorded locally after a
 * successful download so subsequent runs can detect corruption.
 */
object AiModelManager {
    data class ModelInfo(
        val id: String,
        val title: String,
        val purpose: String,
        val sizeLabel: String,
        val sizeBytes: Long,
        val license: String,
        val sourceUrl: String,
        val storageDir: String = "models",
        val files: List<ModelFile> = emptyList()
    )

    data class ModelFile(
        val relativePath: String,
        val url: String,
        val minimumBytes: Long,
        val expectedSha256: String? = null
    )

    val objectRemoval = ModelInfo(
        id = "lama_dilated_int8",
        title = "LaMa-Dilated INT8",
        purpose = "إزالة العناصر وإكمال المناطق المحددة",
        sizeLabel = "حوالي 44 MB",
        sizeBytes = 44L * 1024 * 1024,
        license = "Apache-2.0 (حسب بطاقة النموذج المنشورة)",
        sourceUrl = "https://huggingface.co/Mateus24232u/lama_dilated_int8",
        files = listOf(
            ModelFile(
                "lama_int8.tflite",
                "https://huggingface.co/Mateus24232u/lama_dilated_int8/resolve/main/lama_int8.tflite",
                30L * 1024 * 1024,
                "fb37b19e746f71c930fc42d1cc4f0b3582fbe003f8aff531212f2dfc240d88f7"
            )
        )
    )

    // RealVis 6 inpainting is intentionally a separate optional package. It is not bundled in APK.
    // The publisher's card reports ~1.3 GB for the INT8 ONNX pipeline.
    val generativeFill = ModelInfo(
        id = "realvis6_inpaint_int8",
        title = "RealVis 6 Inpaint INT8",
        purpose = "Text + Mask photorealistic generative fill",
        sizeLabel = "حوالي 1.3 GB",
        sizeBytes = 1_300_000_000L,
        license = "CreativeML OpenRAIL-M (راجع القيود قبل التوزيع)",
        sourceUrl = "https://huggingface.co/latentdivergence/realvis6-inpaint-int8-onnx",
        files = listOf(
            ModelFile("unet/model.onnx", "https://huggingface.co/latentdivergence/realvis6-inpaint-int8-onnx/resolve/main/unet/model.onnx", 100_000_000),
            ModelFile("unet/model.onnx_data", "https://huggingface.co/latentdivergence/realvis6-inpaint-int8-onnx/resolve/main/unet/model.onnx_data", 100_000_000),
            ModelFile("text_encoder/model.onnx", "https://huggingface.co/latentdivergence/realvis6-inpaint-int8-onnx/resolve/main/text_encoder/model.onnx", 50_000_000),
            ModelFile("text_encoder/model.onnx_data", "https://huggingface.co/latentdivergence/realvis6-inpaint-int8-onnx/resolve/main/text_encoder/model.onnx_data", 50_000_000),
            ModelFile("vae_encoder/model.onnx", "https://huggingface.co/latentdivergence/realvis6-inpaint-int8-onnx/resolve/main/vae_encoder/model.onnx", 50_000_000),
            ModelFile("vae_decoder/model.onnx", "https://huggingface.co/latentdivergence/realvis6-inpaint-int8-onnx/resolve/main/vae_decoder/model.onnx", 20_000_000),
            ModelFile("tokenizer/vocab.json", "https://huggingface.co/latentdivergence/realvis6-inpaint-int8-onnx/resolve/main/tokenizer/vocab.json", 1_000_000),
            ModelFile("tokenizer/merges.txt", "https://huggingface.co/latentdivergence/realvis6-inpaint-int8-onnx/resolve/main/tokenizer/merges.txt", 100_000)
        )
    )

    /**
     * Optional super-resolution model. It is not bundled in the APK and shares the exact
     * storage path already used by AiUpscaleEngine, so downloading it here makes the
     * existing upscale tool fully offline-ready.
     */
    val upscale = ModelInfo(
        id = "realesrgan_x4plus",
        title = "Real-ESRGAN x4plus",
        purpose = "رفع دقة الصورة 4× واستعادة التفاصيل والحدة",
        sizeLabel = "حوالي 64 MB",
        sizeBytes = 64L * 1024 * 1024,
        license = "BSD-3-Clause",
        sourceUrl = "https://huggingface.co/SceneWorks/real-esrgan-onnx",
        storageDir = "models/upscale",
        files = listOf(
            ModelFile(
                "realesrgan_x4plus.onnx",
                "https://huggingface.co/SceneWorks/real-esrgan-onnx/resolve/main/real_esrgan_x4.onnx",
                60L * 1024 * 1024,
                "5c586662929cbc686c1a5c38d9c060dbdb4ea5863a1f7672b8c0761e6b89c033"
            )
        )
    )

    // Existing Phase 2 model retained for compatibility. Nothing is downloaded automatically.
    val all = listOf(objectRemoval, generativeFill, upscale)

    private val executor = Executors.newCachedThreadPool()

    fun directory(context: Context, model: ModelInfo): File = File(context.filesDir, model.storageDir).apply { mkdirs() }

    fun isInstalled(context: Context, model: ModelInfo): Boolean {
        val dir = directory(context, model)
        return model.files.all { file ->
            val target = File(dir, file.relativePath)
            target.exists() && target.length() >= file.minimumBytes && sidecarSha(target).isFile &&
                runCatching {
                    val actual = sha256(target)
                    val recorded = sidecarSha(target).readText().trim()
                    actual.equals(recorded, ignoreCase = true) &&
                        (file.expectedSha256 == null || actual.equals(file.expectedSha256, ignoreCase = true))
                }.getOrDefault(false)
        }
    }

    fun installedBytes(context: Context, model: ModelInfo): Long = directory(context, model).walkTopDown().filter { it.isFile && !it.name.endsWith(".sha256") }.sumOf { it.length() }

    fun delete(context: Context, model: ModelInfo): Boolean = directory(context, model).deleteRecursively()

    fun downloadBlocking(context: Context, model: ModelInfo, onProgress: (String) -> Unit) {
        if (isInstalled(context, model)) return
        model.files.forEachIndexed { index, file ->
            val target = File(directory(context, model), file.relativePath)
            if (target.exists() && target.length() >= file.minimumBytes && sidecarSha(target).isFile) return@forEachIndexed
            downloadFile(file, target) { p -> onProgress("${model.title}: ملف ${index + 1}/${model.files.size} — $p٪") }
        }
    }

    fun download(
        context: Context,
        model: ModelInfo,
        onProgress: (String) -> Unit,
        onResult: (Result<Unit>) -> Unit
    ) {
        val app = context.applicationContext
        executor.execute {
            val result = runCatching {
                if (model.files.isEmpty()) error("النموذج لا يحتوي ملفات قابلة للتنزيل")
                model.files.forEachIndexed { index, file ->
                    val target = File(directory(app, model), file.relativePath)
                    if (target.exists() && target.length() >= file.minimumBytes && sidecarSha(target).isFile) {
                        onProgress("${model.title}: ملف ${index + 1}/${model.files.size} موجود")
                    } else {
                        downloadFile(file, target) { p -> onProgress("${model.title}: ملف ${index + 1}/${model.files.size} — $p٪") }
                    }
                }
                onProgress("${model.title}: اكتمل التنزيل والتحقق")
            }
            onResult(result)
        }
    }

    private fun downloadFile(file: ModelFile, target: File, progress: (Int) -> Unit) {
        target.parentFile?.mkdirs()
        val temp = File(target.parentFile, target.name + ".download")
        val connection = (URL(file.url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 30_000
            readTimeout = 180_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "MoKnight-Photo-Editor/3.0")
        }
        try {
            connection.connect()
            if (connection.responseCode !in 200..299) error("HTTP ${connection.responseCode}")
            val total = connection.contentLengthLong
            var copied = 0L
            var last = -1
            BufferedInputStream(connection.inputStream).use { input ->
                FileOutputStream(temp).use { output ->
                    val buffer = ByteArray(512 * 1024)
                    while (true) {
                        val n = input.read(buffer)
                        if (n < 0) break
                        output.write(buffer, 0, n)
                        copied += n
                        if (total > 0) {
                            val p = (copied * 100L / total).toInt().coerceIn(0, 100)
                            if (p != last) { last = p; progress(p) }
                        }
                    }
                    output.fd.sync()
                }
            }
            if (temp.length() < file.minimumBytes) error("الملف أصغر من المتوقع")
            val digest = sha256(temp)
            if (file.expectedSha256 != null && !digest.equals(file.expectedSha256, ignoreCase = true)) {
                temp.delete()
                error("فشل التحقق من SHA-256 لنموذج ${file.relativePath}")
            }
            sidecarSha(target).writeText(digest)
            if (target.exists()) target.delete()
            if (!temp.renameTo(target)) error("تعذر تثبيت الملف")
            sidecarSha(target).writeText(digest)
        } finally {
            connection.disconnect()
            if (temp.exists()) temp.delete()
        }
    }

    private fun sidecarSha(file: File) = File(file.parentFile, file.name + ".sha256")

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered().use { input ->
            val buffer = ByteArray(256 * 1024)
            while (true) { val n = input.read(buffer); if (n < 0) break; digest.update(buffer, 0, n) }
        }
        return digest.digest().joinToString("") { "%02x".format(it.toInt() and 0xff) }
    }
}
