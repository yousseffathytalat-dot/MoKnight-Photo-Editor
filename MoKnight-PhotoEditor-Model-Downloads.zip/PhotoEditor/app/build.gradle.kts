plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.moknight.photoeditor"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.moknight.photoeditor"
        minSdk = 29; targetSdk = 34; versionCode = 1; versionName = "1.0"
    }
    buildFeatures { compose = true }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    // GPU shader effects (MIT): curves, HSL, blending and custom filter rules.
    implementation("org.wysaid:gpuimage-plus:3.2.0-min")
    // OpenCV Android (Apache/BSD family): perspective transforms, inpainting and image operations.
    implementation("org.opencv:opencv:4.14.0")
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.activity:activity-compose:1.9.2")
    // Bundled on-device selfie segmentation model; inference works offline after installation.
    implementation("com.google.mlkit:segmentation-selfie:16.0.0-beta6")
    implementation("com.google.mediapipe:tasks-vision:1.1.1")
    // CPU ONNX Runtime for offline LaMa generative inpainting.
    implementation("com.microsoft.onnxruntime:onnxruntime-android:1.20.0")
    // Lightweight TFLite runtime for the 44 MB INT8 LaMa-Dilated object-removal model.
    implementation("org.tensorflow:tensorflow-lite:2.16.1")
}


// Download the two small, Apache-2.0 MediaPipe model assets once at build time.
// The resulting APK contains both models and performs inference fully offline.
val downloadOfflineAiModels by tasks.registering {
    val assetsDir = layout.projectDirectory.dir("src/main/assets")
    outputs.files(
        assetsDir.file("hair_segmenter.tflite"),
        assetsDir.file("magic_touch.tflite")
    )
    doLast {
        val dir = assetsDir.asFile.apply { mkdirs() }
        val models = mapOf(
            "hair_segmenter.tflite" to "https://storage.googleapis.com/mediapipe-models/image_segmenter/hair_segmenter/float32/latest/hair_segmenter.tflite",
            "magic_touch.tflite" to "https://storage.googleapis.com/mediapipe-models/interactive_segmenter/magic_touch/float32/1/magic_touch.tflite"
        )
        models.forEach { (name, address) ->
            val target = dir.resolve(name)
            if (!target.exists() || target.length() < 1024L) {
                logger.lifecycle("Downloading offline AI model: $name")
                val temp = dir.resolve("$name.download")
                java.net.URL(address).openStream().use { input -> temp.outputStream().use { output -> input.copyTo(output) } }
                if (temp.length() < 1024L) throw GradleException("Downloaded model $name is unexpectedly small")
                if (target.exists()) target.delete()
                if (!temp.renameTo(target)) throw GradleException("Could not install model $name")
            }
        }
    }
}
tasks.named("preBuild").configure { dependsOn(downloadOfflineAiModels) }
