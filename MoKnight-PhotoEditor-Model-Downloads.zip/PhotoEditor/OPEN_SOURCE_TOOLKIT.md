# MoKnight – Open-source processing toolkit

## Dependencies

| Repository | Library | Used for | License |
|---|---|---|---|
| `wysaid/android-gpuimage-plus` | GPUImage-Plus `3.2.0-min` (image-only) | GPU filter buttons in the Filters tool | MIT |
| `opencv/opencv` | OpenCV Android `4.14.0` (Maven Central) | Four-point perspective correction and the "إزالة OpenCV" inpaint button | Apache-2.0 / BSD-3-Clause family |

Both versions were checked against their public release pages. GPUImage-Plus is served from `https://maven.wysaid.org/` (already declared in `settings.gradle.kts`).

## Where they are connected

- `GpuImageEffects.kt` → Filters tool: three GPU filter buttons (clarity, vignette, warm). Failures are caught and shown as a status line.
- `OpenCvImageToolkit.kt` → initialized in `MainActivity.onCreate`; used by Crop / Perspective (falls back to the built-in warp if OpenCV is unavailable or the quad is invalid) and by the AI panel inpaint button.
- `HtmlTextLayer.kt` → Text tool: HTML/CSS preview box with JavaScript disabled. It is a preview only; it does not create an image layer.

## Removed

- Audio effects (`AndroidAudioEffects.kt`) were removed; this is a photo editor.
- RichEditor was removed because no code used it.
- TarsosDSP was never added (GPL-3.0).

## Limits

- No APK was built or tested on a device by the author of this update. GPUImage rule-string value ranges (contrast 0–4, saturation 0–2) follow the library's rule documentation and should be checked on a device.
- GPUImage-Plus needs its native ABI libraries and an OpenGL ES context; OpenCV must be initialized before use.
