# MoKnight Photo Editor

Android photo editor source project (Kotlin + Jetpack Compose).

## Open the project
Open the `PhotoEditor` folder in Android Studio. The project uses Android Gradle Plugin 8.5.2, Kotlin 2.0.20, Java 17, compileSdk 34 and minSdk 29.

## Main source files
- `app/src/main/java/com/moknight/photoeditor/MainActivity.kt` — editor screen and current controls.
- `app/src/main/java/com/moknight/photoeditor/AdvancedImageOps.kt` — pixel operations (adjustments, HSL, curves, healing primitive, shapes, masks, gradients and blending).
- `app/src/main/java/com/moknight/photoeditor/OfflineAiTools.kt` — on-device person segmentation and background operations.
- `app/src/main/java/com/moknight/photoeditor/EditorFeatures.kt` — reusable layer compositor, mask editing primitives, RGB curves, clarity, crop and patch-repair helpers.
- `FEATURES_CATALOG.md` — full feature checklist and honest implementation status.

## Offline AI
The bundled ML Kit selfie segmentation model performs person segmentation on-device. MediaPipe Tasks Vision supplies hair and tap-based object-selection models. LaMa ONNX inpainting is integrated through ONNX Runtime Android for context-based Generative Fill.

## Build
Open in Android Studio (JDK 17), or build on GitHub: push the repository and the workflow in `.github/workflows/android-build.yml` builds a debug APK and uploads it as an artifact. The workflow installs Gradle 8.7 itself, so the Gradle wrapper is not required (run `gradle wrapper --gradle-version 8.7` once locally if you want `gradlew` committed).


### Current feature status

The latest source pass adds independent overlay-layer controls, advanced text styling, a larger shape set, custom point paths, RGB channel curve controls, gradient alpha/angle controls, manual mask painting, person-behind-text compositing, and LaMa ONNX Generative Fill. Some advanced capabilities remain incomplete: multi-point curve graph, Bézier handles, full adjustment layers, texture control, perspective correction, and expanded blend modes. Read `FEATURES_CATALOG.md` and `DEVELOPMENT_STATUS.md` before treating the source as production-ready.

## Offline AI model assets

The Android module now includes a Gradle `preBuild` task that downloads two official MediaPipe models into `app/src/main/assets` if absent:

- `hair_segmenter.tflite` — close-up hair segmentation.
- `magic_touch.tflite` — tap/point-guided arbitrary-object segmentation.

The first Gradle build requires an internet connection to retrieve these model files and the Maven dependencies. Once included in the APK, model inference runs locally without internet. This source ZIP does not currently contain the model binaries because the working environment could not fetch binary assets.

Object removal offers both a classical local fallback and LaMa ONNX context-based generative inpainting. The LaMa model is downloaded once on first use, SHA-256 verified, and then used locally without uploading photos. It does not accept text prompts.


## Generative Fill model

The ONNX weights are not embedded in the source ZIP. Tap Generative Fill once while online to download and verify the LaMa model; the verified model is kept in app-private storage for later offline use. The first use requires internet and storage space.

### Portrait and landscape use

- **Landscape on phones (including OPPO Reno6):** immersive full-screen mode hides the status and navigation bars, and the editor uses the full available display area. A swipe from an edge can temporarily reveal Android system bars; the app returns to immersive mode when it regains focus.
- **Portrait:** Android system bars remain visible and the existing portrait layout keeps its safe-area padding.
- Rotating between the two modes keeps the current editing session and loaded image in place.

The activity handles orientation changes without recreating the editing session, so the loaded image and in-progress edits remain available when rotating the phone. The tool panel becomes shorter and scrollable in landscape to give the canvas more room. The current interface is still a mobile-first stacked workspace; a dedicated side-dock desktop layout is not yet implemented.

The active selection is shown with a high-contrast dashed contour derived from the mask boundary, plus a translucent overlay. The visible contour is only as accurate as the AI/manual mask supplied to it.


### Four-corner perspective correction

In the Crop/Straighten tool, drag the four corner handles on the image to match the edges of the object or document. A live 3×3 alignment grid follows the selected quadrilateral. Apply Correction to rectify the selected quadrilateral, then use the straighten slider for fine rotation. Reset restores the four corners to the image edges. This source change has not yet been compiled or tested on a physical Android device.


### Recent editing controls
- Image layers: scale, rotate, X/Y offset and blend modes.
- Double Exposure: seven blend modes, opacity, scale, rotation, offsets, and add-as-independent-layer.
- Shapes: adjustable placement and dimensions before creating a shape layer.
- Masks: expand/shrink and save/union one previous selection.
See `FEATURES_CATALOG.md` for remaining limitations.

### SVG and app-icon exports

The editor has an SVG export action that saves to `Download/MoKnight`. Vector path overlays are emitted as SVG paths; the photograph and other raster layers are embedded as PNG data in the SVG. The `أيقونة 1024` action creates a centered 1024×1024 PNG artwork file under `Pictures/MoKnightIcons`; it does not change the installed Android app icon automatically.


## Editing updates — 2026-11-02
- Bitmap layers: direct on-canvas corner resize handles and a rotation handle in Move mode, plus independent source RGB channel selection.
- Vector paths: cubic Bézier handles are visible and draggable; nodes can be toggled smooth/sharp.
- Masks: manual alpha-matte edge contrast/feather controls for hair boundaries; these do not synthesize missing hair strands.
- Double exposure: ten blend modes, RGB channel filtering, and attaching the current selection as a layer mask.
- Runtime status: source-only update. No APK build or physical-device test was performed.

## Latest source-only editing pass (2026-11-02)

- Text and vector path layers now have on-canvas transform frames for move, resize and rotate. Preset shapes are created as editable vector path layers rather than flattened bitmap layers.
- Independent masks can be painted on bitmap, adjustment, text, vector and drawing layers. The Masks tool can switch between the global selection and the selected layer mask.
- Adjustment layers remain non-destructive and support exposure, contrast, saturation, temperature, tint, clarity, sharpening, opacity and masks.
- Pen Tool paths retain cubic Bézier handles and smooth/corner node state. Vector paths can be combined with Union, Subtract and Intersect operations.
- Double exposure now has a live canvas preview, optional selection mask, RGB channel filtering, ten blend modes and Blend-If-style luminance thresholds for shadows/highlights.
- Added a cinematic Teal & Orange lighting grade with warmth, teal shadows, contrast, vignette and highlight bloom.

These changes are source integrations only. No APK, Gradle build, or physical-device test was performed. Text/vector transform hit areas and boolean-path editing should be validated on a touch device before treating them as production-ready. Boolean-result paths render as vectors in the editor but are rasterized in the hybrid SVG export.

## AI features 15–17

- **15 AI Object Removal:** select an area, then use LaMa Generative Fill. First use downloads the model; later inference is local.
- **16 AI Upscale:** Real-ESRGAN x4plus ONNX, 4× tiled inference, capped at 4096 px on the long edge. First use downloads a model of roughly 60–70 MB. This is AI enhancement, not guaranteed recovery of original lost detail.
- **17 Smart Selection:** tap an object with MediaPipe MagicTouch, or choose person/hair segmentation. Refine the resulting mask manually.

Model weights are not included in this ZIP. First-time downloads require internet. No APK build or device test was performed.

### Cinematic color grading
The editor now has a dedicated cinematic grading tool with six built-in LUT-style looks (Teal & Orange, Hollywood, Moody Blue, Warm Film, Bleach Bypass, Vintage Film) plus manual controls for highlight warmth, teal shadows, contrast, vignette and bloom. These are local pixel transforms; external `.cube` LUT import is not included in this stage.
The mobile tool navigation is grouped into Basic, Color, AI & Selection, and Design & Layers sections so the tool strip is easier to browse on a phone.

### Manual cinematic grading and creative effects

The Cinematic panel is manual rather than preset-driven. It exposes exposure, contrast, highlights, shadows, whites, blacks, temperature, tint, vibrance, saturation, and separate shadow/midtone/highlight color controls with balance. It also includes eight independently applied creative effects (matte fade, posterize, solarize, duotone, highlight lift, edge burn, emboss, threshold). The existing Effects panel continues to provide vignette, grain, blur, sharpening, clarity and texture. See `AI_INTEGRATION_RESEARCH.md` for research references and limitations.


## Open-source media processing integrations

See `OPEN_SOURCE_TOOLKIT.md` for the GPUImage-Plus and OpenCV integrations, license notes, and current limits.
