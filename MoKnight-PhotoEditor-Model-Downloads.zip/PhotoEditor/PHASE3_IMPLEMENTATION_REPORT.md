# MoKnight Photo Editor — Phase 3 implementation report

## What changed

- Added a dedicated Phase 3 AI Studio UI with three tabs:
  - Object Removal
  - Generative Fill
  - Model Manager
- Added on-demand model management. AI models are stored in app-private storage and are not bundled into the APK.
- Replaced the previous large LaMa ONNX removal download with a mobile-focused LaMa-Dilated INT8 TFLite model package (~44 MB) from the published model card.
- Added TensorFlow Lite runtime dependency for the INT8 object-removal model.
- Added the RealVis 6 Inpaint INT8 ONNX package as a separate optional download (~1.3 GB), with the package split into its ONNX/tokenizer files.
- Added file-level minimum-size checks and post-download SHA-256 sidecar verification to detect corruption on subsequent launches.
- Kept the existing ONNX Runtime dependency and existing Real-ESRGAN pipeline intact.
- Kept `GenerativeFillEngine` as a compatibility facade so existing call sites do not break; its old mask-only operation now routes to the dedicated ObjectRemovalEngine.

## Model size budget

Phase 3 model downloads:

- LaMa-Dilated INT8: ~44 MB
- RealVis 6 Inpaint INT8 ONNX: ~1.3 GB
- Combined Phase 3 models: ~1.344 GB

The existing Real-ESRGAN model is downloaded separately and remains outside the APK. Therefore the planned model store remains comfortably below the user's 3 GB ceiling when all listed Phase 3 models are installed together.

## Important limitation

The RealVis package is a real text+mask inpainting model, but this revision does **not** falsely claim that the Android inference backend is complete. The package is downloadable and managed, but the full diffusion execution backend (tokenizer + text encoder + scheduler + UNet + VAE + Android native acceleration/runtime) still needs to be wired and verified on an actual Android device. The Generate button therefore does not fabricate an image and does not route text prompts through LaMa.

This is intentional: the project requirement says not to use fake results and not to claim a feature is complete before testing.

## Verification performed

- Project archive was unpacked and inspected before edits.
- Existing Kotlin/Compose/Gradle structure was preserved.
- Original ZIP was kept untouched as the backup source.
- Static source consistency was checked after edits.
- A full Android build could not be executed in this environment because the Gradle wrapper JAR is absent and no system Gradle installation is available. Device-level inference testing was therefore not possible here.

## External model references

- LaMa-Dilated INT8: `Mateus24232u/lama_dilated_int8`
- RealVis 6 Inpaint INT8 ONNX: `latentdivergence/realvis6-inpaint-int8-onnx`

Before commercial redistribution, review each model's current license and upstream terms.
